#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const { Claude } = await import("../mutator/claude/index");
  const mutator = new Claude();
  return mutator.execute();
}

const args = parseArgs(Bun.argv.slice(2));
runModule("Claude", main);