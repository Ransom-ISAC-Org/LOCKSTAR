#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));

  const baseUrl = args.params["jfrog-url"];
  if (!baseUrl)
    throw new Error(
      "--jfrog-url required (e.g. https://myco.jfrog.io/artifactory)",
    );

  const rawCred = args.params["jfrog-token"];
  if (!rawCred)
    throw new Error(
      "--jfrog-token required (API key, Bearer token, or user:pass)",
    );

  const { detectCredential, validateCredentials } =
    await import("../mutator/jfrognpm/auth");

  const explicitType = args.params["jfrog-auth-type"] as
    | "api-key"
    | "bearer"
    | "basic"
    | undefined;
  const credential = explicitType
    ? { type: explicitType, value: rawCred }
    : detectCredential(rawCred);
  console.error(`[jfrognpm] Auth type: ${credential.type}`);

  const validation = await validateCredentials(baseUrl, credential);

  if (!validation.valid) {
    throw new Error(`JFrog credential validation failed: ${validation.error}`);
  }

  const session = validation.session!;
  console.error(
    `[jfrognpm] Authenticated as ${session.username} (admin: ${session.isAdmin}, write: ${session.canWrite})`,
  );
  console.error(
    `[jfrognpm] NPM repos: ${session.npmRepos.join(", ") || "(none)"}`,
  );

  const packages = args.params["packages"]
    ? args.params["packages"]
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean)
    : [];

  const maxPackages = args.params["max-packages"]
    ? parseInt(args.params["max-packages"], 10)
    : undefined;

  const forceCache = args.flags.has("force-cache-overwrite");
  const doExecute = args.flags.has("execute");

  const { JfrogNpmMutator } = await import("../mutator/jfrognpm/index");
  const mutator = new JfrogNpmMutator(session, {
    packages,
    maxPackages,
    forceCacheOverwrite: forceCache,
    reconOnly: !doExecute,
  });

  return mutator.execute();
}

runModule("JfrogNpmClient", main);
