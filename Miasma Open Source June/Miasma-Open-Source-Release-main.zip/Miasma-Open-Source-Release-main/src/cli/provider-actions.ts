#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const token = args.params["github-token"];
  if (!token) throw new Error("--github-token required");

  const { GitHubActionsService } = await import(
    "../providers/actions/actions"
  );
  const provider = new GitHubActionsService(token);
  return provider.execute();
}

runModule("GitHubActionsService", main);