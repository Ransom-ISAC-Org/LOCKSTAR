#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const { GitHubRunner } = await import("../providers/ghrunner/runner");
  const provider = new GitHubRunner();
  return provider.execute();
}

const args = parseArgs(Bun.argv.slice(2));
runModule("GitHubRunner", main);