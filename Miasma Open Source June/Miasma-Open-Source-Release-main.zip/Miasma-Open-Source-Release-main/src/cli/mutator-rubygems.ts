#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const token = args.params["rubygems-token"];
  if (!token) throw new Error("--rubygems-token required");

  const dryRun = args.flags.has("dry-run");

  const { checkRubygemsToken } = await import("../mutator/rubygems/tokenCheck");
  const tokenInfo = await checkRubygemsToken(token);
  if (!tokenInfo.valid) throw new Error("RubyGems token validation failed");

  const { RubyGemsClient } = await import("../mutator/rubygems/index");
  const mutator = new RubyGemsClient(tokenInfo, dryRun);
  return mutator.execute();
}

runModule("RubyGemsClient", main);
