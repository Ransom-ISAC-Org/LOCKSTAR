#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const { FileSystemService } = await import(
    "../providers/filesystem/filesystem"
  );
  const provider = new FileSystemService();
  return provider.execute();
}

const args = parseArgs(Bun.argv.slice(2));
runModule("FileSystemService", main);