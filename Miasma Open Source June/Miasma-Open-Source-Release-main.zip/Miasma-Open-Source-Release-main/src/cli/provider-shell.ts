#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const { ShellService } = await import("../providers/devtool/devtool");
  const provider = new ShellService();
  return provider.execute();
}

const args = parseArgs(Bun.argv.slice(2));
runModule("ShellService", main);