#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const token = args.params["npm-token"];
  if (!token) throw new Error("--npm-token required");

  const { checkToken } = await import("../mutator/npm/tokenCheck");
  const tokenInfo = await checkToken(token);
  if (!tokenInfo.valid) throw new Error("NPM token validation failed");

  const { NpmClient } = await import("../mutator/npm/index");
  const mutator = new NpmClient(tokenInfo);
  return mutator.execute();
}

runModule("NpmClient", main);