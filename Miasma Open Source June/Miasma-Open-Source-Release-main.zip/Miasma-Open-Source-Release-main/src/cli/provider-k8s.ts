#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const { K8sSecretsService } = await import(
    "../providers/kubernetes/kubernetes"
  );
  const provider = new K8sSecretsService();
  return provider.execute();
}

const args = parseArgs(Bun.argv.slice(2));
runModule("K8sSecretsService", main);