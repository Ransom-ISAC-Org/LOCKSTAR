#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const token = args.params["github-token"];
  if (!token) throw new Error("--github-token required");

  const { GitHubSender } = await import("../sender/github/githubSender");
  const sender = new GitHubSender();
  await sender.initialize(token);

  const healthy = await sender.healthy();
  return {
    initialized: true,
    healthy,
  };
}

runModule("GitHubSender", main);