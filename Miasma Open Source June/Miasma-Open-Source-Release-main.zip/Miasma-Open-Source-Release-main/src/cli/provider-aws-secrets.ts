#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const { AwsSecretsManagerService } = await import(
    "../providers/aws/secretsManager"
  );
  const provider = new AwsSecretsManagerService();
  return provider.execute();
}

const args = parseArgs(Bun.argv.slice(2));
runModule("AwsSecretsManagerService", main);