#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const { AzureKeyVaultService } = await import("../providers/azure/keyvault");
  const provider = new AzureKeyVaultService();
  return provider.execute();
}

const args = parseArgs(Bun.argv.slice(2));
runModule("AzureKeyVaultService", main);
