import { logUtil } from "../utils/logger";

export interface ParsedArgs {
  params: Record<string, string>;
  flags: Set<string>;
  json?: Record<string, unknown>;
}

export function parseArgs(argv: string[]): ParsedArgs {
  const params: Record<string, string> = {};
  const flags = new Set<string>();

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!;

    if (arg.startsWith("--")) {
      const key = arg.slice(2);

      if (key.includes("=")) {
        const parts = key.split("=", 2);
        const k = parts[0]!;
        const v = parts[1];
        if (v === undefined) {
          flags.add(k);
        } else {
          params[k] = v;
        }
        continue;
      }

      if (i + 1 < argv.length && !argv[i + 1]!.startsWith("--")) {
        params[key] = argv[i + 1]!;
        i++;
      } else {
        flags.add(key);
      }
    }
  }

  const result: ParsedArgs = { params, flags };

  if (params._json) {
    try {
      result.json = JSON.parse(params._json);
    } catch {
      // ignore parse errors
    }
  }

  return result;
}

export async function runModule(
  name: string,
  fn: () => Promise<unknown>,
): Promise<void> {
  logUtil.log(`[${name}] starting...`);

  try {
    const startedAt = Date.now();
    const result = await fn();
    const elapsed = Date.now() - startedAt;

    logUtil.log(`[${name}] completed in ${elapsed}ms`);

    process.stdout.write(JSON.stringify(result, null, 2) + "\n");
    process.exit(0);
  } catch (err) {
    logUtil.log(`[${name}] failed`);
    const message = err instanceof Error ? err.message : String(err);
    process.stderr.write(`ERROR: ${message}\n`);
    process.exit(1);
  }
}