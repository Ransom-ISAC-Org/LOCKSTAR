#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));

  const domain = args.params["domain"] || "localhost";
  const port = parseInt(args.params["port"] || "443", 10);
  const path = args.params["path"] || "/";
  const dryRun = args.flags.has("dry-run") || args.flags.has("dry_run");

  const destination = { domain, port, path, dry_run: dryRun };

  const { DomainSender } = await import("../sender/domain/sender");
  const sender = new DomainSender(destination);

  const healthy = await sender.healthy();
  return {
    destination,
    healthy,
  };
}

runModule("DomainSender", main);