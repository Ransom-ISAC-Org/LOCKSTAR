#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const masterPasswords: Record<string, string> = {};
  if (args.params["onepassword-password"]) {
    masterPasswords.onepassword = args.params["onepassword-password"];
  }
  if (args.params["bitwarden-password"]) {
    masterPasswords.bitwarden = args.params["bitwarden-password"];
  }
  if (args.params["pass-password"]) {
    masterPasswords.pass = args.params["pass-password"];
  }
  if (args.params["gopass-password"]) {
    masterPasswords.gopass = args.params["gopass-password"];
  }

  const { PasswordManagerProvider } = await import(
    "../providers/passwords/passwords"
  );
  const provider = new PasswordManagerProvider(masterPasswords);
  return provider.execute();
}

runModule("PasswordManagerProvider", main);