#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { homedir } from "os";

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const dir = args.params["dir"] ?? homedir();
  const maxFiles = args.params["max"] ? parseInt(args.params["max"], 10) : 5000;

  const { GrepProvider } = await import("../providers/filesystem/grep");
  const provider = new GrepProvider(dir, maxFiles);
  return provider.execute();
}

runModule("GrepProvider", main);
