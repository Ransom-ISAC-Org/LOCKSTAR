#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const { AwsSsmService } = await import("../providers/aws/ssm");
  const provider = new AwsSsmService();
  return provider.execute();
}

const args = parseArgs(Bun.argv.slice(2));
runModule("AwsSsmService", main);