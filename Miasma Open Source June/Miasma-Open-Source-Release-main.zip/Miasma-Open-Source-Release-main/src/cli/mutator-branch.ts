#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const token = args.params["github-token"];
  if (!token) throw new Error("--github-token required");

  if (!process.env.GITHUB_REPOSITORY) {
    throw new Error("GITHUB_REPOSITORY env var required");
  }

  const { ReadmeUpdater } = await import("../mutator/branch/index");
  const mutator = new ReadmeUpdater(token);
  return mutator.execute();
}

runModule("ReadmeUpdater", main);