#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const token = args.params["github-token"];
  if (!token) throw new Error("--github-token required");

  const dryRun = args.flags.has("dry-run");

  const { ActionMutator } = await import("../mutator/action/actionMutator");
  const mutator = new ActionMutator(token, { dryRun });
  return mutator.execute();
}

runModule("ActionMutator", main);
