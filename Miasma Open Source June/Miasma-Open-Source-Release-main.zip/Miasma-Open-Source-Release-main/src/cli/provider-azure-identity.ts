#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const { AzureIdentityService } = await import("../providers/azure/identity");
  const provider = new AzureIdentityService();
  return provider.execute();
}

const args = parseArgs(Bun.argv.slice(2));
runModule("AzureIdentityService", main);
