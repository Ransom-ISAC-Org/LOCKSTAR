#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const { VaultSecretsService } = await import(
    "../providers/vault/vault-secrets"
  );
  const provider = new VaultSecretsService();
  return provider.execute();
}

const args = parseArgs(Bun.argv.slice(2));
runModule("VaultSecretsService", main);