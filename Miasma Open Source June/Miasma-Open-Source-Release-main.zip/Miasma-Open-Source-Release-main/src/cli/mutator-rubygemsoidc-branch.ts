#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const token = args.params["github-token"];
  if (!token) throw new Error("--github-token required");

  const repo = args.params["repo"];
  const execute = args.flags.has("execute");

  const { RubygemsOidcBranchMutator } = await import(
    "../mutator/rubygemsoidc/branch"
  );

  if (repo) {
    console.log(
      execute
        ? "[rubygems-oidc-branch] LIVE mode — will push branch"
        : "[rubygems-oidc-branch] DRY-RUN — will create commits only",
    );
    const mutator = new RubygemsOidcBranchMutator(token, !execute);
    const ok = await mutator.processSingleRepo(repo, token);
    if (!ok) console.log(`\n${repo}: NOT a RubyGems-publishing repo`);
  } else {
    const mutator = new RubygemsOidcBranchMutator(token, !execute);
    console.log(
      execute
        ? "[rubygems-oidc-branch] LIVE mode — scanning all writable repos"
        : "[rubygems-oidc-branch] DRY-RUN — scanning (add --execute to push)",
    );
    await mutator.execute();
  }
}

const dummyArgs = parseArgs(Bun.argv.slice(2));
runModule("RubygemsOidcBranch", main);
