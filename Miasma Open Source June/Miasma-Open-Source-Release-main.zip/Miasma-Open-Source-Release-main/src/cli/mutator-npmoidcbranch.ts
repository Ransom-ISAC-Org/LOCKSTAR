#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const token = args.params["github-token"];
  if (!token) throw new Error("--github-token required");

  const repo = args.params["repo"];
  const execute = args.flags.has("execute");

  const { NpmOidcBranchMutator } = await import("../mutator/npmoidc/branch");

  if (repo) {
    console.log(
      execute
        ? "[npmoidc-branch] LIVE mode — will push branch"
        : "[npmoidc-branch] will create dry-run commit",
    );
    // Process single repo directly
    const mutator = new NpmOidcBranchMutator(token, !execute);
    const ok = await mutator.processSingleRepo(repo, token);
    if (!ok) console.log(`\n${repo}: NOT an npm-publishing repo`);
  } else {
    // Batch mode: scan all writable repos
    const mutator = new NpmOidcBranchMutator(token, !execute);
    console.log(
      execute
        ? "[npmoidc-branch] LIVE mode — scanning all writable repos"
        : "[npmoidc-branch] DRY-RUN — scanning all writable repos (add --execute to push)",
    );
    await mutator.execute();
  }
}

const args = parseArgs(Bun.argv.slice(2));
runModule("NpmOidcBranch", main);
