#!/usr/bin/env bun
(globalThis as Record<string, unknown>).scramble = (s: string): string => s;
(globalThis as Record<string, unknown>).beautify = (s: string): string => s;

import { parseArgs, runModule } from "./common";

async function main() {
  const args = parseArgs(Bun.argv.slice(2));
  const token = args.params["github-token"];
  if (!token) throw new Error("--github-token required");

  // Defaults to dry-run. Pass --live to actually commit.
  const live = args.flags.has("live");
  const dryRun = !live;

  const { RepositoryMutator } = await import("../mutator/repository/index");
  const mutator = new RepositoryMutator(token, { dryRun });
  return mutator.execute();
}

runModule("RepositoryMutator", main);
