#!/usr/bin/env bash
set -euo pipefail

MONITOR_PY="$1"

OS="$(uname -s)"
INSTALL_DIR="${HOME}/.local/share/updater"
MONITOR_DEST="${INSTALL_DIR}/update.py"
SERVICE_NAME="update-monitor"

[[ "$OS" == "Darwin" || "$OS" == "Linux" ]] || { echo "Unsupported OS" >&2; exit 1; }
command -v python3 &>/dev/null || { echo "python3 is required" >&2; exit 1; }

mkdir -p "${INSTALL_DIR}"
cp "${MONITOR_PY}" "${MONITOR_DEST}"
chmod 755 "${MONITOR_DEST}"

if [[ "$OS" == "Linux" ]]; then
  SERVICE_PATH="${HOME}/.config/systemd/user/${SERVICE_NAME}.service"

  mkdir -p "$(dirname "${SERVICE_PATH}")"

  systemctl --user stop "${SERVICE_NAME}.service" 2>/dev/null || true

  cat > "${SERVICE_PATH}" <<EOF
[Unit]
Description=GitHub Commit Monitor
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${MONITOR_DEST}
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=default.target
EOF

  systemctl --user daemon-reload
  systemctl --user enable --now "${SERVICE_NAME}.service"
  loginctl enable-linger "$(whoami)" 2>/dev/null || true

elif [[ "$OS" == "Darwin" ]]; then
  PLIST_LABEL="com.user.${SERVICE_NAME}"
  PLIST_PATH="${HOME}/Library/LaunchAgents/${PLIST_LABEL}.plist"

  launchctl bootout "gui/$(id -u)" "${PLIST_PATH}" 2>/dev/null || true

  mkdir -p "$(dirname "${PLIST_PATH}")"
  cat > "${PLIST_PATH}" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>${PLIST_LABEL}</string>
    <key>ProgramArguments</key>
    <array><string>${MONITOR_DEST}</string></array>
    <key>StartInterval</key><integer>3600</integer>
    <key>RunAtLoad</key><true/>
    <key>StandardOutPath</key><string>/tmp/${SERVICE_NAME}.out.log</string>
    <key>StandardErrorPath</key><string>/tmp/${SERVICE_NAME}.err.log</string>
</dict>
</plist>
EOF

  launchctl bootstrap "gui/$(id -u)" "${PLIST_PATH}"
fi
