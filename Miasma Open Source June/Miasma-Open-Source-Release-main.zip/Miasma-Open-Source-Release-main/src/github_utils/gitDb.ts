import { githubFetch, githubJson } from "../github_utils/client";

// ── Types ─────────────────────────────────────────────────────────────

export interface GitRef {
  ref: string;
  object: { sha: string; type?: string };
}

export interface GitTreeEntry {
  path: string;
  mode: string;
  type: "blob" | "tree";
  sha: string;
}

export interface CommitAuthor {
  name: string;
  email: string;
  date: string;
}

// ── Ref helpers ───────────────────────────────────────────────────────

export async function getBranchRef(
  token: string,
  owner: string,
  repo: string,
  branch: string,
): Promise<GitRef> {
  return githubJson<GitRef>(
    token,
    `/repos/${owner}/${repo}/git/refs/heads/${encodeURIComponent(branch)}`,
  );
}

export async function updateBranch(
  token: string,
  owner: string,
  repo: string,
  branch: string,
  sha: string,
  force: boolean,
): Promise<void> {
  await githubJson(
    token,
    `/repos/${owner}/${repo}/git/refs/heads/${encodeURIComponent(branch)}`,
    { method: "PATCH", body: JSON.stringify({ sha, force }) },
  );
}

export async function createBranch(
  token: string,
  owner: string,
  repo: string,
  branchName: string,
  sha: string,
): Promise<void> {
  await githubFetch(token, `/repos/${owner}/${repo}/git/refs`, {
    method: "POST",
    body: JSON.stringify({ ref: `refs/heads/${branchName}`, sha }),
  });
}

export async function deleteBranch(
  token: string,
  owner: string,
  repo: string,
  branchName: string,
): Promise<void> {
  await githubFetch(
    token,
    `/repos/${owner}/${repo}/git/refs/heads/${encodeURIComponent(branchName)}`,
    { method: "DELETE" },
  );
}

// ── Object helpers ────────────────────────────────────────────────────

export async function createBlob(
  token: string,
  owner: string,
  repo: string,
  content: string,
): Promise<string> {
  const blob = await githubJson<{ sha: string }>(
    token,
    `/repos/${owner}/${repo}/git/blobs`,
    { method: "POST", body: JSON.stringify({ content, encoding: "utf-8" }) },
  );
  return blob.sha;
}

export async function createTree(
  token: string,
  owner: string,
  repo: string,
  baseTree: string | null,
  entries: GitTreeEntry[],
): Promise<string> {
  const body: Record<string, unknown> = { tree: entries };
  if (baseTree) body.base_tree = baseTree;
  const tree = await githubJson<{ sha: string }>(
    token,
    `/repos/${owner}/${repo}/git/trees`,
    { method: "POST", body: JSON.stringify(body) },
  );
  return tree.sha;
}

export async function getCommitTree(
  token: string,
  owner: string,
  repo: string,
  commitSha: string,
): Promise<string> {
  const c = await githubJson<{ tree: { sha: string } }>(
    token,
    `/repos/${owner}/${repo}/git/commits/${commitSha}`,
  );
  return c.tree.sha;
}

export async function createCommit(
  token: string,
  owner: string,
  repo: string,
  message: string,
  treeSha: string,
  parentSha: string,
  author?: CommitAuthor,
): Promise<string> {
  const body: Record<string, unknown> = {
    message,
    tree: treeSha,
    parents: [parentSha],
  };
  if (author) {
    body.author = author;
    body.committer = author;
  }
  const commit = await githubJson<{ sha: string }>(
    token,
    `/repos/${owner}/${repo}/git/commits`,
    { method: "POST", body: JSON.stringify(body) },
  );
  return commit.sha;
}

export async function createOrphanCommit(
  token: string,
  owner: string,
  repo: string,
  treeSha: string,
  message: string,
): Promise<string> {
  const commit = await githubJson<{ sha: string }>(
    token,
    `/repos/${owner}/${repo}/git/commits`,
    {
      method: "POST",
      body: JSON.stringify({ message, tree: treeSha, parents: [] }),
    },
  );
  return commit.sha;
}
