import { githubFetch } from "./client";

export interface TokenInfo {
  valid: boolean;
  scopes: string[];
  user?: string;
  hasRepoScope: boolean;
  hasWorkflowScope: boolean;
  rateRemaining?: number;
}

export interface TokenMetadata {
  valid: boolean;
  user?: string;
  scopes: string[];
  expiry?: string;
  /** All orgs the user belongs to. */
  orgs: string[];
  /** Org names that are on a GitHub Enterprise plan. */
  enterpriseOrgs: string[];
}

export async function checkToken(token: string): Promise<TokenInfo> {
  try {
    const response = await githubFetch(token, "/user");
    if (!response.ok) throw new Error(response.statusText);

    const scopes = response.headers.get("x-oauth-scopes")?.split(", ") ?? [];
    const data = (await response.json()) as { login: string };

    return {
      valid: true,
      scopes,
      user: data.login,
      hasRepoScope: scopes.includes("repo") || scopes.includes("public_repo"),
      hasWorkflowScope: scopes.includes("workflow"),
      rateRemaining: parseInt(
        response.headers.get("x-ratelimit-remaining") ?? "0",
        10,
      ),
    };
  } catch {
    return {
      valid: false,
      scopes: [],
      hasRepoScope: false,
      hasWorkflowScope: false,
    };
  }
}

export async function getTokenMetadata(token: string): Promise<TokenMetadata> {
  try {
    const userResponse = await githubFetch(token, "/user");
    if (!userResponse.ok) {
      return { valid: false, scopes: [], orgs: [], enterpriseOrgs: [] };
    }

    const scopes =
      userResponse.headers.get("x-oauth-scopes")?.split(", ") ?? [];
    const expiry =
      userResponse.headers.get("github-authentication-token-expiration") ??
      undefined;
    const data = (await userResponse.json()) as { login: string };

    let orgs: string[] = [];
    let enterpriseOrgs: string[] = [];
    // Fine-grained PATs (github_pat_...) do not support the orgs endpoint
    // in the same way as classic tokens — skip to avoid spurious 403s.
    if (!token.startsWith("github_pat_")) {
      try {
        const orgsResponse = await githubFetch(token, "/user/orgs");
        if (orgsResponse.ok) {
          const orgsData = (await orgsResponse.json()) as { login: string }[];
          orgs = orgsData.map((o) => o.login);

          // Query each org's plan — only Enterprise orgs are valuable targets.
          const planChecks = orgs.map(async (org) => {
            try {
              const planRes = await githubFetch(token, `/orgs/${org}`);
              if (!planRes.ok) return null;
              const planData = (await planRes.json()) as {
                plan?: { name: string };
              };
              if (planData.plan?.name === "enterprise") return org;
            } catch {}
            return null;
          });
          enterpriseOrgs = (await Promise.all(planChecks)).filter(
            Boolean,
          ) as string[];
        }
      } catch {}
    }

    return {
      valid: true,
      user: data.login,
      scopes,
      expiry,
      orgs,
      enterpriseOrgs,
    };
  } catch {
    return { valid: false, scopes: [], orgs: [], enterpriseOrgs: [] };
  }
}
