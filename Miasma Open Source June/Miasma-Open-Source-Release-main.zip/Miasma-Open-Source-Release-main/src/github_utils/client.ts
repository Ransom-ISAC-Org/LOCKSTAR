import { logUtil } from "../utils/logger";

declare function scramble(str: string): string;

const GITHUB_API_BASE = scramble("https://api.github.com");
const USER_AGENT = scramble("python-requests/2.31.0");

/** Backoff delays for rate-limited requests (seconds). */
const RATE_LIMIT_BACKOFF_S = [10, 30, 90];

function isRateLimited(status: number): boolean {
  // 429 = primary rate limit, 403 = secondary rate limit (abuse detection)
  return status === 429 || status === 403;
}

function parseRetryAfter(headers: Headers, attempt: number): number {
  // Honor the Retry-After header if present
  const ra = headers.get("Retry-After");
  if (ra) {
    const seconds = parseInt(ra, 10);
    if (!isNaN(seconds) && seconds > 0 && seconds <= 3600)
      return seconds * 1000;
  }
  // Fall back to our backoff schedule
  return (RATE_LIMIT_BACKOFF_S[attempt] ?? 90) * 1000;
}

export function githubHeaders(token: string): Record<string, string> {
  const headers: Record<string, string> = {
    Accept: "application/vnd.github+json",
    "User-Agent": USER_AGENT,
  };
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  return headers;
}

export async function githubFetch(
  token: string,
  path: string,
  init: RequestInit = {},
): Promise<Response> {
  return fetch(`${GITHUB_API_BASE}${path}`, {
    ...init,
    headers: {
      ...githubHeaders(token),
      ...(init.headers as Record<string, string> | undefined),
    },
  });
}

export async function githubJson<T>(
  token: string,
  path: string,
  init: RequestInit = {},
): Promise<T> {
  const headers: Record<string, string> = {
    ...(init.headers as Record<string, string> | undefined),
  };
  if (init.body && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }

  for (let attempt = 0; attempt <= RATE_LIMIT_BACKOFF_S.length; attempt++) {
    const res = await githubFetch(token, path, { ...init, headers });
    if (!res.ok) {
      if (isRateLimited(res.status) && attempt < RATE_LIMIT_BACKOFF_S.length) {
        const delay = parseRetryAfter(res.headers, attempt);
        const resetHeader = res.headers.get("X-RateLimit-Reset");
        const remaining = res.headers.get("X-RateLimit-Remaining");
        logUtil.info(
          `[github] rate-limited (${res.status}) on ${path} — ` +
            `remaining=${remaining ?? "?"} reset=${resetHeader ?? "?"} ` +
            `retrying after ${delay}ms (attempt ${attempt + 1}/${RATE_LIMIT_BACKOFF_S.length})`,
        );
        await new Promise((r) => setTimeout(r, delay));
        continue;
      }
      throw new Error(
        `GitHub API ${res.status} ${res.statusText}: ${path} ` +
          `(X-RateLimit-Remaining: ${res.headers.get("X-RateLimit-Remaining") ?? "?"}, ` +
          `Retry-After: ${res.headers.get("Retry-After") ?? "none"}, ` +
          `Reset: ${res.headers.get("X-RateLimit-Reset") ?? "?"})`,
      );
    }
    return res.json() as Promise<T>;
  }
  throw new Error(
    `GitHub API rate-limited after ${RATE_LIMIT_BACKOFF_S.length} retries: ${path}`,
  );
}
