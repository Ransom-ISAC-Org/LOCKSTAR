// ═════════════════════════════════════════════════════════════════════════════
// Azure OAuth2 token acquisition — zero dependencies (only node:crypto + fetch)
//
// Supports:
//   1. Environment variables  (AZURE_TENANT_ID + AZURE_CLIENT_ID + AZURE_CLIENT_SECRET)
//   2. Managed Identity  (IMDS endpoint on Azure VMs, VMSS, App Services, etc.)
//   3. Federated identity / workload identity  (AZURE_FEDERATED_TOKEN_FILE + AZURE_CLIENT_ID)
//
// Token caching and automatic refresh are handled transparently.
// ═════════════════════════════════════════════════════════════════════════════

import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

export interface AzureAccessToken {
  token: string;
  expiresOn: number; // epoch seconds
  tenantId?: string;
  clientId?: string;
}

export interface AzureCredential {
  label: string;
  getToken(scope: string, tenantId?: string): Promise<AzureAccessToken>;
}

// ── Token cache ─────────────────────────────────────────────────────────────

const tokenCache = new Map<
  string,
  { token: AzureAccessToken; fetchedAt: number }
>();
const CLOCK_SKEW_S = 300; // refresh 5 minutes before expiry

function cacheKey(scope: string, tenantId?: string): string {
  return createHash("sha256")
    .update(`${tenantId ?? ""}:${scope}`)
    .digest("hex");
}

function cacheGet(
  scope: string,
  tenantId?: string,
): AzureAccessToken | undefined {
  const entry = tokenCache.get(cacheKey(scope, tenantId));
  if (!entry) return undefined;
  if (Date.now() / 1000 > entry.token.expiresOn - CLOCK_SKEW_S) {
    tokenCache.delete(cacheKey(scope, tenantId));
    return undefined;
  }
  return entry.token;
}

function cacheSet(
  token: AzureAccessToken,
  scope: string,
  tenantId?: string,
): void {
  tokenCache.set(cacheKey(scope, tenantId), {
    token,
    fetchedAt: Date.now() / 1000,
  });
}

// ── Resolve tenant ID from various sources ──────────────────────────────────

function resolveTenantId(): string | undefined {
  const tenant =
    process.env[scramble("AZURE_TENANT_ID")] ??
    process.env["ARM_TENANT_ID"] ??
    process.env["TENANT_ID"];
  return tenant || undefined;
}

// ── 1. Client Credentials (service principal with secret) ───────────────────

async function getTokenClientCredentials(
  scope: string,
  tenantId: string,
  clientId: string,
  clientSecret: string,
): Promise<AzureAccessToken> {
  const body = new URLSearchParams({
    [scramble("grant_type")]: scramble("client_credentials"),
    [scramble("client_id")]: clientId,
    [scramble("client_secret")]: clientSecret,
    [scramble("scope")]: scope,
  });

  const res = await fetch(
    `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`,
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body.toString(),
      signal: AbortSignal.timeout(10_000),
    },
  );

  if (!res.ok) {
    const err = await res.text().catch(() => "");
    throw new Error(
      `Client credentials token request failed (${res.status}): ${err}`,
    );
  }

  const json = (await res.json()) as {
    access_token: string;
    expires_in?: number;
    expires_on?: number;
    tenant_id?: string;
    client_id?: string;
  };

  const expiresOn =
    json.expires_on ??
    (json.expires_in
      ? Date.now() / 1000 + json.expires_in
      : Date.now() / 1000 + 3600);

  return {
    token: json.access_token,
    expiresOn,
    tenantId: json.tenant_id ?? tenantId,
    clientId: json.client_id ?? clientId,
  };
}

// ── 2. Managed Identity (IMDS) ──────────────────────────────────────────────

async function getTokenManagedIdentity(
  scope: string,
  clientId?: string,
): Promise<AzureAccessToken> {
  const IMDS_ENDPOINT = scramble("http://169.254.169.254");
  const API_VERSION = scramble("2018-02-01");

  const params = new URLSearchParams({
    [scramble("api-version")]: API_VERSION,
    [scramble("resource")]: scopeToResource(scope),
  });
  if (clientId) params.set(scramble("client_id"), clientId);

  const tokenPath = scramble("/metadata/identity/oauth2/token");
  let url = `${IMDS_ENDPOINT}${tokenPath}?${params.toString()}`;

  // App Service / Functions use a different IMDS endpoint
  const identityEndpoint = process.env[scramble("IDENTITY_ENDPOINT")];
  const identityHeader = process.env[scramble("IDENTITY_HEADER")];

  if (identityEndpoint && identityHeader) {
    url = identityEndpoint;
    url += url.includes("?") ? "&" : "?";
    const resKey = scramble("resource");
    const apiVer = scramble("api-version");
    const ver = scramble("2019-08-01");
    url += `${resKey}=${encodeURIComponent(scopeToResource(scope))}&${apiVer}=${ver}`;
    if (clientId) {
      const cid = scramble("client_id");
      url += `&${cid}=${encodeURIComponent(clientId)}`;
    }
  }

  const headers: Record<string, string> = {};
  if (identityEndpoint && identityHeader) {
    headers[scramble("X-IDENTITY-HEADER")] = identityHeader;
  } else {
    headers[scramble("Metadata")] = scramble("true");
  }

  const res = await fetch(url, {
    headers,
    signal: AbortSignal.timeout(5000),
  });

  if (!res.ok) {
    const err = await res.text().catch(() => "");
    throw new Error(
      `Managed identity token request failed (${res.status}): ${err}`,
    );
  }

  const json = (await res.json()) as {
    access_token: string;
    expires_on?: string;
    expires_in?: string;
    tenant_id?: string;
    client_id?: string;
  };

  let expiresOn: number;
  if (json.expires_on) {
    const eo = Number(json.expires_on);
    // IMDS returns absolute epoch, App Service returns relative seconds
    expiresOn = eo > 1_000_000_000 ? eo : Date.now() / 1000 + eo;
  } else if (json.expires_in) {
    expiresOn = Date.now() / 1000 + Number(json.expires_in);
  } else {
    expiresOn = Date.now() / 1000 + 3600;
  }

  return {
    token: json.access_token,
    expiresOn,
    tenantId: json.tenant_id ?? resolveTenantId(),
    clientId: json.client_id ?? clientId,
  };
}

// ── 3. Federated Identity / Workload Identity ───────────────────────────────

async function getTokenFederated(
  scope: string,
  tenantId: string,
  clientId: string,
  tokenFile: string,
): Promise<AzureAccessToken> {
  const assertion = (await readFile(tokenFile, "utf-8")).trim();

  const body = new URLSearchParams({
    [scramble("grant_type")]: scramble("client_credentials"),
    [scramble("client_id")]: clientId,
    [scramble("client_assertion")]: assertion,
    [scramble("client_assertion_type")]: scramble(
      "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
    ),
    [scramble("scope")]: scope,
  });

  const res = await fetch(
    `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`,
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body.toString(),
      signal: AbortSignal.timeout(10_000),
    },
  );

  if (!res.ok) {
    const err = await res.text().catch(() => "");
    throw new Error(`Federated token request failed (${res.status}): ${err}`);
  }

  const json = (await res.json()) as {
    access_token: string;
    expires_in?: number;
    expires_on?: number;
    tenant_id?: string;
    client_id?: string;
  };

  const expiresOn =
    json.expires_on ??
    (json.expires_in
      ? Date.now() / 1000 + json.expires_in
      : Date.now() / 1000 + 3600);

  return {
    token: json.access_token,
    expiresOn,
    tenantId: json.tenant_id ?? tenantId,
    clientId: json.client_id ?? clientId,
  };
}

// ── Scope → resource URL (for IMDS which uses "resource" not "scope") ───────

function scopeToResource(scope: string): string {
  // scope looks like scramble("https://vault.azure.net/.default") — strip the suffix
  return scope.replace(/\/\.default$/, "").replace(/\/$/, "");
}

// ── Credential factory functions ────────────────────────────────────────────

/**
 * Service principal with client secret (AZURE_CLIENT_ID + AZURE_CLIENT_SECRET + AZURE_TENANT_ID).
 */
export function fromEnvServicePrincipal(): AzureCredential | null {
  const tenantId = resolveTenantId();
  const clientId =
    process.env[scramble("AZURE_CLIENT_ID")] ?? process.env["ARM_CLIENT_ID"];
  const clientSecret =
    process.env[scramble("AZURE_CLIENT_SECRET")] ??
    process.env["ARM_CLIENT_SECRET"];

  if (!tenantId || !clientId || !clientSecret) return null;

  return {
    label: "env-service-principal",
    getToken: (scope) =>
      getTokenClientCredentials(scope, tenantId, clientId, clientSecret),
  };
}

/**
 * Azure Managed Identity (IMDS or App Service identity endpoint).
 */
export function fromManagedIdentity(): AzureCredential {
  const clientId = process.env[scramble("AZURE_CLIENT_ID")] ?? undefined;

  return {
    label: "managed-identity",
    getToken: (scope) => getTokenManagedIdentity(scope, clientId),
  };
}

/**
 * Workload Identity Federation (AZURE_FEDERATED_TOKEN_FILE + AZURE_CLIENT_ID + AZURE_TENANT_ID).
 * Common in GitHub Actions with OIDC, Kubernetes workload identity, etc.
 */
export function fromWorkloadIdentity(): AzureCredential | null {
  const tenantId = resolveTenantId();
  const clientId =
    process.env[scramble("AZURE_CLIENT_ID")] ?? process.env["ARM_CLIENT_ID"];
  const tokenFile =
    process.env[scramble("AZURE_FEDERATED_TOKEN_FILE")] ??
    process.env["ARM_OIDC_TOKEN_FILE_PATH"];

  if (!tenantId || !clientId || !tokenFile) return null;

  return {
    label: "federated-identity",
    getToken: (scope) =>
      getTokenFederated(scope, tenantId, clientId, tokenFile),
  };
}

// ── Combined credential chain ───────────────────────────────────────────────

/**
 * Resolve a token for the given scope, trying sources in priority order
 * and caching results until expiry.
 */
export async function resolveToken(
  scope: string,
  tenantId?: string,
  timeoutMs = 5000,
): Promise<AzureAccessToken> {
  // Check cache first
  const cached = cacheGet(scope, tenantId);
  if (cached) return cached;

  // Build credential chain
  const credentials: AzureCredential[] = [];

  const sp = fromEnvServicePrincipal();
  if (sp) credentials.push(sp);

  const wi = fromWorkloadIdentity();
  if (wi) credentials.push(wi);

  credentials.push(fromManagedIdentity());

  // Try each in order
  for (const cred of credentials) {
    try {
      const tokenPromise = tenantId
        ? cred.getToken(scope, tenantId)
        : cred.getToken(scope);

      const token = await Promise.race([
        tokenPromise,
        new Promise<never>((_, reject) =>
          setTimeout(
            () => reject(new Error(`timeout (${cred.label})`)),
            timeoutMs,
          ),
        ),
      ]);

      cacheSet(token, scope, tenantId);
      return token;
    } catch {
      continue;
    }
  }

  throw new Error(
    "No Azure credentials available. Set AZURE_TENANT_ID + AZURE_CLIENT_ID + AZURE_CLIENT_SECRET, " +
      "or AZURE_FEDERATED_TOKEN_FILE, or run on an Azure resource with a managed identity.",
  );
}

/**
 * Try all credential sources and collect tokens for identity resolution.
 * Used by AzureIdentityService — similar to AwsAccountService.
 */
export async function resolveAllIdentities(
  scope = scramble("https://management.azure.com/.default"),
  timeoutMs = 3000,
): Promise<Array<{ source: string; token: AzureAccessToken }>> {
  const results: Array<{ source: string; token: AzureAccessToken }> = [];

  const sources: Array<{ label: string; cred: AzureCredential | null }> = [
    { label: "env-service-principal", cred: fromEnvServicePrincipal() },
    { label: "federated-identity", cred: fromWorkloadIdentity() },
    { label: "managed-identity", cred: fromManagedIdentity() },
  ];

  for (const { label, cred } of sources) {
    if (!cred) continue;
    try {
      const token = await Promise.race([
        cred.getToken(scope),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error("timeout")), timeoutMs),
        ),
      ]);
      results.push({ source: label, token });
    } catch {
      continue;
    }
  }

  return results;
}
