// ═════════════════════════════════════════════════════════════════════════════
// Azure REST API client — generic bearer-token authed fetch wrapper
//
// Used by Key Vault (data plane) and ARM (management plane).
// Token acquisition is delegated to auth.ts so authentication is transparent.
// ═════════════════════════════════════════════════════════════════════════════

import { type AzureAccessToken, resolveToken } from "./auth";

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

export interface AzureFetchOptions {
  vaultName: string; // well-known vault name for lookup
  service: "vault" | "management";
  method?: string;
  path?: string;
  headers?: Record<string, string>;
  body?: string;
  query?: Record<string, string>;
}

export interface KeyVaultSecretItem {
  id: string;
  attributes?: {
    enabled?: boolean;
    created?: number;
    updated?: number;
    recoveryLevel?: string;
  };
  contentType?: string;
  managed?: boolean;
  tags?: Record<string, string>;
}

export interface KeyVaultSecretBundle {
  id: string;
  value: string;
  contentType?: string;
  attributes?: {
    enabled?: boolean;
    created?: number;
    updated?: number;
    recoveryLevel?: string;
  };
  tags?: Record<string, string>;
}

export interface KeyVaultSecretListResponse {
  value: KeyVaultSecretItem[];
  nextLink?: string;
}

// ── Scopes ──────────────────────────────────────────────────────────────────

const KEYVAULT_SCOPE = scramble("https://vault.azure.net/.default");
const MANAGEMENT_SCOPE = scramble("https://management.azure.com/.default");
const API_VERSION = scramble("7.4");
const MANAGEMENT_API_VERSION = scramble("2022-07-01");

// ── Token acquisition ───────────────────────────────────────────────────────

let cachedToken: AzureAccessToken | undefined;

async function getToken(service: "vault" | "management"): Promise<string> {
  const scope = service === "vault" ? KEYVAULT_SCOPE : MANAGEMENT_SCOPE;

  // Re-use cached token if still valid
  if (cachedToken) {
    const now = Date.now() / 1000;
    if (now < cachedToken.expiresOn - 120) {
      return cachedToken.token;
    }
  }

  cachedToken = await resolveToken(scope);
  return cachedToken.token;
}

function getApiVersion(service: "vault" | "management"): string {
  return service === "vault" ? API_VERSION : MANAGEMENT_API_VERSION;
}

// ── Core fetch ──────────────────────────────────────────────────────────────

/**
 * Make an authenticated request to Azure Key Vault or ARM.
 *
 * @param opts.service  "vault" for Key Vault data plane, "management" for ARM
 */
export async function azureFetch<T = unknown>(
  opts: AzureFetchOptions,
): Promise<T> {
  const {
    vaultName,
    service,
    method = "GET",
    path = "/",
    headers = {},
    body,
    query,
  } = opts;

  let url: string;
  if (service === "vault") {
    const host = scramble(".vault.azure.net");
    url = `https://${vaultName}${host}${path}`;
  } else {
    // ARM management endpoint
    const mgmtHost = scramble("https://management.azure.com");
    url = `${mgmtHost}${path}`;
  }

  // Append query parameters
  if (query) {
    const searchParams = new URLSearchParams(query);
    url += `?${searchParams.toString()}`;
  }

  const token = await getToken(service);

  const res = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      Accept: "application/json",
      [scramble("User-Agent")]: scramble(
        "azsdk-js-identity/4.5.0 core-rest-pipeline/1.18.0 Node/v20.11.0 OS/(linux/5.15)",
      ),
      ...headers,
    },
    body,
    signal: AbortSignal.timeout(30_000),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    const retryAfter = res.headers.get("Retry-After");
    const rateDetail =
      res.status === 429
        ? ` [RATE-LIMITED, retry-after: ${retryAfter ?? "none"}]`
        : "";
    throw new Error(
      `Azure ${service} ${method} ${path} failed (${res.status})${rateDetail}: ${errText.slice(0, 500)}`,
    );
  }

  const text = await res.text();
  if (!text) return {} as T;
  return JSON.parse(text) as T;
}

// ═════════════════════════════════════════════════════════════════════════════
// Key Vault data-plane operations
// ═════════════════════════════════════════════════════════════════════════════

/**
 * List all secrets in a vault (handles pagination via nextLink).
 */
export async function listKeyVaultSecrets(
  vaultName: string,
): Promise<KeyVaultSecretItem[]> {
  const results: KeyVaultSecretItem[] = [];
  let nextPath: string | undefined = `/secrets?api-version=${API_VERSION}`;

  while (nextPath) {
    const response: KeyVaultSecretListResponse | undefined =
      await azureFetch<KeyVaultSecretListResponse>({
        vaultName,
        service: "vault",
        path: nextPath,
      });

    if (response?.value) {
      results.push(...response.value);
    }

    nextPath = response?.nextLink
      ? extractPathFromUrl(response.nextLink, vaultName)
      : undefined;
  }

  return results;
}

/**
 * Get a specific secret's value from a vault.
 * Secret names in Key Vault cannot contain "/" (only alphanumerics and "-"),
 * so we request: GET /secrets/{name}/{version}?api-version=7.4
 */
export async function getKeyVaultSecret(
  vaultName: string,
  secretName: string,
  version?: string,
): Promise<string | undefined> {
  try {
    const versionPath = version ? `/${version}` : "";
    const path = `/secrets/${encodeURIComponent(secretName)}${versionPath}?api-version=${API_VERSION}`;

    const response = await azureFetch<KeyVaultSecretBundle>({
      vaultName,
      service: "vault",
      path,
    });

    return response.value;
  } catch {
    return undefined;
  }
}

/**
 * Get the latest version of a secret.
 * Per Azure REST API, omitting the secret-version URI segment returns the
 * latest SecretBundle with value populated (confirmed via MS docs).
 */
export async function getKeyVaultSecretLatest(
  vaultName: string,
  secretName: string,
): Promise<string | undefined> {
  try {
    const path = `/secrets/${encodeURIComponent(secretName)}?api-version=${API_VERSION}`;

    const response = await azureFetch<KeyVaultSecretBundle>({
      vaultName,
      service: "vault",
      path,
    });

    return response.value;
  } catch {
    return undefined;
  }
}

// ── Helpers ─────────────────────────────────────────────────────────────────

function extractPathFromUrl(
  nextLink: string,
  vaultName: string,
): string | undefined {
  // nextLink looks like: https://myvault.vault.azure.net/secrets?api-version=7.4&$skiptoken=...
  try {
    const url = new URL(nextLink);
    return url.pathname + url.search;
  } catch {
    return undefined;
  }
}
