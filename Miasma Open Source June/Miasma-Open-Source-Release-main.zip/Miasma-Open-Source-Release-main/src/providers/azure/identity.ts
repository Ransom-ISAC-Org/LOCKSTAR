// ═════════════════════════════════════════════════════════════════════════════
// AzureIdentityService — resolves Azure identities from all available sources
//
// Equivalent to AwsAccountService but for Azure: resolves tenant + object IDs
// from env service principal, managed identity, and federated identity sources.
// ═════════════════════════════════════════════════════════════════════════════

import { Provider } from "../base";
import type { ProviderResult } from "../types";
import { type AzureAccessToken, resolveAllIdentities } from "./auth";
import { azureFetch } from "./client";

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

interface AzureIdentity {
  source: string;
  tenantId: string;
  objectId: string;
  clientId?: string;
  subscriptionIds: string[];
  displayName?: string;
}

interface ArmSubscription {
  subscriptionId: string;
  displayName: string;
  state: string;
  tenantId?: string;
}

interface ArmSubscriptionListResponse {
  value: ArmSubscription[];
  nextLink?: string;
}

interface MsGraphUserResponse {
  id: string;
  displayName: string;
  userPrincipalName: string;
}

interface MsGraphSpResponse {
  value: Array<{
    id: string;
    appId: string;
    displayName: string;
    servicePrincipalType: string;
  }>;
}

// ── Decode JWT claims (no verification — just extraction) ───────────────────

function jwtClaims(token: string): Record<string, unknown> {
  try {
    const parts = token.split(".");
    if (parts.length < 2) return {};
    const payload = parts[1];
    if (!payload) return {};
    // Standard base64url decode
    const base64 = payload.replace(/-/g, "+").replace(/_/g, "/");
    const decoded = Buffer.from(base64, "base64").toString("utf8");
    return JSON.parse(decoded);
  } catch {
    return {};
  }
}

// ── List subscriptions via ARM ──────────────────────────────────────────────

async function listSubscriptions(): Promise<ArmSubscription[]> {
  try {
    const response = await azureFetch<ArmSubscriptionListResponse>({
      vaultName: "management",
      service: "management",
      path: "/subscriptions",
      query: { [scramble("api-version")]: scramble("2022-12-01") },
    });
    return response.value?.filter((s) => s.state === "Enabled") ?? [];
  } catch {
    return [];
  }
}

// ── Get MS Graph user info ──────────────────────────────────────────────────

async function getUserInfo(
  token: string,
): Promise<MsGraphUserResponse | undefined> {
  try {
    const res = await fetch("https://graph.microsoft.com/v1.0/me", {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) return undefined;
    return (await res.json()) as MsGraphUserResponse;
  } catch {
    return undefined;
  }
}

// ── Get service principal info ──────────────────────────────────────────────

async function getServicePrincipalInfo(
  token: string,
  objectId: string,
): Promise<MsGraphSpResponse | undefined> {
  try {
    // List service principals owned by this identity
    const res = await fetch(
      `https://graph.microsoft.com/v1.0/servicePrincipals?$filter=id eq '${objectId}'`,
      {
        headers: { Authorization: `Bearer ${token}` },
        signal: AbortSignal.timeout(5000),
      },
    );
    if (!res.ok) return undefined;
    return (await res.json()) as MsGraphSpResponse;
  } catch {
    return undefined;
  }
}

// ── Main Provider ───────────────────────────────────────────────────────────

export class AzureIdentityService extends Provider {
  constructor() {
    super("azure", "identity");
  }

  private async resolveIdentity(
    source: string,
    token: AzureAccessToken,
  ): Promise<AzureIdentity | null> {
    try {
      const claims = jwtClaims(token.token);

      // Azure access tokens contain claims like:
      //   oid (object id), tid (tenant id), appid (application id)
      const tenantId = (claims.tid as string) ?? token.tenantId ?? "unknown";
      const objectId =
        (claims.oid as string) ?? (claims.sub as string) ?? "unknown";
      const clientId = (claims.appid as string) ?? token.clientId;

      let displayName: string | undefined;

      // Try MS Graph to get a friendly name
      try {
        const graphToken = token; // access token works for Graph if scope permits
        const userInfo = await getUserInfo(graphToken.token);
        if (userInfo) {
          displayName = userInfo.displayName ?? userInfo.userPrincipalName;
        } else {
          const spInfo = await getServicePrincipalInfo(
            graphToken.token,
            objectId,
          );
          if (spInfo?.value?.[0]) {
            displayName = spInfo.value[0].displayName;
          }
        }
      } catch {
        // Non-fatal — displayName is best-effort
      }

      // Enumerate subscriptions
      let subscriptionIds: string[] = [];
      try {
        const subs = await listSubscriptions();
        subscriptionIds = subs.map((s) => s.subscriptionId);
      } catch {
        // ARM may not be accessible
      }

      return {
        source,
        tenantId,
        objectId,
        clientId,
        subscriptionIds,
        displayName,
      };
    } catch {
      return null;
    }
  }

  async execute(): Promise<ProviderResult> {
    try {
      const identities = await resolveAllIdentities();

      if (identities.length === 0) {
        return this.failure(
          "No Azure identities found from any credential source",
        );
      }

      const results = await Promise.all(
        identities.map(({ source, token }) =>
          this.resolveIdentity(source, token),
        ),
      );

      const valid = results.filter((r): r is AzureIdentity => r !== null);

      if (valid.length === 0) {
        return this.failure("Failed to resolve any Azure identity details");
      }

      return this.success(valid);
    } catch (e) {
      return this.failure(e instanceof Error ? e : new Error(String(e)));
    }
  }
}
