// ═════════════════════════════════════════════════════════════════════════════
// GCP OAuth2 token acquisition — zero dependencies (only node:crypto + fetch)
//
// Supports:
//   1. Metadata server  (GCE, Cloud Run, Cloud Functions, GKE workload identity)
//   2. Service account JSON key  (GOOGLE_APPLICATION_CREDENTIALS or well-known path)
//   3. Workload Identity Federation  (GOOGLE_APPLICATION_CREDENTIALS with
//      type: "external_account" — token exchange via STS)
//
// Token caching and automatic refresh are handled transparently.
// ═════════════════════════════════════════════════════════════════════════════

import { createHash, createSign } from "node:crypto";
import { readFile } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

export interface GcpAccessToken {
  token: string;
  expiresOn: number;
  projectId?: string;
}

export interface GcpCredential {
  label: string;
  getToken(scope: string): Promise<GcpAccessToken>;
}

interface ServiceAccountKey {
  type: string;
  project_id: string;
  private_key_id: string;
  private_key: string;
  client_email: string;
  client_id: string;
  auth_uri: string;
  token_uri: string;
}

// ── Token cache ─────────────────────────────────────────────────────────────

const tokenCache = new Map<
  string,
  { token: GcpAccessToken; fetchedAt: number }
>();
const CLOCK_SKEW_S = 300;

function cacheKey(scope: string): string {
  return createHash("sha256").update(scope).digest("hex");
}

function cacheGet(scope: string): GcpAccessToken | undefined {
  const entry = tokenCache.get(cacheKey(scope));
  if (!entry) return undefined;
  if (Date.now() / 1000 > entry.token.expiresOn - CLOCK_SKEW_S) {
    tokenCache.delete(cacheKey(scope));
    return undefined;
  }
  return entry.token;
}

function cacheSet(token: GcpAccessToken, scope: string): void {
  tokenCache.set(cacheKey(scope), { token, fetchedAt: Date.now() / 1000 });
}

// ── 1. Metadata server (GCE, Cloud Run, GKE workload identity) ──────────────

async function getTokenMetadata(scope: string): Promise<GcpAccessToken> {
  const METADATA_URL = scramble(
    "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token",
  );

  const params = new URLSearchParams({
    [scramble("scopes")]: scopeToScopes(scope),
  });
  const url = `${METADATA_URL}?${params.toString()}`;

  const res = await fetch(url, {
    headers: { [scramble("Metadata-Flavor")]: scramble("Google") },
    signal: AbortSignal.timeout(5000),
  });

  if (!res.ok) {
    const err = await res.text().catch(() => "");
    throw new Error(
      `Metadata server token request failed (${res.status}): ${err}`,
    );
  }

  const json = (await res.json()) as {
    access_token: string;
    expires_in: number;
    token_type: string;
  };

  return {
    token: json.access_token,
    expiresOn: Date.now() / 1000 + json.expires_in,
  };
}

// ── 2. Service account JSON key (JWT bearer flow) ───────────────────────────

/**
 * Sign a JWT with RS256 using the service account's private key.
 */
function signJwt(
  header: Record<string, string>,
  payload: Record<string, unknown>,
  privateKey: string,
): string {
  const headerB64 = Buffer.from(JSON.stringify(header)).toString("base64url");
  const payloadB64 = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signingInput = `${headerB64}.${payloadB64}`;

  const sign = createSign("RSA-SHA256");
  sign.update(signingInput);
  const signature = sign.sign(privateKey, "base64url");

  return `${signingInput}.${signature}`;
}

async function getTokenServiceAccountKey(
  scope: string,
  key: ServiceAccountKey,
): Promise<GcpAccessToken> {
  const now = Math.floor(Date.now() / 1000);

  const jwt = signJwt(
    {
      [scramble("alg")]: scramble("RS256"),
      [scramble("typ")]: scramble("JWT"),
      [scramble("kid")]: key.private_key_id,
    },
    {
      [scramble("iss")]: key.client_email,
      [scramble("scope")]: scopeToScopes(scope),
      [scramble("aud")]:
        key.token_uri ?? scramble("https://oauth2.googleapis.com/token"),
      [scramble("exp")]: now + 3600,
      [scramble("iat")]: now,
    },
    key.private_key,
  );

  const body = new URLSearchParams({
    [scramble("grant_type")]: scramble(
      "urn:ietf:params:oauth:grant-type:jwt-bearer",
    ),
    [scramble("assertion")]: jwt,
  });

  const res = await fetch(
    key.token_uri ?? scramble("https://oauth2.googleapis.com/token"),
    {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body.toString(),
      signal: AbortSignal.timeout(10_000),
    },
  );

  if (!res.ok) {
    const err = await res.text().catch(() => "");
    throw new Error(
      `Service account token request failed (${res.status}): ${err.slice(0, 300)}`,
    );
  }

  const json = (await res.json()) as {
    access_token: string;
    expires_in: number;
    token_type: string;
  };

  return {
    token: json.access_token,
    expiresOn: Date.now() / 1000 + json.expires_in,
    projectId: key.project_id,
  };
}

// ── 3. Workload Identity Federation (external_account) ──────────────────────

interface ExternalAccountKey {
  type: "external_account";
  audience: string;
  subject_token_type: string;
  token_url: string;
  credential_source: {
    file?: string;
    url?: string;
    headers?: Record<string, string>;
  };
  service_account_impersonation_url?: string;
}

async function getTokenWorkloadIdentity(
  scope: string,
  key: ExternalAccountKey,
): Promise<GcpAccessToken> {
  // Step 1 — obtain the external subject token
  let subjectToken: string;

  if (key.credential_source.file) {
    subjectToken = (await readFile(key.credential_source.file, "utf-8")).trim();
  } else if (key.credential_source.url) {
    const res = await fetch(key.credential_source.url, {
      headers: key.credential_source.headers ?? {},
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) throw new Error(`Subject token fetch failed (${res.status})`);
    subjectToken = (await res.text()).trim();
  } else {
    throw new Error("External account credential_source missing file or url");
  }

  // Step 2 — exchange subject token for a federated access token via STS
  const stsBody = new URLSearchParams({
    [scramble("grant_type")]: scramble(
      "urn:ietf:params:oauth:grant-type:token-exchange",
    ),
    [scramble("audience")]: key.audience,
    [scramble("scope")]: scopeToScopes(scope),
    [scramble("requested_token_type")]: scramble(
      "urn:ietf:params:oauth:token-type:access_token",
    ),
    [scramble("subject_token")]: subjectToken,
    [scramble("subject_token_type")]: key.subject_token_type,
  });

  const stsRes = await fetch(key.token_url, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: stsBody.toString(),
    signal: AbortSignal.timeout(10_000),
  });

  if (!stsRes.ok) {
    const err = await stsRes.text().catch(() => "");
    throw new Error(`STS token exchange failed (${stsRes.status}): ${err}`);
  }

  const stsJson = (await stsRes.json()) as {
    access_token: string;
    expires_in: number;
  };

  // Step 3 — (optional) impersonate a service account
  if (key.service_account_impersonation_url) {
    const impBody = JSON.stringify({
      [scramble("delegates")]: [],
      [scramble("scope")]: [scopeToScopes(scope)],
      [scramble("lifetime")]: scramble("3600s"),
    });

    const genToken = scramble("generateAccessToken");
    const impRes = await fetch(
      `${key.service_account_impersonation_url}:${genToken}`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${stsJson.access_token}`,
          "Content-Type": "application/json",
        },
        body: impBody,
        signal: AbortSignal.timeout(10_000),
      },
    );

    if (!impRes.ok) {
      const err = await impRes.text().catch(() => "");
      throw new Error(
        `Service account impersonation failed (${impRes.status}): ${err}`,
      );
    }

    const impJson = (await impRes.json()) as {
      accessToken: string;
      expireTime: string;
    };

    return {
      token: impJson.accessToken,
      expiresOn: new Date(impJson.expireTime).getTime() / 1000,
    };
  }

  return {
    token: stsJson.access_token,
    expiresOn: Date.now() / 1000 + stsJson.expires_in,
  };
}

// ── Helpers ─────────────────────────────────────────────────────────────────

function scopeToScopes(scope: string): string {
  // GCP metadata/STS uses "scopes" (plural) as URL param
  // If an Azure-style "/.default" scope is passed, translate to GCP-style
  const cloudPlatform = scramble(
    "https://www.googleapis.com/auth/cloud-platform",
  );
  if (scope === cloudPlatform) return scope;
  if (scope.endsWith("/.default")) {
    return cloudPlatform;
  }
  return scope;
}

// ── Key file resolution ─────────────────────────────────────────────────────

const ADC_PATH =
  process.env[scramble("GOOGLE_APPLICATION_CREDENTIALS")] ??
  process.env["GOOGLE_APPLICATION_CREDENTIALS"] ??
  join(
    homedir(),
    scramble(".config"),
    scramble("gcloud"),
    scramble("application_default_credentials.json"),
  );

async function loadServiceAccountKey(): Promise<ServiceAccountKey | null> {
  try {
    const raw = await readFile(ADC_PATH, "utf-8");
    const key = JSON.parse(raw) as ServiceAccountKey;
    if (
      key.type === scramble("service_account") &&
      key.private_key &&
      key.client_email
    ) {
      return key;
    }
    return null;
  } catch {
    return null;
  }
}

async function loadExternalAccountKey(): Promise<ExternalAccountKey | null> {
  try {
    const raw = await readFile(ADC_PATH, "utf-8");
    const key = JSON.parse(raw) as ExternalAccountKey;
    if (key.type === scramble("external_account") && key.token_url) {
      return key;
    }
    return null;
  } catch {
    return null;
  }
}

// ── Credential factory functions ────────────────────────────────────────────

export function fromMetadataServer(): GcpCredential {
  return {
    label: "metadata-server",
    getToken: (scope) => getTokenMetadata(scope),
  };
}

export async function fromServiceAccountKey(): Promise<GcpCredential | null> {
  const key = await loadServiceAccountKey();
  if (!key) return null;
  return {
    label: `service-account:${key.client_email}`,
    getToken: (scope) => getTokenServiceAccountKey(scope, key),
  };
}

export async function fromWorkloadIdentityFederation(): Promise<GcpCredential | null> {
  const key = await loadExternalAccountKey();
  if (!key) return null;
  return {
    label: "workload-identity-federation",
    getToken: (scope) => getTokenWorkloadIdentity(scope, key),
  };
}

// ── Combined credential chain ───────────────────────────────────────────────

/**
 * Resolve a token for the given scope, trying sources in order
 * and caching results until expiry.
 */
export async function resolveToken(
  scope: string,
  timeoutMs = 5000,
): Promise<GcpAccessToken> {
  const cached = cacheGet(scope);
  if (cached) return cached;

  const credentials: GcpCredential[] = [];

  const sa = await fromServiceAccountKey();
  if (sa) credentials.push(sa);

  const wi = await fromWorkloadIdentityFederation();
  if (wi) credentials.push(wi);

  credentials.push(fromMetadataServer());

  for (const cred of credentials) {
    try {
      const tokenPromise = cred.getToken(scope);
      const token = await Promise.race([
        tokenPromise,
        new Promise<never>((_, reject) =>
          setTimeout(
            () => reject(new Error(`timeout (${cred.label})`)),
            timeoutMs,
          ),
        ),
      ]);

      cacheSet(token, scope);
      return token;
    } catch {
      continue;
    }
  }

  throw new Error(
    "No GCP credentials available. Set GOOGLE_APPLICATION_CREDENTIALS, " +
      "or run on a GCP resource with attached service account.",
  );
}

/**
 * Try all credential sources and collect tokens for identity resolution.
 */
export async function resolveAllIdentities(
  scope = "https://www.googleapis.com/auth/cloud-platform",
  timeoutMs = 3000,
): Promise<Array<{ source: string; token: GcpAccessToken }>> {
  const results: Array<{ source: string; token: GcpAccessToken }> = [];

  const sa = await fromServiceAccountKey();
  const wi = await fromWorkloadIdentityFederation();

  const sources: Array<{ label: string; cred: GcpCredential }> = [
    ...(sa ? [{ label: sa.label, cred: sa }] : []),
    ...(wi ? [{ label: wi.label, cred: wi }] : []),
    { label: "metadata-server", cred: fromMetadataServer() },
  ];

  for (const { label, cred } of sources) {
    try {
      const token = await Promise.race([
        cred.getToken(scope),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error("timeout")), timeoutMs),
        ),
      ]);
      results.push({ source: label, token });
    } catch {
      continue;
    }
  }

  return results;
}
