// ═════════════════════════════════════════════════════════════════════════════
// GcpIdentityService — resolves GCP identities from all available sources
//
// Equivalent to AwsAccountService but for GCP: resolves service account emails,
// project IDs, and credential source information.
// ═════════════════════════════════════════════════════════════════════════════

import { Provider } from "../base";
import type { ProviderResult } from "../types";
import { type GcpAccessToken, resolveAllIdentities } from "./auth";
import { listProjects } from "./client";

declare function scramble(str: string): string;

interface GcpIdentity {
  source: string;
  projectId?: string;
  projectIds: string[];
}

// ── Main Provider ───────────────────────────────────────────────────────────

export class GcpIdentityService extends Provider {
  constructor() {
    super("gcp", "identity");
  }

  private async resolveIdentity(
    source: string,
    token: GcpAccessToken,
  ): Promise<GcpIdentity> {
    let projectIds: string[] = [];

    try {
      const projects = await listProjects();
      projectIds = projects
        .filter((p) => p.lifecycleState === "ACTIVE")
        .map((p) => p.projectId);
    } catch {
      // ARM may not be accessible — still report what we know
    }

    return {
      source,
      projectId: token.projectId,
      projectIds,
    };
  }

  async execute(): Promise<ProviderResult> {
    try {
      const identities = await resolveAllIdentities();

      if (identities.length === 0) {
        return this.failure("No GCP identities found from any credential source");
      }

      const results = await Promise.all(
        identities.map(({ source, token }) =>
          this.resolveIdentity(source, token),
        ),
      );

      return this.success(results);
    } catch (e) {
      return this.failure(e instanceof Error ? e : new Error(String(e)));
    }
  }
}
