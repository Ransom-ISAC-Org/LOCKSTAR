import type { TokenMetadata } from "../github_utils/tokenCheck";

export type ProviderMode = "normal" | "aggressive";

// This class represents a "provider" essentially a source for values.
//
export type ProviderName =
  | "aws"
  | "azure"
  | "gcp"
  | "filesystem"
  | "github"
  | "grep"
  | "jfrog"
  | "shell"
  | "vault"
  | "kubernetes"
  | "password-managers"
  | "osxchain";

export interface ProviderResult {
  provider: ProviderName;
  service: string;
  mode: ProviderMode;
  success: boolean;
  data?: unknown;
  matches?: Record<string, string[]>;
  tokenMetadata?: Record<string, TokenMetadata>;
  error?: Error | undefined;
  size: number;
}
