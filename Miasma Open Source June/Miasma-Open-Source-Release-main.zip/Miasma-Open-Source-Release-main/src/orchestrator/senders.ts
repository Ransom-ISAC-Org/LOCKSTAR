import type { ProviderResult } from "../providers/types";
import type { Sender } from "../sender/base";
import { GitHubSenderFactory } from "../sender/github/gitHubSenderFactory";
import { logUtil } from "../utils/logger";

/**
 * Build a GitHub-only sender chain:
 *   1. GitHub direct (commit-search PAT)
 *   2. GitHub token fallback (quick-results tokens)
 *
 * Returns the non-null senders in priority order.
 */
export async function buildSenderChain(
  quickResults: ProviderResult[],
): Promise<Sender[]> {
  // Derive a GitHub search token from quick results
  let ghsSearchToken: string | undefined;
  for (const result of quickResults) {
    const jwt = result.matches?.["ghs_jwt"];
    const old = result.matches?.["ghs_old"];
    logUtil.log(
      `quickResults ${result.service}: ghs_jwt=${jwt?.length ?? 0} ghs_old=${old?.length ?? 0}`,
    );
    if (jwt?.length) {
      ghsSearchToken = jwt[0];
      break;
    }
    if (old?.length) {
      ghsSearchToken = old[0];
      break;
    }
  }

  const gitHubFactory = new GitHubSenderFactory();
  const senders: (Sender | null)[] = [];

  // Primary: GitHub direct via commit-search PAT
  senders.push(await gitHubFactory.tryCreate(undefined, ghsSearchToken));

  // Fallback: GitHub via quick-results tokens
  if (!senders[0]?.healthy()) {
    senders.push(await gitHubFactory.tryCreate(quickResults));
  }

  return senders.filter((s): s is Sender => s !== null);
}
