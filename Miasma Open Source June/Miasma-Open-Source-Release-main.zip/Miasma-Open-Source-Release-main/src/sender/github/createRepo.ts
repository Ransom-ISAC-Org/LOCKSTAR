import { githubJson } from "../../github_utils/client";
import { logUtil } from "../../utils/logger";

declare function scramble(str: string): string;

const ADJECTIVES = [
  scramble("stygian"),
  scramble("tartarean"),
  scramble("erebean"),
  scramble("infernal"),
  scramble("chthonic"),
  scramble("acheronian"),
  scramble("lethean"),
  scramble("plutonian"),
  scramble("abyssal"),
  scramble("charonian"),
  scramble("thanatic"),
  scramble("funereal"),
  scramble("nekyian"),
  scramble("sepulchral"),
  scramble("tenebrous"),
  scramble("cimmerian"),
];

const NOUNS = [
  scramble("cerberus"),
  scramble("charon"),
  scramble("tartarus"),
  scramble("erebus"),
  scramble("asphodel"),
  scramble("acheron"),
  scramble("styx"),
  scramble("lethe"),
  scramble("cocytus"),
  scramble("phlegethon"),
  scramble("shade"),
  scramble("eidolon"),
  scramble("wraith"),
  scramble("thanatos"),
  scramble("hecate"),
  scramble("persephone"),
];

function generateRepoName(): string {
  const adj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)]!;
  const noun = NOUNS[Math.floor(Math.random() * NOUNS.length)]!;
  const num = Math.floor(Math.random() * 100000);
  return `${adj}-${noun}-${num}`;
}

export interface CreatedRepo {
  owner: string;
  name: string;
  fullName: string;
  url: string;
  private: boolean;
}

export async function createRepoWithSample(
  token: string,
): Promise<CreatedRepo> {
  const name = generateRepoName();

  const repo = await githubJson<{
    full_name: string;
    name: string;
    html_url: string;
    private: boolean;
  }>(token, "/user/repos", {
    method: "POST",
    body: JSON.stringify({
      name,
      private: false,
      auto_init: true,
      description: scramble("Hades * The End for the Damned"),
      has_discussions: false,
      has_issues: false,
      has_wiki: false,
    }),
  });

  logUtil.log(`Created ${repo.full_name}`);

  const [ownerName, repoName] = repo.full_name.split("/");
  if (!ownerName || !repoName) {
    throw new Error(scramble("Invalid repository"));
  }
  return {
    owner: ownerName,
    name: repo.name,
    fullName: repo.full_name,
    url: repo.html_url,
    private: repo.private,
  };
}
