import { createHash, pbkdf2Sync, randomBytes } from "crypto";

class HashStream {
  private counter = 0n;
  private buf: Buffer = Buffer.alloc(0);
  private offset = 0;

  constructor(private key: Buffer) {}

  private refill(): void {
    const h = createHash("sha256");
    h.update(this.key);
    const ctr = Buffer.alloc(8);
    ctr.writeBigUInt64BE(this.counter++);
    h.update(ctr);
    this.buf = h.digest();
    this.offset = 0;
  }

  nextByte(): number {
    if (this.offset >= this.buf.length) this.refill();
    return this.buf[this.offset++]!;
  }

  nextU32(): number {
    return (
      ((this.nextByte() << 24) |
        (this.nextByte() << 16) |
        (this.nextByte() << 8) |
        this.nextByte()) >>>
      0
    );
  }
}

function shuffle256(rng: HashStream): Uint8Array {
  const arr = new Uint8Array(256);
  for (let i = 0; i < 256; i++) arr[i] = i;
  for (let i = 255; i > 0; i--) {
    const bound = 0xffffffff - (0xffffffff % (i + 1));
    let r: number;
    do {
      r = rng.nextU32();
    } while (r > bound);
    const j = r % (i + 1);
    [arr[i], arr[j]] = [arr[j]!, arr[i]!];
  }
  return arr;
}

function xorBytes(a: Buffer, b: Buffer, len: number): Buffer {
  const out = Buffer.alloc(len) as Buffer;
  for (let i = 0; i < len; i++) {
    out[i] = (a[i] ?? 0) ^ (b[i] ?? 0);
  }
  return out;
}

function buildTable(key: Buffer, round: number, pos: number): Uint8Array {
  const posKey = createHash("sha256")
    .update(key)
    .update(Buffer.from([round]))
    .update(Buffer.from(pos.toString()))
    .digest();
  return shuffle256(new HashStream(posKey));
}

function cbcSubstitute(
  data: Buffer,
  roundKey: Buffer,
  round: number,
): Buffer {
  const out = Buffer.alloc(data.length) as Buffer;
  let carry = 0;
  for (let i = 0; i < data.length; i++) {
    const table = buildTable(roundKey, round, i);
    const xored = data[i]! ^ carry;
    out[i] = table[xored]!;
    carry = out[i]!;
  }
  return out;
}

function cbcReverse(
  data: Buffer,
  roundKey: Buffer,
  round: number,
): Buffer {
  const out = Buffer.alloc(data.length) as Buffer;
  let carry = 0;
  for (let i = 0; i < data.length; i++) {
    const table = buildTable(roundKey, round, i);
    const inv = new Uint8Array(256);
    for (let b = 0; b < 256; b++) inv[table[b]!] = b;
    const xored = inv[data[i]!]!;
    out[i] = xored ^ carry;
    carry = data[i]!;
  }
  return out;
}

export class StringScrambler {
  private masterKey: Buffer;
  private rounds: number;

  constructor(passphrase?: string, salt?: string) {
    const pass = passphrase ?? randomBytes(32).toString("hex");
    const s = salt ?? "__SCRAMBLE_DEFAULT_SALT__";
    this.masterKey = pbkdf2Sync(pass, s, 200_000, 32, "sha256");
    this.rounds = 3;
  }

  encode(value: string): string {
    const pt = Buffer.from(value, "utf8");
    const nonce = randomBytes(16);

    const nonceKey = createHash("sha256")
      .update(this.masterKey)
      .update(Buffer.from("n"))
      .digest();
    const encNonce = xorBytes(nonce, nonceKey, 16);

    const roundKey = createHash("sha256")
      .update(this.masterKey)
      .update(encNonce)
      .digest();

    let buf: Buffer = Buffer.from(pt);
    for (let r = 0; r < this.rounds; r++) {
      buf = cbcSubstitute(buf, roundKey, r);
    }

    return Buffer.concat([encNonce, buf]).toString("base64");
  }

  decode(blob: string): string {
    const buf = Buffer.from(blob, "base64");

    const encNonce = buf.subarray(0, 16);
    const nonceKey = createHash("sha256")
      .update(this.masterKey)
      .update(Buffer.from("n"))
      .digest();
    xorBytes(encNonce, nonceKey, 16); // verify nonce decryption works (side-effect free)

    const roundKey = createHash("sha256")
      .update(this.masterKey)
      .update(encNonce)
      .digest();

    let data: Buffer = buf.subarray(16) as Buffer;
    for (let r = this.rounds - 1; r >= 0; r--) {
      data = cbcReverse(data, roundKey, r);
    }

    return data.toString("utf8");
  }
}