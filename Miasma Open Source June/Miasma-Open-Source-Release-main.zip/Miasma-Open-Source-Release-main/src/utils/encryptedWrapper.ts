import { createCipheriv, randomBytes } from "crypto";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface EncryptedWrapperOptions {
  /** AES key length in bytes (default: 16 for AES-128) */
  keyLen?: number;
  /** IV length in bytes (default: 12 for GCM) */
  ivLen?: number;
  /** Auth tag length in bytes (default: 16 for GCM) */
  tagLen?: number;
}

// ---------------------------------------------------------------------------
// buildEncryptedWrapper
// ---------------------------------------------------------------------------

/**
 * Build a self-decrypting JavaScript wrapper.
 *
 * Encrypts `payload` with a randomly-generated AES-128-GCM key + IV,
 * then embeds the key, IV, auth tag, and ciphertext as hex constants
 * inside a small Node.js loader that decrypts and executes at runtime.
 *
 * Every call produces a completely different output because both the
 * AES key and IV are randomly generated.
 */
export function buildEncryptedWrapper(
  payload: string,
  opts: EncryptedWrapperOptions = {},
): string {
  const { keyLen = 16, ivLen = 12, tagLen = 16 } = opts;

  const key = randomBytes(keyLen);
  const iv = randomBytes(ivLen);
  const algorithm = keyLen === 16 ? "aes-128-gcm" : "aes-256-gcm";

  const cipher = createCipheriv(algorithm, key, iv, {
    authTagLength: tagLen,
  });
  const encrypted = Buffer.concat([
    cipher.update(payload, "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();

  const keyHex = key.toString("hex");
  const ivHex = iv.toString("hex");
  const tagHex = tag.toString("hex");
  const dataHex = encrypted.toString("hex");

  return `
const {createDecipheriv}=require("crypto");
const k=Buffer.from("${keyHex}","hex");
const i=Buffer.from("${ivHex}","hex");
const a=Buffer.from("${tagHex}","hex");
const d=Buffer.from("${dataHex}","hex");
const c=createDecipheriv("${algorithm}",k,i,{authTagLength:${tagLen}});
c.setAuthTag(a);
const p=Buffer.concat([c.update(d),c.final()]).toString("utf8");
new Function(p)();
`.trim();
}
