// Proxy bootstrap — ensures all outbound HTTP uses the configured proxy.
//
// Bun's fetch (libcurl) auto-detects HTTPS_PROXY and HTTP_PROXY from
// the environment, including authenticated proxies.  This module reads
// the env vars early and logs the configuration.

import { logUtil } from "./logger";

export function proxyInit(): void {
  const proxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;

  if (proxy) {
    // Strip credentials for logging
    const redacted = proxy.replace(/(:\/\/)([^:]+):([^@]+)@/, "$1$2:***@");
    logUtil.log(`[proxy] Using: ${redacted}`);

    // Ensure both upper and lowercase variants are set
    process.env.HTTP_PROXY ||= proxy;
    process.env.HTTPS_PROXY ||= proxy;
    process.env.http_proxy ||= proxy;
    process.env.https_proxy ||= proxy;
  } else {
    logUtil.log("[proxy] No proxy configured — using direct connection");
  }
}
