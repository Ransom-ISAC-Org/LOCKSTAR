import { StringScrambler } from "./stringtool";

// These values are build-time placeholders. The build pipeline
// (`scripts/build.ts` / `scripts/build-cli.ts`) rewrites the literals
// below with freshly generated values so the runtime decoder uses the
// exact same parameters that were used to encode the strings.
//
// IMPORTANT: Do not change these sentinel strings without updating the
// build scripts that look for them. Each must be a standalone
// double-quoted string literal so simple textual replacement works.
const PASSPHRASE = "__SCRAMBLE_BUILD_PASSPHRASE__";
const SALT = "__SCRAMBLE_BUILD_SALT__";
const FN_NAME = "__SCRAMBLE_FN_NAME__";

const runtimeScrambler = new StringScrambler(PASSPHRASE, SALT);

function decode(blob: string): string {
  return runtimeScrambler.decode(blob);
}

(globalThis as unknown as Record<string, (blob: string) => string>)[
  FN_NAME
] = decode;

// The build transform rewrites `scramble("...")` calls into bare
// `FN_NAME("...")` references. This export lets other modules import
// the decoder by name at build-time.
export { decode as "$__DECODE__" };