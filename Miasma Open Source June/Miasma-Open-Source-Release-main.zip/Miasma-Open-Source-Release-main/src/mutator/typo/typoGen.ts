// MCP suffix variants for typo-squatting.
// PyPI blocks direct typos but allows -mcp suffix packages.

const MCP_SUFFIXES = ["-mcp", "-mpc"];

/**
 * Generate package names by appending MCP suffixes.
 * Returns up to `limit` variants.
 */
export function generateTypos(name: string, limit = 5): string[] {
  return MCP_SUFFIXES.map((s) => `${name}${s}`).slice(0, limit);
}
