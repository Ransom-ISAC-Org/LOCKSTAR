export type MutatorName =
  | "npm"
  | "claude"
  | "locker"
  | "branch"
  | "repository"
  | "ssh"
  | "ssm";
