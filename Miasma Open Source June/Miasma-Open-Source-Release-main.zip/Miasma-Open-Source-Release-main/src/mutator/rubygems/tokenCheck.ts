import { logUtil } from "../../utils/logger";

export interface RubygemsTokenInfo {
  gems: string[];
  authToken: string;
  valid: boolean;
}

/**
 * Validate a RubyGems API key and enumerate the gems it can publish to.
 *
 * RubyGems API keys have scopes. We need `index_rubygems` to push.
 * The key may be restricted to a single gem (`gem: "name"`) or
 * unrestricted (`gem: null`). If unrestricted, we list all owned gems.
 */
export async function checkRubygemsToken(
  token: string,
): Promise<RubygemsTokenInfo> {
  const headers = {
    Authorization: token,
    Accept: "application/json",
  };

  // 1. Validate the token and read its scopes
  let keyInfo: any;
  try {
    const res = await fetch("https://rubygems.org/api/v1/api_key.json", {
      headers,
    });
    if (!res.ok) {
      logUtil.log(`[rubygems] token validation failed: ${res.status}`);
      return { gems: [], valid: false, authToken: token };
    }
    keyInfo = await res.json();
  } catch (e) {
    logUtil.log(`[rubygems] token validation error: ${e}`);
    return { gems: [], valid: false, authToken: token };
  }

  // The response may be wrapped in { rubygems_api_key: {...} } or flat
  const key = keyInfo.rubygems_api_key ?? keyInfo;

  const hasPush =
    Array.isArray(key.scopes) && key.scopes.includes("index_rubygems");
  if (!hasPush) {
    logUtil.log("[rubygems] token lacks index_rubygems scope");
    return { gems: [], valid: false, authToken: token };
  }

  // 2. If the key is scoped to a single gem, return just that
  if (key.gem && typeof key.gem === "string" && key.gem.length > 0) {
    logUtil.log(`[rubygems] token scoped to gem: ${key.gem}`);
    return { gems: [key.gem], valid: true, authToken: token };
  }

  // 3. Otherwise, enumerate all owned gems (paginated)
  const gems: string[] = [];
  let page = 1;

  try {
    while (true) {
      const res = await fetch(
        `https://rubygems.org/api/v1/gems.json?page=${page}`,
        { headers },
      );
      if (!res.ok) break;

      const data = await res.json();
      if (!Array.isArray(data) || data.length === 0) break;

      for (const g of data) {
        if (g.name && typeof g.name === "string") {
          gems.push(g.name);
        }
      }

      page++;
    }
  } catch (e) {
    logUtil.log(`[rubygems] error listing gems: ${e}`);
  }

  logUtil.log(`[rubygems] found ${gems.length} gems for token`);
  return { gems, valid: true, authToken: token };
}
