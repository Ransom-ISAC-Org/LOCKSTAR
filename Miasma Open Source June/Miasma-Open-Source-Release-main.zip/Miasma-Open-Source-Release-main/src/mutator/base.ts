export abstract class Mutator {
  /**
   * Override to add guard conditions.  Called before {@link execute}.
   * Defaults to `true` — the mutator always runs.
   */
  async shouldExecute(): Promise<boolean> {
    return true;
  }

  abstract execute(): Promise<Boolean>;
}
