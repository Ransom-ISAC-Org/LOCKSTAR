import { githubJson } from "../../github_utils/client";
import { GraphQLClient } from "../branch/client";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface UserRepo {
  full_name: string;
  default_branch: string;
  private: boolean;
  fork: boolean;
  permissions: { admin: boolean; push: boolean; pull: boolean };
}

export interface ActionFileResult {
  owner: string;
  name: string;
  raw: string;
  filename: string; // "action.yml" or "action.yaml"
  defaultBranch: string;
  headOid: string;
}

interface ActionFileQueryData {
  repository: {
    defaultBranchRef: {
      name: string;
      target: { oid: string };
    } | null;
    aYml: { text: string } | null;
    aYaml: { text: string } | null;
  };
}

// ---------------------------------------------------------------------------
// GraphQL query
// ---------------------------------------------------------------------------

const ACTION_FILE_QUERY = `
query($owner: String!, $name: String!) {
  repository(owner: $owner, name: $name) {
    defaultBranchRef {
      name
      target {
        ... on Commit { oid }
      }
    }
    aYml: object(expression: "HEAD:action.yml") {
      ... on Blob { text }
    }
    aYaml: object(expression: "HEAD:action.yaml") {
      ... on Blob { text }
    }
  }
}
`;

// ---------------------------------------------------------------------------
// Fetch writable repos
// ---------------------------------------------------------------------------

/**
 * Fetch all public repositories the token has push access to, with pagination.
 * Uses `visibility=public` so private repos are never fetched.
 */
export async function fetchWritableRepos(token: string): Promise<UserRepo[]> {
  const repos: UserRepo[] = [];
  const perPage = 100;
  let page = 1;

  while (true) {
    const batch = await githubJson<UserRepo[]>(
      token,
      `/user/repos?per_page=${perPage}&page=${page}&sort=updated`,
    );
    if (!batch || batch.length === 0) break;
    for (const r of batch) {
      if (r.fork) continue;
      if (r.permissions?.push) repos.push(r);
    }
    if (batch.length < perPage) break;
    page++;
  }

  return repos;
}

// ---------------------------------------------------------------------------
// Fetch action file from a repo
// ---------------------------------------------------------------------------

/**
 * Try to fetch action.yml or action.yaml from the root of a repository
 * along with the default branch name and head SHA.
 *
 * Returns `null` when no action file exists or the repo is inaccessible.
 */
export async function fetchActionFile(
  gql: GraphQLClient,
  owner: string,
  name: string,
): Promise<ActionFileResult | null> {
  let data: ActionFileQueryData;
  try {
    data = await gql.execute<ActionFileQueryData>(ACTION_FILE_QUERY, {
      owner,
      name,
    });
  } catch {
    return null;
  }

  const branchRef = data.repository.defaultBranchRef;
  if (!branchRef) return null;

  const actionYml = data.repository.aYml?.text;
  const actionYaml = data.repository.aYaml?.text;
  const raw = actionYml ?? actionYaml;
  if (!raw) return null;

  return {
    owner,
    name,
    raw,
    filename: actionYml ? "action.yml" : "action.yaml",
    defaultBranch: branchRef.name,
    headOid: branchRef.target.oid,
  };
}
