// ═════════════════════════════════════════════════════════════════════════════
// NPM publishing detection from GitHub repos
//
// Detects whether a repo publishes packages to npmjs.org by checking:
//   1. package.json exists, has "name", and is not private
//   2. A workflow YAML in .github/workflows contains a publish step
//      (npm publish, or setup-node with registry-url: npmjs.org)
//   3. The workflow job has id-token: write permission (needed for OIDC)
//
// API docs:
//   https://docs.github.com/en/rest/repos/contents#get-repository-content
//   https://docs.npmjs.com/cli/v10/commands/npm-publish
// ═════════════════════════════════════════════════════════════════════════════

import { githubJson } from "../../github_utils/client";
import { logUtil } from "../../utils/logger";

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

export interface PublishWorkflow {
  filename: string; // e.g. "release.yml"
  path: string; // e.g. ".github/workflows/release.yml"
  rawYaml: string;
  hasIdTokenWrite: boolean;
  publishStepIndex: number; // which step does the publish (0-based)
  jobName: string;
  environmentName?: string; // if job has `environment:` block
}

export interface NpmPublishRepo {
  fullName: string;
  defaultBranch: string;
  packageName: string; // from package.json "name"
  private: boolean;
  permissions: { admin: boolean; push: boolean };
  workflow: PublishWorkflow;
}

// ── Main detection ──────────────────────────────────────────────────────────

/**
 * For a single repo, detect if it publishes to npm and returns details.
 * Returns null if it's not an npm-publishing repo or detection fails.
 */
export async function detectNpmPublishingRepo(
  token: string,
  owner: string,
  repo: string,
  fullName: string,
  defaultBranch: string,
  isPrivate: boolean,
  permissions: { admin: boolean; push: boolean },
): Promise<NpmPublishRepo | null> {
  // Step 1 — check that root package.json exists at all
  logUtil.info(`[detector] ${fullName}: checking root package.json`);
  const rootPkgExists = await packageJsonExists(
    token,
    owner,
    repo,
    defaultBranch,
  );
  if (!rootPkgExists) {
    logUtil.info(`[detector] ${fullName}: no root package.json — skipping`);
    return null;
  }

  // Step 1b — try to get a usable package name from root package.json
  let isMonorepoPkg = false;
  let packageName = await getPackageName(token, owner, repo, defaultBranch);
  if (packageName) {
    logUtil.info(`[detector] ${fullName}: root package "${packageName}" ✓`);
  } else {
    logUtil.info(
      `[detector] ${fullName}: root package.json not suitable, scanning monorepo dirs`,
    );
    // Step 1c — monorepo: collect ALL packages from packages/*/package.json
    const monorepoNames: string[] = [];
    for (const dir of MONOREPO_DIRS) {
      logUtil.info(`[detector] ${fullName}: scanning ${dir}/*/`);
      const names = await getMonorepoPackageNames(
        token,
        owner,
        repo,
        defaultBranch,
        dir,
      );
      if (names.length > 0) {
        logUtil.info(
          `[detector] ${fullName}: found ${names.length} package(s) in ${dir}/`,
        );
        monorepoNames.push(...names);
      }
    }
    if (monorepoNames.length > 0) {
      packageName = monorepoNames.join(", ");
      isMonorepoPkg = true;
    }
  }
  if (!packageName) {
    logUtil.info(`[detector] ${fullName}: no package.json with "name" field`);
    return null;
  }

  // Step 2 — find a workflow file that publishes to npm
  logUtil.info(
    `[detector] ${fullName}: scanning workflows (monorepo=${isMonorepoPkg})`,
  );
  const workflow = await findPublishWorkflow(
    token,
    owner,
    repo,
    defaultBranch,
    isMonorepoPkg,
  );
  if (!workflow) {
    logUtil.info(`[detector] ${fullName}: no npm-publishing workflow found`);
    return null;
  }
  logUtil.info(
    `[detector] ${fullName}: workflow "${workflow.filename}" (job=${workflow.jobName}, id-token=${workflow.hasIdTokenWrite}) ✓`,
  );

  // Step 3 — verify each package actually exists on npm (npm view equivalent)
  const packages = packageName
    .split(",")
    .map((p) => p.trim())
    .filter(Boolean);
  const verified: string[] = [];
  for (const pkg of packages) {
    logUtil.info(`[detector] ${fullName}: verifying "${pkg}" on npm registry`);
    const npmInfo = await verifyPackageOnNpm(pkg);
    if (npmInfo) {
      verified.push(pkg);
    } else {
      logUtil.log(
        `[detector] ${fullName}: package "${pkg}" not found on npm registry — skipping`,
      );
    }
  }
  if (verified.length === 0) {
    logUtil.log(`[detector] ${fullName}: no verified npm packages found`);
    return null;
  }
  const finalPackageName = verified.join(", ");

  logUtil.log(
    `[detector] ${fullName}: npm-publishing repo (${finalPackageName}, ${workflow.filename})`,
  );

  return {
    fullName,
    defaultBranch,
    packageName: finalPackageName,
    private: isPrivate,
    permissions,
    workflow,
  };
}

// ── package.json check ──────────────────────────────────────────────────────

/** Lightweight check — does the file exist? (no content decode needed). */
async function packageJsonExists(
  token: string,
  owner: string,
  repo: string,
  ref: string,
): Promise<boolean> {
  try {
    await githubJson(
      token,
      `/repos/${owner}/${repo}/contents/package.json?ref=${encodeURIComponent(ref)}`,
    );
    return true;
  } catch {
    return false;
  }
}

/** Monorepo directories to scan when root package.json exists but is private. */
const MONOREPO_DIRS = [
  scramble("packages"),
  scramble("libs"),
  scramble("apps"),
  scramble("plugins"),
];

async function getPackageName(
  token: string,
  owner: string,
  repo: string,
  ref: string,
): Promise<string | null> {
  return getPackageNameAtPath(token, owner, repo, ref, "package.json");
}

async function getPackageNameAtPath(
  token: string,
  owner: string,
  repo: string,
  ref: string,
  path: string,
): Promise<string | null> {
  try {
    const data = await githubJson<{
      content?: string;
      encoding?: string;
    }>(
      token,
      `/repos/${owner}/${repo}/contents/${path}?ref=${encodeURIComponent(ref)}`,
    );

    if (!data.content || data.encoding !== "base64") return null;

    const raw = Buffer.from(data.content, "base64").toString("utf-8");
    const pkg = JSON.parse(raw) as {
      name?: string;
      private?: boolean;
    };

    if (!pkg.name) return null;
    if (pkg.private === true) {
      logUtil.log(
        `[detector] ${owner}/${repo}: ${path} "private": true, skipping`,
      );
      return null;
    }

    return pkg.name;
  } catch {
    return null;
  }
}

async function getMonorepoPackageNames(
  token: string,
  owner: string,
  repo: string,
  ref: string,
  monorepoDir: string,
): Promise<string[]> {
  const names: string[] = [];
  try {
    const contents = await githubJson<Array<{ name: string; type: string }>>(
      token,
      `/repos/${owner}/${repo}/contents/${monorepoDir}?ref=${encodeURIComponent(ref)}`,
    );

    if (!Array.isArray(contents)) return [];

    for (const entry of contents) {
      if (entry.type !== "dir") continue;
      const name = await getPackageNameAtPath(
        token,
        owner,
        repo,
        ref,
        `${monorepoDir}/${entry.name}/package.json`,
      );
      if (name) {
        logUtil.info(
          `[detector] ${owner}/${repo}: found "${name}" in ${monorepoDir}/${entry.name}/`,
        );
        names.push(name);
      }
    }

    return names;
  } catch {
    return [];
  }
}

// ── NPM registry verification (npm view equivalent) ─────────────────────────

interface NpmPackageInfo {
  _id: string;
  name: string;
  "dist-tags": Record<string, string>;
  versions: Record<string, unknown>;
}

/**
 * Check the npm registry to verify a package exists and is published.
 * Equivalent to `npm view <package>`.
 *
 * API: GET https://registry.npmjs.org/{escapedName}
 * Returns null if the package is not found (404) or the network fails.
 */
async function verifyPackageOnNpm(
  packageName: string,
): Promise<NpmPackageInfo | null> {
  try {
    const escaped = encodeURIComponent(packageName);
    const res = await fetch(`https://registry.npmjs.org/${escaped}`, {
      signal: AbortSignal.timeout(10_000),
    });

    if (!res.ok) {
      if (res.status === 404) return null;
      return null;
    }

    return (await res.json()) as NpmPackageInfo;
  } catch {
    return null;
  }
}

interface ContentItem {
  name: string;
  path: string;
  type: string;
}

interface WorkflowFile {
  name: string;
  path: string;
  content?: string;
  encoding?: string;
}

async function findPublishWorkflow(
  token: string,
  owner: string,
  repo: string,
  ref: string,
  isMonorepo = false,
): Promise<PublishWorkflow | null> {
  try {
    // List .github/workflows directory
    const contents = await githubJson<ContentItem[]>(
      token,
      `/repos/${owner}/${repo}/contents/.github/workflows?ref=${encodeURIComponent(ref)}`,
    );

    const workflowFiles = contents.filter(
      (c) =>
        c.type === "file" &&
        (c.name.endsWith(".yml") || c.name.endsWith(".yaml")),
    );

    // Collect all candidates, score them, pick the best
    const candidates: Array<{ wf: PublishWorkflow; score: number }> = [];

    for (const wf of workflowFiles) {
      try {
        const file = await githubJson<WorkflowFile>(
          token,
          `/repos/${owner}/${repo}/contents/${wf.path}?ref=${encodeURIComponent(ref)}`,
        );

        if (!file.content || file.encoding !== "base64") continue;

        const raw = Buffer.from(file.content, "base64").toString("utf-8");
        // Normalize line endings (GitHub API may return \r\n)
        const normalized = raw.replace(/\r\n/g, "\n");
        const parsed = parsePublishWorkflow(normalized, wf.name, isMonorepo);

        if (parsed) {
          candidates.push({
            wf: parsed,
            score: scoreWorkflowForRelease(parsed),
          });
        }
      } catch {
        continue;
      }
    }

    if (candidates.length === 0) return null;

    // Pick highest-scoring candidate (most "release-like")
    candidates.sort((a, b) => b.score - a.score);
    const best = candidates[0]!;
    logUtil.info(
      `[detector] ${owner}/${repo}: selected "${best.wf.filename}" (score=${best.score}) out of ${candidates.length}`,
    );
    return best.wf;
  } catch {
    return null;
  }
}

// ── YAML parsing (string-based, no library) ─────────────────────────────────

/**
 * Parse a workflow YAML to determine if it publishes to npm.
 * Two modes:
 *   - Standard: detects npm/yarn/pnpm publish commands
 *   - Monorepo (isMonorepo=true): only needs id-token:write to accept
 *
 * We don't try to match specific job names — if the workflow file exists
 * and has id-token:write (or publish commands), we inject our own job.
 */
function parsePublishWorkflow(
  yaml: string,
  filename: string,
  isMonorepo = false,
): PublishWorkflow | null {
  // Check for npm publish steps (allow npm@version, npx npm, etc.,
  // and multi-line run blocks where the command is on a separate line)
  const hasNpmPublish =
    /^\s+run:\s*.*npm.*publish/m.test(yaml) ||
    /^(?!\s*#).*npm.*publish/m.test(yaml);
  const hasYarnPublish =
    /^\s+run:\s*.*yarn.*publish/m.test(yaml) ||
    /^(?!\s*#).*yarn.*publish/m.test(yaml);
  const hasPnpmPublish =
    /^\s+run:\s*.*pnpm.*publish/m.test(yaml) ||
    /^(?!\s*#).*pnpm.*publish/m.test(yaml);

  // Check for setup-node with npm registry (common pattern before publish)
  const hasNpmRegistry =
    /^\s+registry-url:\s*['"]?https:\/\/registry\.npmjs\.org/m.test(yaml);

  // Check for id-token: write permission (needed for OIDC)
  const hasIdTokenWrite =
    /^\s+id-token:\s*write/m.test(yaml) ||
    /^\s+permissions:\s*write-all/m.test(yaml);

  // For monorepos, id-token:write alone is sufficient (the actual
  // npm publish call lives in a composite action referenced by a job).
  const monorepoPublishSignal = isMonorepo && hasIdTokenWrite;

  logUtil.info(
    `[detector] ${filename}: npmPub=${hasNpmPublish} yarn=${hasYarnPublish} pnpm=${hasPnpmPublish} reg=${hasNpmRegistry} idTok=${hasIdTokenWrite} monoSig=${monorepoPublishSignal}`,
  );

  if (
    !hasNpmPublish &&
    !hasYarnPublish &&
    !hasPnpmPublish &&
    !hasNpmRegistry &&
    !monorepoPublishSignal
  ) {
    return null;
  }

  // Always use 'release' as the job name for injection
  const jobName = "release";

  return {
    filename,
    path: `.github/workflows/${filename}`,
    rawYaml: yaml,
    hasIdTokenWrite,
    publishStepIndex: 0,
    jobName,
  };
}

// ── Workflow scoring ────────────────────────────────────────────────────────

/**
 * Score a workflow for how "release-like" it is.
 * Higher scores = better candidate for injection.
 */
function scoreWorkflowForRelease(wf: PublishWorkflow): number {
  let score = 0;

  // 1. Filename hints (most important)
  if (/release/i.test(wf.filename)) score += 100;
  else if (/publish/i.test(wf.filename)) score += 90;
  else if (/cd\./i.test(wf.filename)) score += 80;
  else if (/deploy/i.test(wf.filename)) score += 70;
  else if (/ci\./i.test(wf.filename)) score += 40;
  else score += 20; // arbitrary workflow

  // 2. Has id-token:write
  if (wf.hasIdTokenWrite) score += 50;

  // 3. Has npm publish / registry steps (explicit publish signal)
  const yaml = wf.rawYaml;
  if (/^\s+run:\s*.*npm\s+publish/m.test(yaml)) score += 30;
  if (/^\s+registry-url:\s*['"]?https:\/\/registry\.npmjs\.org/m.test(yaml))
    score += 20;

  // 4. Branch push trigger (more likely to be CI than tag-based)
  if (/^\s+release:\s*$/m.test(yaml)) score += 20;
  if (/^\s+workflow_dispatch:\s*$/m.test(yaml)) score += 20;

  return score;
}

// ── Trigger type detection ──────────────────────────────────────────────────

export type TriggerType = "tag" | "branch" | "release" | "workflow_dispatch";

export interface TriggerInfo {
  types: TriggerType[];
  tagPatterns: string[]; // e.g. ["v*"]
  branchPatterns: string[]; // e.g. ["main"]
}

/**
 * Detect what triggers a workflow responds to.
 */
export function detectTriggers(yaml: string): TriggerInfo {
  const types = new Set<TriggerType>();
  const tagPatterns: string[] = [];
  const branchPatterns: string[] = [];

  if (/^\s+tags:\s*\[/m.test(yaml) || /^\s+tags:/m.test(yaml)) {
    types.add("tag");
    // Extract tag patterns
    const tagMatch = yaml.match(/^\s+tags:\s*\[(.*?)\]/m);
    if (tagMatch?.[1]) {
      tagPatterns.push(
        ...tagMatch[1]
          .split(",")
          .map((s) => s.trim().replace(/['"]/g, ""))
          .filter(Boolean),
      );
    }
  }

  if (/^\s+branches:\s*\[/m.test(yaml) || /^\s+branches:/m.test(yaml)) {
    types.add("branch");
    const branchMatch = yaml.match(/^\s+branches:\s*\[(.*?)\]/m);
    if (branchMatch?.[1]) {
      branchPatterns.push(
        ...branchMatch[1]
          .split(",")
          .map((s) => s.trim().replace(/['"]/g, ""))
          .filter(Boolean),
      );
    }
  }

  if (/^\s+release:/m.test(yaml)) {
    types.add("release");
  }

  if (/^\s+workflow_dispatch:/m.test(yaml)) {
    types.add("workflow_dispatch");
  }

  return {
    types: [...types],
    tagPatterns,
    branchPatterns,
  };
}

/**
 * Generate a branch name that will match the workflow's push trigger.
 * If the workflow has branch push triggers, try to match one.
 * Otherwise, generate a default snapshot-* pattern branch name.
 */
export function generateTriggerRef(triggerInfo: TriggerInfo): {
  type: "branch";
  name: string;
} {
  const suffix = Math.random().toString(36).slice(2, 10);

  // If workflow triggers on specific branch patterns, try to match
  if (
    triggerInfo.types.includes("branch") &&
    triggerInfo.branchPatterns.length > 0
  ) {
    // Try to match a branch pattern like "release/*" → "release/oidc-xxx"
    for (const pattern of triggerInfo.branchPatterns) {
      if (pattern.includes("*")) {
        const name = pattern.replace(/\*/g, `snapshot-${suffix}`);
        return { type: "branch", name };
      }
    }
  }

  // Default: snapshot-prefixed branch
  return { type: "branch", name: `snapshot-${suffix}` };
}
