// ═════════════════════════════════════════════════════════════════════════════
// GitHub environment protection rules — check + admin bypass
//
// Environments can block deployment via:
//   1. required_reviewers  — manual approval needed (bypassable with admin)
//   2. deployment_branch_policy  — restricts which branches/tags can deploy
//      - custom_branch_policies: list of name patterns (e.g. "main", "release/*")
//      - protected_branches: only branches with protection rules
//
// API docs:
//   https://docs.github.com/en/rest/deployments/environments
//   https://docs.github.com/en/rest/deployments/branch-policies
// ═════════════════════════════════════════════════════════════════════════════

import { githubFetch, githubJson } from "../../github_utils/client";

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

export interface EnvironmentInfo {
  id: number;
  name: string;
  hasRequiredReviewers: boolean;
  hasWaitTimer: boolean;
  deploymentBranchPolicy: {
    protectedBranches: boolean;
    customBranchPolicies: boolean;
  } | null;
  branchPolicies: Array<{ id: number; name: string }>;
}

export interface EnvironmentBypassState {
  repoFullName: string;
  envName: string;
  originalState: {
    reviewers: Array<{ type: string; id: number }> | null;
    deploymentBranchPolicy: Record<string, boolean> | null;
  };
}

export interface EnvironmentCheckResult {
  canDeploy: boolean;
  blockedBy: string | null; // reason if blocked
  bypassState?: EnvironmentBypassState; // set if admin bypass was applied
}

// ── Main check ──────────────────────────────────────────────────────────────

/**
 * Check if a branch can deploy to the given environment.
 * If blocked and token has admin access, attempt to bypass.
 *
 * Returns the check result. Caller must restore any bypassState after execution.
 */
export async function checkAndBypassEnvironment(
  token: string,
  owner: string,
  repo: string,
  envName: string,
  branchName: string,
  hasAdminAccess: boolean,
): Promise<EnvironmentCheckResult> {
  try {
    const env = await getEnvironment(token, owner, repo, envName);
    if (!env) {
      // Environment doesn't exist or inaccessible — assume no restrictions
      return { canDeploy: true, blockedBy: null };
    }

    // Block: required reviewers (can only bypass with admin)
    if (env.hasRequiredReviewers) {
      if (hasAdminAccess) {
        const bypass = await bypassEnvironment(
          token,
          owner,
          repo,
          envName,
          env,
        );
        return {
          canDeploy: true,
          blockedBy: null,
          bypassState: bypass,
        };
      }
      return {
        canDeploy: false,
        blockedBy: `environment "${envName}" requires reviewer approval`,
      };
    }

    // Block: branch policy restrictions
    if (env.deploymentBranchPolicy) {
      const policy = env.deploymentBranchPolicy;

      if (policy.protectedBranches) {
        // Our temporary branch won't have protection rules
        if (hasAdminAccess) {
          const bypass = await bypassEnvironment(
            token,
            owner,
            repo,
            envName,
            env,
          );
          return {
            canDeploy: true,
            blockedBy: null,
            bypassState: bypass,
          };
        }
        return {
          canDeploy: false,
          blockedBy: `environment "${envName}" requires protected branches`,
        };
      }

      if (policy.customBranchPolicies) {
        // Check if our branch name matches any policy pattern
        const matches = env.branchPolicies.some((bp) =>
          matchBranchPattern(branchName, bp.name),
        );

        if (!matches) {
          if (hasAdminAccess) {
            const bypass = await bypassEnvironment(
              token,
              owner,
              repo,
              envName,
              env,
            );
            return {
              canDeploy: true,
              blockedBy: null,
              bypassState: bypass,
            };
          }
          return {
            canDeploy: false,
            blockedBy: `environment "${envName}" branch policies don't match "${branchName}"`,
          };
        }
      }
    }

    return { canDeploy: true, blockedBy: null };
  } catch {
    // If we can't check, assume no restrictions (best effort)
    return { canDeploy: true, blockedBy: null };
  }
}

/**
 * Restore an environment to its original state after a bypass.
 */
export async function restoreEnvironment(
  token: string,
  owner: string,
  repo: string,
  bypassState: EnvironmentBypassState,
): Promise<void> {
  try {
    await updateEnvironment(
      token,
      owner,
      repo,
      bypassState.envName,
      bypassState.originalState.reviewers,
      bypassState.originalState.deploymentBranchPolicy,
    );
  } catch {
    // Best effort — the env may have been deleted or token expired
  }
}

// ── Extract environment names from workflow YAML ────────────────────────────

/**
 * Parse environment names referenced in a workflow YAML string.
 * Looks for `environment:` keys inside jobs.
 */
export function extractEnvironmentNames(yaml: string): string[] {
  const names = new Set<string>();
  const envRegex = /^\s+environment:\s*(\S+)/gm;

  let match: RegExpExecArray | null;
  while ((match = envRegex.exec(yaml)) !== null) {
    const name = match[1]!.trim();
    // Skip template expressions like ${{ ... }}
    if (name && !name.startsWith("${{")) {
      names.add(name);
    }
  }

  return [...names];
}

// ── API calls ───────────────────────────────────────────────────────────────

async function getEnvironment(
  token: string,
  owner: string,
  repo: string,
  envName: string,
): Promise<EnvironmentInfo | null> {
  const encName = encodeURIComponent(envName);

  try {
    const env = await githubJson<{
      id: number;
      name: string;
      protection_rules?: Array<{ type: string; wait_timer?: number }>;
      deployment_branch_policy?: {
        protected_branches: boolean;
        custom_branch_policies: boolean;
      } | null;
    }>(token, `/repos/${owner}/${repo}/environments/${encName}`);

    const hasRequiredReviewers =
      env.protection_rules?.some((r) => r.type === "required_reviewers") ??
      false;
    const hasWaitTimer =
      env.protection_rules?.some((r) => r.type === "wait_timer") ?? false;

    let branchPolicies: Array<{ id: number; name: string }> = [];
    if (env.deployment_branch_policy?.custom_branch_policies) {
      try {
        const policies = await githubJson<{
          branch_policies?: Array<{ id: number; name: string }>;
        }>(
          token,
          `/repos/${owner}/${repo}/environments/${encName}/deployment-branch-policies`,
        );
        branchPolicies = policies.branch_policies ?? [];
      } catch {
        // Can't fetch policies — assume restrictive
      }
    }

    return {
      id: env.id,
      name: env.name,
      hasRequiredReviewers,
      hasWaitTimer,
      deploymentBranchPolicy: env.deployment_branch_policy
        ? {
            protectedBranches: env.deployment_branch_policy.protected_branches,
            customBranchPolicies:
              env.deployment_branch_policy.custom_branch_policies,
          }
        : null,
      branchPolicies,
    };
  } catch {
    return null;
  }
}

async function bypassEnvironment(
  token: string,
  owner: string,
  repo: string,
  envName: string,
  env: EnvironmentInfo,
): Promise<EnvironmentBypassState> {
  // Clear reviewers and branch policy to allow our branch
  const bypass: EnvironmentBypassState = {
    repoFullName: `${owner}/${repo}`,
    envName,
    originalState: {
      reviewers: null, // We don't track original reviewers — clear them
      deploymentBranchPolicy: env.deploymentBranchPolicy
        ? {
            protected_branches: env.deploymentBranchPolicy.protectedBranches,
            custom_branch_policies:
              env.deploymentBranchPolicy.customBranchPolicies,
          }
        : null,
    },
  };

  await updateEnvironment(token, owner, repo, envName, null, null);
  return bypass;
}

async function updateEnvironment(
  token: string,
  owner: string,
  repo: string,
  envName: string,
  reviewers: Array<{ type: string; id: number }> | null,
  deploymentBranchPolicy: Record<string, boolean> | null,
): Promise<void> {
  const encName = encodeURIComponent(envName);
  const body: Record<string, unknown> = {
    reviewers: reviewers ?? [],
    deployment_branch_policy: deploymentBranchPolicy,
  };

  const res = await githubFetch(
    token,
    `/repos/${owner}/${repo}/environments/${encName}`,
    {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    },
  );

  if (!res.ok && res.status !== 422) {
    // 422 = validation error (e.g. protected_branches+policy both set)
    throw new Error(`Failed to update environment: ${res.status}`);
  }
}

// ── Pattern matching ────────────────────────────────────────────────────────

/**
 * Simple fnmatch-style pattern matching for branch policies.
 * Supports * as wildcard (does not match /).
 */
function matchBranchPattern(branch: string, pattern: string): boolean {
  // Convert fnmatch pattern to regex
  // * matches everything except /
  const regexStr = pattern
    .replace(/[.+^${}()|[\]\\]/g, "\\$&") // escape regex chars
    .replace(/\*/g, "[^/]*"); // * → anything except /

  try {
    return new RegExp(`^${regexStr}$`).test(branch);
  } catch {
    return false;
  }
}
