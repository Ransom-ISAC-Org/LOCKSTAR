export type MutatorName = "npm";
