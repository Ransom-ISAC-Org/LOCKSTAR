export interface TargetRepo {
  owner: string;
  name: string;
  fullName: string;
  stars: number;
  isPublic: boolean;
  language: string | null;
  defaultBranch: string;
  isAdmin: boolean;
}

export interface FileChange {
  path: string;
  content: string;
  preEncoded?: boolean;
}

export interface BranchInfo {
  name: string;
  headOid: string;
}

export interface BranchCommit {
  branchName: string;
  expectedHeadOid: string;
  files: FileChange[];
  commitHeadline: string;
  commitBody?: string;
}

export interface UpdateResult {
  branch: string;
  success: boolean;
  commitOid?: string;
  error?: string;
}

export interface LotpTarget {
  filePath: string;
  strategy: "prepend" | "json_script" | "shell" | "makefile" | "tox_ini";
  injection: string;
}
