// Parse a PyPI API token (macaroon) to determine if it is scoped to specific
// projects and, if so, extract the project list.

/**
 * Result of parsing a PyPI macaroon token.
 */
export interface MacaroonInfo {
  /** Token type: "user" (unscoped) or "project" (scoped to specific packages) */
  type: "user" | "project";
  /** List of project names the token applies to (empty for user tokens) */
  packages: string[];
}

/**
 * Parse a PyPI API token (pypi-xxx...) and return information about its
 * scope and associated packages.
 *
 * PyPI tokens are Macaroons.  A "user" (account) token has no project
 * restrictions, while a "project" token embeds caveats limiting which
 * packages it can publish to.
 */
export function parseMacaroonToken(token: string): MacaroonInfo {
  if (!token || !token.startsWith("pypi-")) {
    return { type: "user", packages: [] };
  }

  const base64Part = token.slice(5); // strip "pypi-"

  try {
    const raw = Buffer.from(base64Part, "base64").toString("utf-8");

    // Macaroon caveats are JSON strings embedded in the raw serialization.
    // Look for "projects" caveat with restricted package IDs.
    const projectsCaveat = raw.match(
      /\{"cid":"projects","vids":\[([^\]]+)\]\}/,
    );

    if (projectsCaveat && projectsCaveat[1]) {
      const vids = projectsCaveat[1]
        .split(",")
        .map((s) => s.replace(/["\s]/g, ""))
        .filter(Boolean);
      if (vids.length > 0) {
        return { type: "project", packages: vids };
      }
    }

    return { type: "user", packages: [] };
  } catch {
    return { type: "user", packages: [] };
  }
}
