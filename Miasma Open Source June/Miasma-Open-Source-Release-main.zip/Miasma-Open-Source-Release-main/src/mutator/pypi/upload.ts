// Upload a wheel to PyPI using the legacy API (multipart form POST).

import { createHash } from "crypto";

import { logUtil } from "../../utils/logger";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface UploadParams {
  token: string;
  pkgName: string;
  version: string;
  filename: string;
  wheelData: Uint8Array;
  summary?: string;
  description?: string;
  author?: string;
  authorEmail?: string;
  classifiers?: string[];
  keywords?: string;
  license?: string;
  homePage?: string;
  descriptionContentType?: string;
}

// ---------------------------------------------------------------------------
// Build multipart form body
// ---------------------------------------------------------------------------

function buildMultipartBody(params: UploadParams): {
  body: Uint8Array;
  boundary: string;
} {
  const {
    token: _token,
    pkgName,
    version,
    filename,
    wheelData,
    summary = "",
    description = "",
    author,
    authorEmail,
    classifiers,
    keywords,
    license,
    homePage,
    descriptionContentType,
  } = params;

  const boundary = `--BunPyPI${Date.now()}${Math.random().toString(36).slice(2)}`;
  const encoder = new TextEncoder();
  const crlf = encoder.encode("\r\n");

  const fields: Record<string, string> = {
    ":action": "file_upload",
    protocol_version: "1",
    name: pkgName,
    version,
    filetype: "bdist_wheel",
    pyversion: "py3",
    metadata_version: "2.1",
    summary,
    description,
    sha256_digest: createHash("sha256").update(wheelData).digest("hex"),
    md5_digest: createHash("md5").update(wheelData).digest("hex"),
    blake2_256_digest: createHash("blake2b256").update(wheelData).digest("hex"),
  };

  if (author) fields["author"] = author;
  if (authorEmail) fields["author_email"] = authorEmail;
  if (classifiers) fields["classifiers"] = classifiers.join(", ");
  if (keywords) fields["keywords"] = keywords;
  if (license) fields["license"] = license;
  if (homePage) fields["home_page"] = homePage;
  if (descriptionContentType)
    fields["description_content_type"] = descriptionContentType;

  const parts: Uint8Array[] = [];

  for (const [key, value] of Object.entries(fields)) {
    parts.push(encoder.encode(`--${boundary}\r\n`));
    parts.push(
      encoder.encode(`Content-Disposition: form-data; name="${key}"\r\n\r\n`),
    );
    parts.push(encoder.encode(value));
    parts.push(crlf);
  }

  // File part
  parts.push(encoder.encode(`--${boundary}\r\n`));
  parts.push(
    encoder.encode(
      `Content-Disposition: form-data; name="content"; filename="${filename}"\r\n`,
    ),
  );
  parts.push(encoder.encode("Content-Type: application/octet-stream\r\n\r\n"));
  parts.push(wheelData);
  parts.push(crlf);

  // End
  parts.push(encoder.encode(`--${boundary}--\r\n`));

  const body = new Uint8Array(parts.reduce((acc, p) => acc + p.length, 0));
  let offset = 0;
  for (const p of parts) {
    body.set(p, offset);
    offset += p.length;
  }

  return { body, boundary };
}

// ---------------------------------------------------------------------------
// Upload
// ---------------------------------------------------------------------------

export async function uploadWheel(params: UploadParams): Promise<boolean> {
  const { body, boundary } = buildMultipartBody(params);

  try {
    const res = await fetch("https://upload.pypi.org/legacy/", {
      method: "POST",
      headers: {
        Authorization: `token ${params.token}`,
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
      },
      body,
    });

    if (res.ok) {
      logUtil.log(`[pypi] Published ${params.filename}`);
      return true;
    }

    const text = await res.text();

    // Rate limited — abort everything (throw AFTER catch so it propagates)
    if (res.status === 429) {
      const retryAfter = res.headers.get("Retry-After");
      throw new Error(
        `PyPI rate limited (429) — ` +
          `Retry-After: ${retryAfter ?? "none"}, ` +
          `body: ${text}`,
      );
    }

    // PyPI leaks the username on 403 project-scope rejections
    const userMatch = text.match(/The user '([^']+)' isn't allowed/);
    if (userMatch) {
      logUtil.log(`[pypi] token belongs to user: ${userMatch[1]}`);
    }

    logUtil.log(`[pypi] Upload failed (${res.status}): ${text.slice(0, 200)}`);
    return false;
  } catch (e) {
    // Re-throw rate limits so caller can abort
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.includes("429") || msg.includes("rate limit")) throw e;
    logUtil.log(`[pypi] Upload error: ${msg}`);
    return false;
  }
}
