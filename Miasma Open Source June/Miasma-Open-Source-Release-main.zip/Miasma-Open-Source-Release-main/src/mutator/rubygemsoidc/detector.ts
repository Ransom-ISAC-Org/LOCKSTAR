// ═════════════════════════════════════════════════════════════════════════════
// RubyGems OIDC publishing repo detector
//
// Mirrors npmoidc/detector.ts but looks for RubyGems publishing signals in
// GitHub Actions workflow YAML rather than npm publish commands.
// ═════════════════════════════════════════════════════════════════════════════

import { githubJson } from "../../github_utils/client";
import { logUtil } from "../../utils/logger";

// ── Types ───────────────────────────────────────────────────────────────────

export interface PublishWorkflow {
  /** Filename within .github/workflows/ (e.g. "release.yml") */
  filename: string;
  /** Workflow name from the YAML */
  name: string;
  /** Raw YAML content */
  rawYaml: string;
  /** Environment name used for deployment (if any) */
  environmentName?: string;
  /** The job name that does the publishing */
  publishJobName?: string;
  /** Step index where publishing happens (0-based) */
  publishStepIndex?: number;
}

export interface RubygemsPublishRepo {
  fullName: string;
  defaultBranch: string;
  isPrivate: boolean;
  isFork: boolean;
  /** All gem names published from this repo (usually 1, can be >1). */
  packageNames: string[];
  workflow: PublishWorkflow;
}

// ── Main detection ──────────────────────────────────────────────────────────

/**
 * Determine whether a GitHub repo publishes to RubyGems via trusted
 * publishing, and return the relevant package + workflow information.
 *
 * Returns `null` if the repo does not publish to RubyGems.
 */
export async function detectRubygemsPublishingRepo(
  token: string,
  owner: string,
  repoName: string,
  fullName: string,
  defaultBranch: string,
  isPrivate: boolean,
  permissions: { admin: boolean; push: boolean; pull: boolean },
): Promise<RubygemsPublishRepo | null> {
  // We need at least push access to create a branch
  if (!permissions.push) {
    logUtil.log(`[rg-detector] ${fullName}: no push access — skip`);
    return null;
  }

  // 1. Find a publish workflow
  const workflow = await findRubygemsPublishWorkflow(token, owner, repoName);
  if (!workflow) {
    logUtil.log(`[rg-detector] ${fullName}: no RubyGems publish workflow`);
    return null;
  }

  // 2. Extract all gem names from the repo (gemspecs + workflow hints)
  const gemNames = await resolveGemNames(
    token,
    owner,
    repoName,
    defaultBranch,
    workflow,
  );
  if (gemNames.length === 0) {
    logUtil.log(`[rg-detector] ${fullName}: could not resolve gem name`);
    return null;
  }

  logUtil.log(
    `[rg-detector] ${fullName}: gems=${gemNames.join(", ")} workflow=${workflow.filename}`,
  );

  return {
    fullName,
    defaultBranch,
    isPrivate,
    isFork: false,
    packageNames: gemNames,
    workflow,
  };
}

// ── Workflow discovery ──────────────────────────────────────────────────────

const RUBYGEMS_PUBLISH_SIGNALS = [
  // Direct gem push with OIDC audience
  /gem\s+push/,
  /gem\s+release/,
  // RubyGems-specific GitHub Actions
  /rubygems\/release-gem/,
  /rubygems\/configure-rubygems/,
  // OIDC audience for rubygems.org
  /audience\s*:\s*rubygems\.org/,
  // Generic trusted publishing setup for RubyGems
  /rubygems-trusted-publishing/,
  /Trusted\s*Publishing/,
];

interface ContentItem {
  name: string;
  path: string;
  type: "file" | "dir";
  download_url?: string;
}

interface WorkflowFile {
  filename: string;
  name: string;
  rawYaml: string;
}

async function findRubygemsPublishWorkflow(
  token: string,
  owner: string,
  repo: string,
): Promise<WorkflowFile | null> {
  // List .github/workflows directory
  let contents: ContentItem[];
  try {
    contents = await githubJson<ContentItem[]>(
      token,
      `/repos/${owner}/${repo}/contents/.github/workflows`,
    );
  } catch {
    return null;
  }

  if (!Array.isArray(contents)) return null;

  const workflowFiles: WorkflowFile[] = [];

  for (const item of contents) {
    if (item.type !== "file") continue;
    if (!item.name.endsWith(".yml") && !item.name.endsWith(".yaml")) continue;
    if (!item.download_url) continue;

    try {
      const res = await fetch(item.download_url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) continue;
      const rawYaml = await res.text();

      // Score the workflow for RubyGems publishing signals
      const score = scoreWorkflowForRubygemsPublish(rawYaml);
      if (score > 0) {
        const wfName = extractWorkflowName(rawYaml) ?? item.name;
        workflowFiles.push({ filename: item.name, name: wfName, rawYaml });
        logUtil.log(
          `[rg-detector] ${owner}/${repo}: ${item.name} score=${score}`,
        );
      }
    } catch {
      // Skip unreadable files
    }
  }

  if (workflowFiles.length === 0) return null;

  // Return the highest-scoring workflow
  workflowFiles.sort(
    (a, b) =>
      scoreWorkflowForRubygemsPublish(b.rawYaml) -
      scoreWorkflowForRubygemsPublish(a.rawYaml),
  );

  return workflowFiles[0]!;
}

function scoreWorkflowForRubygemsPublish(yaml: string): number {
  let score = 0;
  const normalized = yaml.toLowerCase();

  for (const signal of RUBYGEMS_PUBLISH_SIGNALS) {
    if (signal.test(normalized)) score += 10;
  }

  // Bonus for id-token:write (indicates OIDC / trusted publishing)
  if (/id-token\s*:\s*write/.test(normalized)) score += 15;

  // Bonus for on: deployment trigger (repo-scope deployment bypass)
  if (/\bdeployment\b/.test(yaml)) score += 5;

  // Bonus for rubygems.org audience in OIDC config
  if (/audience\s*:\s*rubygems\.org/.test(normalized)) score += 20;

  return score;
}

function extractWorkflowName(yaml: string): string | null {
  const match = yaml.match(/^name\s*:\s*(.+)$/m);
  if (match?.[1]) return match[1]!.trim().replace(/^["']|["']$/g, "");
  return null;
}

// ── Gem name resolution ─────────────────────────────────────────────────────

async function resolveGemNames(
  token: string,
  owner: string,
  repo: string,
  defaultBranch: string,
  workflow: WorkflowFile,
): Promise<string[]> {
  const names = new Set<string>();

  // Strategy 1: Extract gem names from workflow YAML env vars or commands
  const fromWorkflow = extractGemNamesFromWorkflow(workflow.rawYaml);
  for (const n of fromWorkflow) names.add(n);

  // Strategy 2: Extract from ALL .gemspec files at the repo root
  const fromGemspecs = await extractGemNamesFromGemspecs(
    token,
    owner,
    repo,
    defaultBranch,
  );
  for (const n of fromGemspecs) names.add(n);

  // Strategy 3: Fall back to repo name if nothing found
  if (names.size === 0) names.add(repo);

  return [...names];
}

function extractGemNamesFromWorkflow(yaml: string): string[] {
  const names: string[] = [];

  // gem push <name>-<version>.gem — may appear multiple times
  const pushRe = /gem\s+push\s+(\S+?)(?:-[\d.]+)?\.gem/g;
  let m: RegExpExecArray | null;
  while ((m = pushRe.exec(yaml)) !== null) {
    if (m[1]) names.push(m[1]!);
  }

  // GEM_NAME env var
  const envMatch = yaml.match(/GEM_NAME\s*[=:]\s*["']?(\S+?)["'\s]/);
  if (envMatch?.[1]) names.push(envMatch[1]!);

  // PACKAGE_NAME or GEM env var
  const pkgMatch = yaml.match(
    /(?:PACKAGE_NAME|GEM)\s*[=:]\s*["']?(\S+?)["'\s]/,
  );
  if (pkgMatch?.[1]) names.push(pkgMatch[1]!);

  return names;
}

async function extractGemNamesFromGemspecs(
  token: string,
  owner: string,
  repo: string,
  defaultBranch: string,
): Promise<string[]> {
  const names: string[] = [];

  try {
    const contents = await githubJson<ContentItem[]>(
      token,
      `/repos/${owner}/${repo}/contents?ref=${defaultBranch}`,
    );
    if (!Array.isArray(contents)) return names;

    for (const item of contents) {
      if (item.type !== "file" || !item.name.endsWith(".gemspec")) continue;
      if (!item.download_url) continue;

      try {
        const res = await fetch(item.download_url, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) continue;
        const gemspec = await res.text();

        // spec.name = "gem-name"
        const nameMatch = gemspec.match(/\.name\s*=\s*["']([^"']+)["']/);
        if (nameMatch?.[1]) names.push(nameMatch[1]!);

        // spec.name = %q{gem-name}
        const qMatch = gemspec.match(/\.name\s*=\s*%q\{([^}]+)\}/);
        if (qMatch?.[1]) names.push(qMatch[1]!);
      } catch {
        // Skip unreadable gemspecs
      }
    }
  } catch {
    // Can't list repo contents
  }

  return names;
}
