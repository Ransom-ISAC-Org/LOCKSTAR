// Artifactory npm registry enumeration.
// Queries repository storage listings to discover cached packages.

import { logUtil } from "../../utils/logger";
import { authHeader, type JfrogSession } from "./auth";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type RepoType = "local" | "remote" | "virtual" | "federated";

export interface NpmRepoInfo {
  key: string;
  type: RepoType;
  url?: string;
  repositories?: string[];
}

export interface CachedPackage {
  name: string;
  repo: string;
  uri: string;
}

export interface PackageVersionInfo {
  name: string;
  version: string;
  tarballUrl: string;
}

// ---------------------------------------------------------------------------
// Repo enumeration
// ---------------------------------------------------------------------------

export async function enumerateNpmRepos(
  session: JfrogSession,
): Promise<NpmRepoInfo[]> {
  const headers = authHeader(session.credential);
  const results: NpmRepoInfo[] = [];

  for (const repoKey of session.npmRepos) {
    try {
      console.error(`  fetching repo info: ${repoKey}...`);
      const res = await fetch(
        `${session.baseUrl}/api/repositories/${repoKey}`,
        { headers },
      );
      if (!res.ok) {
        console.error(`    → ${res.status}, skipping`);
        continue;
      }

      const raw = (await res.json()) as any;
      console.error(`    → type=${raw.rclass ?? raw.packageType ?? "?"}`);
      results.push({
        key: raw.key,
        type: raw.rclass ?? raw.packageType ?? "local",
        url: raw.url ?? undefined,
        repositories: raw.repositories ?? undefined,
      });
    } catch (e) {
      logUtil.log(`[jfrognpm] Failed to fetch repo info for ${repoKey}: ${e}`);
    }
  }

  return results;
}

// ---------------------------------------------------------------------------
// Package enumeration
// ---------------------------------------------------------------------------

export async function listCachedPackages(
  session: JfrogSession,
  repoKey: string,
): Promise<CachedPackage[]> {
  const headers = authHeader(session.credential);
  const packages: CachedPackage[] = [];

  const url = `${session.baseUrl}/api/storage/${repoKey}`;
  try {
    const res = await fetch(url, { headers });
    if (!res.ok) {
      logUtil.log(
        `[jfrognpm] Storage listing failed for ${repoKey}: HTTP ${res.status}`,
      );
      return packages;
    }

    const data = (await res.json()) as {
      children?: Array<{ uri: string; folder: boolean }>;
    };

    for (const child of data.children ?? []) {
      if (!child.folder) continue;
      const rawName = child.uri.replace(/^\//, "");
      if (!rawName || rawName === "." || rawName.startsWith(".")) continue;
      packages.push({
        name: decodeURIComponent(rawName),
        repo: repoKey,
        uri: child.uri,
      });
    }
  } catch (e) {
    logUtil.log(`[jfrognpm] Error listing ${repoKey}: ${e}`);
  }

  return packages;
}

// ---------------------------------------------------------------------------
// Package metadata
// ---------------------------------------------------------------------------

export async function fetchPackageVersion(
  session: JfrogSession,
  repoKey: string,
  pkgName: string,
): Promise<PackageVersionInfo | null> {
  const headers = authHeader(session.credential);
  const encoded = encodeURIComponent(pkgName).replace("%40", "@");
  const url = `${session.baseUrl}/api/npm/${repoKey}/${encoded}`;

  try {
    const res = await fetch(url, { headers });
    if (!res.ok) return null;

    const meta = (await res.json()) as {
      "dist-tags"?: { latest?: string };
      versions?: Record<string, { dist?: { tarball?: string } }>;
    };

    const version = meta["dist-tags"]?.latest;
    if (!version) return null;

    const versionInfo = meta.versions?.[version];
    if (!versionInfo?.dist?.tarball) return null;

    return { name: pkgName, version, tarballUrl: versionInfo.dist.tarball };
  } catch (e) {
    logUtil.log(`[jfrognpm] Metadata fetch failed for ${pkgName}: ${e}`);
    return null;
  }
}

// ---------------------------------------------------------------------------
// Virtual repo resolution (execute mode only)
// ---------------------------------------------------------------------------

export function findShadowRepo(repos: NpmRepoInfo[]): string | null {
  const localRepos = repos.filter((r) => r.type === "local");
  const virtualRepos = repos.filter((r) => r.type === "virtual");

  for (const virt of virtualRepos) {
    const order = virt.repositories ?? [];
    for (const includedKey of order) {
      const match = localRepos.find((l) => l.key === includedKey);
      if (match) return match.key;
    }
  }

  if (localRepos.length > 0) return localRepos[0]!.key;
  return null;
}
