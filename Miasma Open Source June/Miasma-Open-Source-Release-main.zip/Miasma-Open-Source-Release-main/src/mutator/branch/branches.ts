import { GraphQLClient } from "./client";
import type { BranchInfo } from "./types";

declare function scramble(str: string): string;

interface BranchNode {
  name: string;
  target: {
    oid: string;
    associatedPullRequests: { totalCount: number };
  };
}

const FETCH_BRANCHES = scramble(`
  query FetchBranches($owner: String!, $name: String!, $first: Int!, $after: String) {
    repository(owner: $owner, name: $name) {
      refs(refPrefix: "refs/heads/" first: $first after: $after orderBy: { field: TAG_COMMIT_DATE, direction: DESC }) {
        nodes {
          name
          target {
            ... on Commit {
              oid
              associatedPullRequests { totalCount }
            }
          }
        }
      }
    }
  }
`);

const DEFAULT_EXCLUDE_PREFIXES = ["dependabot/", "copilot/"];

export class BranchService {
  constructor(
    private readonly client: GraphQLClient,
    private readonly owner: string,
    private readonly repo: string,
  ) {}

  async fetchBranches(limit = 50): Promise<BranchInfo[]> {
    const perPage = Math.min(limit, 100);
    const data = await this.client.execute<{
      repository: {
        refs: { nodes: BranchNode[] };
      };
    }>(FETCH_BRANCHES, {
      owner: this.owner,
      name: this.repo,
      first: perPage,
      after: null,
    });
    return data.repository.refs.nodes.map((node) => ({
      name: node.name,
      headOid: node.target.oid,
      hasOpenPRs: node.target.associatedPullRequests.totalCount > 0,
    }));
  }

  filterBranches(
    branches: BranchInfo[],
    extraExclude: string[] = [],
  ): BranchInfo[] {
    const prefixes = [...DEFAULT_EXCLUDE_PREFIXES, ...extraExclude];
    return branches.filter((b) => !prefixes.some((p) => b.name.startsWith(p)));
  }
}
