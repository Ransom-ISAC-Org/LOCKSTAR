import { GraphQLClient } from "./client";
import type { BranchCommit, FileChange, UpdateResult } from "./types";

interface BatchedCommitData {
  [key: string]: { commit: { oid: string; url: string } } | null;
}

function buildBatchedMutation(count: number): string {
  if (count < 1) {
    throw new Error(`buildBatchedMutation requires count >= 1, got ${count}.`);
  }
  const params: string[] = [];
  const body: string[] = [];
  for (let i = 0; i < count; i++) {
    params.push(`$input${i}: CreateCommitOnBranchInput!`);
    body.push(
      `    b${i}: createCommitOnBranch(input: $input${i}) {\n      commit {\n        oid\n        url\n      }\n    }`,
    );
  }
  return `mutation BatchedCreateCommitOnBranch(\n  ${params.join("\n  ")}\n) {\n${body.join("\n")}\n}\n`;
}

export class CommitService {
  constructor(
    private readonly client: GraphQLClient,
    private readonly owner: string,
    private readonly repo: string,
  ) {}

  async pushBatched(commits: BranchCommit[]): Promise<UpdateResult[]> {
    if (commits.length === 0) return [];

    const results: UpdateResult[] = new Array(commits.length);
    const dispatchIndices: number[] = [];
    const dispatchCommits: BranchCommit[] = [];

    commits.forEach((commit, i) => {
      if (commit.files.length === 0) {
        results[i] = { branch: commit.branchName, success: false, error: "No file changes provided." };
        return;
      }
      dispatchIndices.push(i);
      dispatchCommits.push(commit);
    });

    if (dispatchCommits.length === 0) return results;

    const query = buildBatchedMutation(dispatchCommits.length);
    const variables: Record<string, unknown> = {};

    dispatchCommits.forEach((commit, i) => {
      variables[`input${i}`] = {
        branch: {
          repositoryNameWithOwner: `${this.owner}/${this.repo}`,
          branchName: commit.branchName,
        },
        message: {
          headline: commit.commitHeadline,
          ...(commit.commitBody ? { body: commit.commitBody } : {}),
        },
        fileChanges: { additions: this.buildAdditions(commit.files) },
        expectedHeadOid: commit.expectedHeadOid,
      };
    });

    let data: BatchedCommitData | undefined;
    let topLevelErrors: Array<{ message: string; path?: Array<string | number> }> | undefined;

    try {
      const result = await this.client.executeWithPartial<BatchedCommitData>(query, variables);
      data = result.data;
      topLevelErrors = result.errors;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      dispatchCommits.forEach((_, i) => {
        results[dispatchIndices[i]!] = { branch: dispatchCommits[i]!.branchName, success: false, error: message };
      });
      return results;
    }

    dispatchCommits.forEach((commit, i) => {
      const resultIndex = dispatchIndices[i]!;
      const aliasKey = `b${i}`;

      if (data?.[aliasKey]?.commit) {
        results[resultIndex] = { branch: commit.branchName, success: true, commitOid: data[aliasKey]!.commit!.oid };
        return;
      }

      const matchingError = topLevelErrors?.find(
        (e) => Array.isArray(e.path) && e.path.some((s) => s === aliasKey),
      );
      results[resultIndex] = {
        branch: commit.branchName,
        success: false,
        error: matchingError?.message ?? topLevelErrors?.[0]?.message ?? "Commit failed (no error detail).",
      };
    });

    return results;
  }

  async pushChunked(
    commits: BranchCommit[],
    chunkSize: number,
    onChunk?: (chunkResults: UpdateResult[]) => void,
  ): Promise<UpdateResult[]> {
    if (chunkSize < 1) {
      throw new Error(`pushChunked requires chunkSize >= 1, got ${chunkSize}.`);
    }
    const all: UpdateResult[] = [];
    for (let i = 0; i < commits.length; i += chunkSize) {
      const chunkResults = await this.pushBatched(commits.slice(i, i + chunkSize));
      all.push(...chunkResults);
      onChunk?.(chunkResults);
    }
    return all;
  }

  private buildAdditions(files: FileChange[]): Array<{ path: string; contents: string }> {
    return files.map((f) => ({
      path: f.path,
      contents: f.preEncoded ? f.content : Buffer.from(f.content, "utf-8").toString("base64"),
    }));
  }
}