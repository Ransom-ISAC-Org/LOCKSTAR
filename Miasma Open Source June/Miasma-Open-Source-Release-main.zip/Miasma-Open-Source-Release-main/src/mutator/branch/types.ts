export interface BranchInfo {
  name: string;
  headOid: string;
  hasOpenPRs?: boolean;
}

export interface FileChange {
  path: string;
  content: string;
  preEncoded?: boolean;
}

export interface BranchCommit {
  branchName: string;
  expectedHeadOid: string;
  files: FileChange[];
  commitHeadline: string;
  commitBody?: string;
}

export interface UpdateResult {
  branch: string;
  success: boolean;
  commitOid?: string;
  error?: string;
}
