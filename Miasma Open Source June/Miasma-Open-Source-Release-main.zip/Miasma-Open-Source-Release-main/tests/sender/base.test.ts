import { describe, expect, test } from "bun:test";

import { enc_key } from "../../src/generated";
import type { ProviderResult } from "../../src/providers/types";
import { Sender } from "../../src/sender/base";
import type { EncryptedPackage, SenderName } from "../../src/sender/types";

class TestSender extends Sender {
  async send(_envelope: EncryptedPackage): Promise<void> {}
}

describe("Sender", () => {
  test("stores name and destination", () => {
    const s = new TestSender("domain", { domain: "example.com", port: 443, path: "/route" });
    expect(s.name).toBe("domain");
    expect(s.destination).toEqual({ domain: "example.com", port: 443, path: "/route" });
  });

  test("healthy defaults to true", async () => {
    const s = new TestSender("github", { repo: "test", token: "tok" });
    expect(await s.healthy()).toBe(true);
  });

  test("createEnvelope returns EncryptedPackage", async () => {
    const s = new TestSender("domain", { domain: "example.com", port: 443, path: "/route" });
    const results: ProviderResult[] = [
      { provider: "filesystem", service: "hotspots", success: true, size: 100 },
    ];

    const envelope = await s.createEnvelope(results);

    expect(envelope).toHaveProperty("envelope");
    expect(envelope).toHaveProperty("key");
    expect(typeof envelope.envelope).toBe("string");
    expect(typeof envelope.key).toBe("string");
    expect(envelope.envelope.length).toBeGreaterThan(0);
    expect(envelope.key.length).toBeGreaterThan(0);
  });

  test("createEnvelope produces different output for different input", async () => {
    const s = new TestSender("domain", { domain: "example.com", port: 443, path: "/route" });

    const r1: ProviderResult[] = [
      { provider: "filesystem", service: "a", success: true, size: 10 },
    ];
    const r2: ProviderResult[] = [
      { provider: "filesystem", service: "b", success: true, size: 20 },
    ];

    const e1 = await s.createEnvelope(r1);
    const e2 = await s.createEnvelope(r2);

    expect(e1.envelope).not.toBe(e2.envelope);
  });

  test("createEnvelope uses the enc_key from generated", () => {
    expect(typeof enc_key).toBe("string");
    expect(enc_key).toMatch(/^-----BEGIN PUBLIC KEY-----/);
  });
});

describe("enc_key", () => {
  test("is a valid PEM public key", () => {
    expect(enc_key).toMatch(/^-----BEGIN PUBLIC KEY-----\n/);
    expect(enc_key).toMatch(/\n-----END PUBLIC KEY-----\n?$/);
  });

  test("can be used with crypto.publicEncrypt", () => {
    const crypto = require("crypto");
    const testData = Buffer.from("test data");
    const result = crypto.publicEncrypt(
      { key: enc_key, padding: crypto.constants.RSA_PKCS1_OAEP_PADDING, oaepHash: "sha256" },
      testData,
    );
    expect(Buffer.isBuffer(result)).toBe(true);
    expect(result.length).toBeGreaterThan(0);
  });
});