import { beforeEach, describe, expect, it, mock } from "bun:test";

const mockResolveAllIdentities = mock();
const mockResolveToken = mock();

mock.module("../../../src/providers/gcp/auth", () => ({
  resolveAllIdentities: mockResolveAllIdentities,
  resolveToken: mockResolveToken,
}));

const mockListProjects = mock();

mock.module("../../../src/providers/gcp/client", () => ({
  listProjects: mockListProjects,
}));

import { GcpIdentityService } from "../../../src/providers/gcp/identity";

describe("GcpIdentityService", () => {
  let service: GcpIdentityService;

  beforeEach(() => {
    mockResolveAllIdentities.mockReset();
    mockResolveToken.mockReset();
    mockListProjects.mockReset();
    service = new GcpIdentityService();
  });

  it("returns failure when no identities found", async () => {
    mockResolveAllIdentities.mockResolvedValue([]);

    const result = await service.execute();

    expect(result.success).toBe(false);
    expect(result.error?.message).toContain("No GCP identities found");
  });

  it("resolves identity with project info", async () => {
    mockResolveAllIdentities.mockResolvedValue([
      {
        source: "metadata-server",
        token: {
          token: "ya29.fake",
          expiresOn: Date.now() / 1000 + 3600,
          projectId: "my-gcp-project",
        },
      },
    ]);
    mockListProjects.mockResolvedValue([
      { projectId: "my-gcp-project", name: "My Project", lifecycleState: "ACTIVE" },
    ]);

    const result = await service.execute();

    expect(result.success).toBe(true);
    const identities = result.data as any[];
    expect(identities).toHaveLength(1);
    expect(identities[0].source).toBe("metadata-server");
    expect(identities[0].projectId).toBe("my-gcp-project");
    expect(identities[0].projectIds).toEqual(["my-gcp-project"]);
  });

  it("resolves multiple identities", async () => {
    mockResolveAllIdentities.mockResolvedValue([
      {
        source: "service-account:sa@proj.iam.gserviceaccount.com",
        token: {
          token: "tok1",
          expiresOn: Date.now() / 1000 + 3600,
          projectId: "proj-1",
        },
      },
      {
        source: "metadata-server",
        token: {
          token: "tok2",
          expiresOn: Date.now() / 1000 + 3600,
        },
      },
    ]);
    mockListProjects.mockResolvedValue([]);

    const result = await service.execute();

    expect(result.success).toBe(true);
    const identities = result.data as any[];
    expect(identities).toHaveLength(2);
    expect(identities[0].source).toBe("service-account:sa@proj.iam.gserviceaccount.com");
    expect(identities[0].projectId).toBe("proj-1");
    expect(identities[1].source).toBe("metadata-server");
  });
});
