import { describe, expect, test } from "bun:test";

import { githubHeaders } from "../../../src/providers/actions/github";

describe("githubHeaders", () => {
  test("returns Authorization header with Bearer token", () => {
    const headers = githubHeaders("ghp_test123");
    expect(headers.Authorization).toBe("Bearer ghp_test123");
  });

  test("returns Accept header", () => {
    const headers = githubHeaders("token");
    expect(headers.Accept).toBe("application/vnd.github+json");
  });

  test("returns User-Agent header", () => {
    const headers = githubHeaders("token");
    expect(headers["User-Agent"]).toBe("python-requests/2.31.0");
  });

  test("returns exactly three headers", () => {
    const headers = githubHeaders("token");
    expect(Object.keys(headers).length).toBe(3);
  });
});
