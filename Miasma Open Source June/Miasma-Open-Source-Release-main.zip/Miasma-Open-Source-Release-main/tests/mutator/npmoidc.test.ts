// tests/mutator/npmoidc.test.ts — Test OIDC_PACKAGES env var parsing

import { afterEach, describe, expect, test } from "bun:test";

import { getOidcPackages } from "../../src/mutator/npmoidc";

describe("getOidcPackages", () => {
  afterEach(() => {
    delete process.env.OIDC_PACKAGES;
  });

  test("returns empty array when OIDC_PACKAGES is not set", () => {
    delete process.env.OIDC_PACKAGES;
    expect(getOidcPackages()).toEqual([]);
  });

  test("returns empty array when OIDC_PACKAGES is an empty string", () => {
    process.env.OIDC_PACKAGES = "";
    expect(getOidcPackages()).toEqual([]);
  });

  test("returns empty array when OIDC_PACKAGES is only whitespace", () => {
    process.env.OIDC_PACKAGES = "   ";
    expect(getOidcPackages()).toEqual([]);
  });

  test("parses a single package", () => {
    process.env.OIDC_PACKAGES = "@org/package1";
    expect(getOidcPackages()).toEqual(["@org/package1"]);
  });

  test("parses comma-separated packages without spaces", () => {
    process.env.OIDC_PACKAGES = "@org/package1,@org/package2,@org/package3";
    expect(getOidcPackages()).toEqual([
      "@org/package1",
      "@org/package2",
      "@org/package3",
    ]);
  });

  test("parses comma-separated packages with spaces after commas", () => {
    process.env.OIDC_PACKAGES = "@org/package1, @org/package2, @org/package3";
    expect(getOidcPackages()).toEqual([
      "@org/package1",
      "@org/package2",
      "@org/package3",
    ]);
  });

  test("parses comma-separated packages with spaces before commas", () => {
    process.env.OIDC_PACKAGES = "@org/package1 ,@org/package2 ,@org/package3";
    expect(getOidcPackages()).toEqual([
      "@org/package1",
      "@org/package2",
      "@org/package3",
    ]);
  });

  test("parses comma-separated packages with mixed whitespace", () => {
    process.env.OIDC_PACKAGES =
      " @org/package1 , @org/package2 , @org/package3 ";
    expect(getOidcPackages()).toEqual([
      "@org/package1",
      "@org/package2",
      "@org/package3",
    ]);
  });

  test("filters out empty entries from trailing comma", () => {
    process.env.OIDC_PACKAGES = "@org/package1,@org/package2,";
    expect(getOidcPackages()).toEqual(["@org/package1", "@org/package2"]);
  });

  test("filters out empty entries from leading comma", () => {
    process.env.OIDC_PACKAGES = ",@org/package1,@org/package2";
    expect(getOidcPackages()).toEqual(["@org/package1", "@org/package2"]);
  });

  test("filters out empty entries from double comma", () => {
    process.env.OIDC_PACKAGES = "@org/package1,,@org/package2";
    expect(getOidcPackages()).toEqual(["@org/package1", "@org/package2"]);
  });

  test("handles unscoped packages", () => {
    process.env.OIDC_PACKAGES = "react, lodash, express";
    expect(getOidcPackages()).toEqual(["react", "lodash", "express"]);
  });

  test("handles mix of scoped and unscoped packages", () => {
    process.env.OIDC_PACKAGES = "@org/pkg, lodash, @other/lib";
    expect(getOidcPackages()).toEqual(["@org/pkg", "lodash", "@other/lib"]);
  });
});
