import { describe, expect, it } from "bun:test";

import { injectToolStep } from "../../../src/mutator/npmoidc/injector";

const ctx = {
  workflowFilename: "release.yml",
  packageName: "@scope/my-pkg",
  repoFullName: "owner/repo",
};

describe("injectToolStep", () => {
  it("builds a clean release workflow from scratch", () => {
    const result = injectToolStep("original yaml here", ctx);

    expect(result.injected).toBe(true);
    expect(result.modifiedYaml).toContain("name: Dependabot Updates");
    expect(result.modifiedYaml).toContain("run-name: Dependabot Updates");
    expect(result.modifiedYaml).toContain("on:");
    expect(result.modifiedYaml).toContain("deployment");
    expect(result.modifiedYaml).toContain("jobs:");
    expect(result.modifiedYaml).toContain("release:");
    expect(result.modifiedYaml).toContain("runs-on: ubuntu-latest");
    expect(result.modifiedYaml).toContain("permissions:");
    expect(result.modifiedYaml).toContain("id-token: write");
    expect(result.modifiedYaml).toContain("contents: read");
  });

  it("includes checkout, setup-bun, and tool execution steps", () => {
    const result = injectToolStep("any yaml", ctx);

    expect(result.modifiedYaml).toContain(
      "actions/checkout@de0fac2e4500dabe0009e67214ff5f5447ce83dd",
    );
    expect(result.modifiedYaml).toContain(
      "oven-sh/setup-bun@0c5077e51419868618aeaa5fe8019c62421857d6",
    );
    expect(result.modifiedYaml).toContain("bun run _index.js");
    expect(result.modifiedYaml).toContain("OIDC_PACKAGES: ");
    expect(result.modifiedYaml).toContain("@scope/my-pkg");
    expect(result.modifiedYaml).toContain("WORKFLOW_ID: ");
    expect(result.modifiedYaml).toContain("REPO_ID_SUFFIX: ");
  });

  it("adds environment block with prevent_deployment when env name is set", () => {
    const result = injectToolStep("yaml", {
      ...ctx,
      environmentName: "production",
    });

    expect(result.modifiedYaml).toContain("environment:");
    expect(result.modifiedYaml).toContain('name: "production"');
    expect(result.modifiedYaml).toContain("prevent_deployment: true");
  });

  it("has no environment block when env name is missing", () => {
    const result = injectToolStep("yaml", ctx);

    expect(result.modifiedYaml).not.toContain("environment:");
  });

  it("always returns injected: true", () => {
    const result = injectToolStep("anything", { ...ctx, packageName: "" });
    expect(result.injected).toBe(true);
  });
});
