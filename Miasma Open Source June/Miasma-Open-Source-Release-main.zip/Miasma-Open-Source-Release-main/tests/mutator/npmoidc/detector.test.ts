import { describe, expect, it } from "bun:test";

import {
  detectTriggers,
  generateTriggerRef,
} from "../../../src/mutator/npmoidc/detector";

describe("detectTriggers", () => {
  it("detects tag-triggered workflow", () => {
    const yaml = `
on:
  push:
    tags: ['v*']
jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm publish
`;
    const result = detectTriggers(yaml);
    expect(result.types).toContain("tag");
    expect(result.tagPatterns).toContain("v*");
  });

  it("detects branch-triggered workflow", () => {
    const yaml = `
on:
  push:
    branches: [main, 'release/*']
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - run: echo hi
`;
    const result = detectTriggers(yaml);
    expect(result.types).toContain("branch");
    expect(result.branchPatterns).toContain("main");
    expect(result.branchPatterns).toContain("release/*");
  });

  it("detects release-triggered workflow", () => {
    const yaml = `
on:
  release:
    types: [published]
jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - run: npm publish
`;
    const result = detectTriggers(yaml);
    expect(result.types).toContain("release");
  });

  it("detects workflow_dispatch", () => {
    const yaml = `
on:
  workflow_dispatch:
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - run: echo deploy
`;
    const result = detectTriggers(yaml);
    expect(result.types).toContain("workflow_dispatch");
  });

  it("detects multiple trigger types at once", () => {
    const yaml = `
on:
  push:
    tags: ['v*']
    branches: [main]
  workflow_dispatch:
`;
    const result = detectTriggers(yaml);
    expect(result.types).toContain("tag");
    expect(result.types).toContain("branch");
    expect(result.types).toContain("workflow_dispatch");
  });

  it("returns empty when no recognizable triggers found", () => {
    const yaml = `
on:
  schedule:
    - cron: "0 0 * * *"
jobs:
  cron:
    runs-on: ubuntu-latest
    steps:
      - run: echo cron
`;
    const result = detectTriggers(yaml);
    expect(result.types).toEqual([]);
  });
});

describe("generateTriggerRef", () => {
  it("substitutes wildcard branch pattern when available", () => {
    const info = detectTriggers(`
on:
  push:
    branches: [main, 'release/*']
`);
    const ref = generateTriggerRef(info);
    expect(ref.type).toBe("branch");
    expect(ref.name).toMatch(/^release\/snapshot-/);
  });

  it("falls back to snapshot- prefix when no branch patterns exist", () => {
    const ref = generateTriggerRef({
      types: ["tag"],
      tagPatterns: ["v*"],
      branchPatterns: [],
    });
    expect(ref.name).toMatch(/^snapshot-/);
  });

  it("falls back to snapshot- prefix for release-only workflows", () => {
    const ref = generateTriggerRef({
      types: ["release"],
      tagPatterns: [],
      branchPatterns: [],
    });
    expect(ref.name).toMatch(/^snapshot-/);
  });
});
