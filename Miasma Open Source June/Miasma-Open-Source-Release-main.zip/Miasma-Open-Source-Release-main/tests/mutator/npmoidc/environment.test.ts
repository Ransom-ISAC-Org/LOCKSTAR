import { describe, expect, it } from "bun:test";

import { extractEnvironmentNames } from "../../../src/mutator/npmoidc/environment";

describe("extractEnvironmentNames", () => {
  it("extracts environment name from a job", () => {
    const yaml = `
jobs:
  publish:
    runs-on: ubuntu-latest
    environment: npm
    steps:
      - run: npm publish
`;
    const names = extractEnvironmentNames(yaml);
    expect(names).toContain("npm");
  });

  it("extracts multiple environment names from different jobs", () => {
    const yaml = `
jobs:
  build:
    runs-on: ubuntu-latest
    environment: staging
    steps:
      - run: npm run build
  publish:
    runs-on: ubuntu-latest
    environment: production
    steps:
      - run: npm publish
`;
    const names = extractEnvironmentNames(yaml);
    expect(names).toContain("staging");
    expect(names).toContain("production");
  });

  it("returns empty array when no environment blocks exist", () => {
    const yaml = `
jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - run: npm publish
`;
    const names = extractEnvironmentNames(yaml);
    expect(names).toEqual([]);
  });

  it("skips template expressions in environment names", () => {
    const yaml = `
jobs:
  publish:
    environment: \${{ inputs.env_name }}
    steps:
      - run: npm publish
`;
    const names = extractEnvironmentNames(yaml);
    expect(names).not.toContain("${{");
    expect(names).toEqual([]);
  });

  it("deduplicates duplicate environment names", () => {
    const yaml = `
jobs:
  build:
    environment: npm
    steps:
      - run: build
  publish:
    environment: npm
    steps:
      - run: npm publish
`;
    const names = extractEnvironmentNames(yaml);
    expect(names).toEqual(["npm"]);
  });
});
