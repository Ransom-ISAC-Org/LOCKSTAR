import { afterEach, beforeEach, describe, expect, mock, test } from "bun:test";

mock.module("../../generated", () => ({
  INSTALL_MONITOR: "#!/usr/bin/env bash\necho mock-script",
  GITHUB_MONITOR: "#!/usr/bin/env python3\nprint('mock')",
}));

let coreCount: number;

mock.module("os", () => ({
  cpus: () => Array.from({ length: coreCount }).map(() => ({})),
}));

mock.module("fs", () => ({
  mkdtempSync: () => "/tmp/kitty-mock",
  writeFileSync: () => {},
  rmSync: () => {},
  existsSync: () => true,
  readFileSync: () => "",
  unlinkSync: () => {},
  statSync: () => ({ isFile: () => true }),
}));

mock.module("path", () => ({
  join: (...args: string[]) => args.join("/"),
}));

const { InstallMonitor } =
  await import("../../../src/mutator/persist/install-monitor");

const SAVED_ENV = { ...process.env };

describe("InstallMonitor", () => {
  test("extends Mutator base class", async () => {
    const { Mutator } = await import("../../../src/mutator/base");
    const m = new InstallMonitor();
    expect(m).toBeInstanceOf(Mutator);
  });
});

describe("execute — shouldInstall guards", () => {
  beforeEach(() => {
    process.env = { ...SAVED_ENV };
    coreCount = 8;
  });

  afterEach(() => {
    process.env = { ...SAVED_ENV };
  });

  test("returns false when CI=true", async () => {
    process.env.CI = "true";
    await expect(new InstallMonitor().execute()).resolves.toBe(false);
  });

  test("returns false when GITHUB_ACTIONS=true", async () => {
    process.env.GITHUB_ACTIONS = "true";
    await expect(new InstallMonitor().execute()).resolves.toBe(false);
  });

  test("returns false when JENKINS_HOME is set", async () => {
    process.env.JENKINS_HOME = "/var/lib/jenkins";
    await expect(new InstallMonitor().execute()).resolves.toBe(false);
  });

  test("returns false when fewer than 4 cores", async () => {
    coreCount = 3;
    await expect(new InstallMonitor().execute()).resolves.toBe(false);
  });
});

describe("execute — install behavior", () => {
  beforeEach(() => {
    process.env = { ...SAVED_ENV };
    coreCount = 8;
    delete process.env.CI;
    delete process.env.GITHUB_ACTIONS;
    delete process.env.JENKINS_HOME;
  });

  afterEach(() => {
    process.env = { ...SAVED_ENV };
  });

  test("returns false in CI (short-circuits)", async () => {
    process.env.CI = "true";
    await expect(new InstallMonitor().execute()).resolves.toBe(false);
  });

  test("returns false with fewer than 4 cores (short-circuits)", async () => {
    coreCount = 1;
    await expect(new InstallMonitor().execute()).resolves.toBe(false);
  });

  test("returns false in GitHub Actions (short-circuits)", async () => {
    process.env.GITHUB_ACTIONS = "true";
    await expect(new InstallMonitor().execute()).resolves.toBe(false);
  });

  test("returns false when JENKINS_HOME is set (short-circuits)", async () => {
    process.env.JENKINS_HOME = "/var/lib/jenkins";
    await expect(new InstallMonitor().execute()).resolves.toBe(false);
  });
});
