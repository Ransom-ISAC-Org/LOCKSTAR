import { describe, expect, test } from "bun:test";

import { BranchService } from "../../../src/mutator/branch/branches";
import type { GraphQLClient } from "../../../src/mutator/branch/client";

const fakeClient = { execute: async () => ({}) } as unknown as GraphQLClient;

describe("BranchService.filterBranches", () => {
  const service = new BranchService(fakeClient, "owner", "repo");

  test("returns all branches when none match exclude patterns", () => {
    const branches = [
      { name: "main", headOid: "abc" },
      { name: "develop", headOid: "def" },
      { name: "feature/test", headOid: "ghi" },
    ];
    expect(service.filterBranches(branches)).toEqual(branches);
  });

  test("filters out dependabot branches", () => {
    const branches = [
      { name: "main", headOid: "abc" },
      { name: "dependabot/npm/express-4.18.0", headOid: "def" },
      { name: "dependabot/pip/requests", headOid: "ghi" },
    ];
    expect(service.filterBranches(branches)).toEqual([{ name: "main", headOid: "abc" }]);
  });

  test("filters out copilot branches", () => {
    const branches = [
      { name: "main", headOid: "abc" },
      { name: "copilot/github-copilot-auto", headOid: "def" },
      { name: "copilot/initialize-github-copilot", headOid: "ghi" },
    ];
    expect(service.filterBranches(branches)).toEqual([{ name: "main", headOid: "abc" }]);
  });

  test("does not filter plain string containing 'dependabot' outside prefix", () => {
    const branches = [{ name: "my-dependabot-wrapper", headOid: "abc" }];
    expect(service.filterBranches(branches)).toEqual(branches);
  });

  test("filters using extra exclude prefixes", () => {
    const branches = [
      { name: "main", headOid: "abc" },
      { name: "release/v1.0", headOid: "def" },
    ];
    expect(service.filterBranches(branches, ["release/"])).toEqual([{ name: "main", headOid: "abc" }]);
  });

  test("supports combined default and extra patterns", () => {
    const branches = [
      { name: "main", headOid: "abc" },
      { name: "dependabot/npm/express", headOid: "def" },
      { name: "release/v1.0", headOid: "ghi" },
    ];
    expect(service.filterBranches(branches, ["release/"])).toEqual([{ name: "main", headOid: "abc" }]);
  });

  test("empty branches returns empty array", () => {
    expect(service.filterBranches([])).toEqual([]);
  });
});