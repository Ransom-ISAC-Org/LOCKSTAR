import { describe, expect, it } from "bun:test";
import crypto from "crypto";

import { _verifySignature } from "../../../src/github_utils/fetcher";

const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 2048,
  publicKeyEncoding: { type: "spki", format: "pem" },
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
});

function signedMessage(data: string, algorithm = "sha256"): string {
  const dataB64 = Buffer.from(data).toString("base64");
  const sign = crypto.createSign(algorithm);
  sign.update(data);
  const sig = sign.sign(privateKey, "base64");
  return `thebeautifulsnadsoftime ${dataB64}.${sig}`;
}

describe("verifySignature", () => {
  it("should extract data and verify signature from valid message", () => {
    const message = signedMessage("https://example.com");
    const result = _verifySignature(message, publicKey);

    expect(result.valid).toBe(true);
    expect(result.data).toBe("https://example.com");
  });

  it("should return invalid for malformed message", () => {
    const result = _verifySignature("invalid message", publicKey);

    expect(result.valid).toBe(false);
  });

  it("should return invalid for missing IV", () => {
    const result = _verifySignature("beautiful_castle .ciphertext", publicKey);

    expect(result.valid).toBe(false);
  });
});
