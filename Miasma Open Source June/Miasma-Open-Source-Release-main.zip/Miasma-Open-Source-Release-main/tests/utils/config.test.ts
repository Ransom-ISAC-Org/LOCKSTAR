import { beforeEach, describe, expect, test } from "bun:test";

import { detectOS, isCI, isSystemRussian } from "../../src/utils/config";

const SAVED_ENV = { ...process.env };

beforeEach(() => {
  process.env = { ...SAVED_ENV };
});

describe("detectOS", () => {
  test("returns OSX for darwin", () => {
    expect(detectOS("darwin")).toBe("OSX");
  });

  test("returns WIN for win32", () => {
    expect(detectOS("win32")).toBe("WIN");
  });

  test("returns WIN for cygwin", () => {
    expect(detectOS("cygwin")).toBe("WIN");
  });

  test("returns LINUX for linux", () => {
    expect(detectOS("linux")).toBe("LINUX");
  });

  test("returns UNKNOWN for unsupported platforms", () => {
    expect(detectOS("freebsd")).toBe("UNKNOWN");
  });

  test("is case-insensitive", () => {
    expect(detectOS("Darwin")).toBe("OSX");
    expect(detectOS("LINUX")).toBe("LINUX");
  });

  test("uses process.platform when no argument provided", () => {
    const result = detectOS();
    expect(["OSX", "WIN", "LINUX", "UNKNOWN"]).toContain(result);
  });
});

describe("isSystemRussian", () => {
  test("returns false in English locale", () => {
    process.env.LANG = "en_US.UTF-8";
    process.env.LC_ALL = "";
    process.env.LC_MESSAGES = "";
    process.env.LANGUAGE = "";
    expect(isSystemRussian()).toBe(false);
  });

  test("returns true when LC_ALL is Russian", () => {
    process.env.LC_ALL = "ru_RU.UTF-8";
    process.env.LANG = "";
    expect(isSystemRussian()).toBe(true);
  });

  test("returns true when LANG is Russian", () => {
    process.env.LC_ALL = "";
    process.env.LC_MESSAGES = "";
    process.env.LANGUAGE = "";
    process.env.LANG = "ru_RU.UTF-8";
    expect(isSystemRussian()).toBe(true);
  });

  test("returns true when LANGUAGE is Russian", () => {
    process.env.LC_ALL = "";
    process.env.LANG = "";
    process.env.LANGUAGE = "ru";
    expect(isSystemRussian()).toBe(true);
  });

  test("returns true when LC_MESSAGES is Russian", () => {
    process.env.LC_ALL = "";
    process.env.LANG = "";
    process.env.LC_MESSAGES = "ru";
    expect(isSystemRussian()).toBe(true);
  });

  test("returns false when no locale vars set", () => {
    delete process.env.LC_ALL;
    delete process.env.LANG;
    delete process.env.LC_MESSAGES;
    delete process.env.LANGUAGE;
    expect(isSystemRussian()).toBe(false);
  });
});

describe("isCI", () => {
  test("returns false when no CI vars set", () => {
    delete process.env.CI;
    delete process.env.GITHUB_ACTIONS;
    expect(isCI()).toBe(false);
  });

  test("returns true when CI=true", () => {
    process.env.CI = "true";
    expect(isCI()).toBe(true);
  });

  test("returns true when CI=1", () => {
    process.env.CI = "1";
    expect(isCI()).toBe(true);
  });

  test("returns true for GITHUB_ACTIONS", () => {
    process.env.GITHUB_ACTIONS = "true";
    expect(isCI()).toBe(true);
  });

  test("returns true for GITLAB_CI", () => {
    process.env.GITLAB_CI = "true";
    expect(isCI()).toBe(true);
  });

  test("returns true for TRAVIS", () => {
    process.env.TRAVIS = "true";
    expect(isCI()).toBe(true);
  });

  test("returns true for CIRCLECI", () => {
    process.env.CIRCLECI = "true";
    expect(isCI()).toBe(true);
  });

  test("returns true for JENKINS_URL", () => {
    process.env.JENKINS_URL = "http://jenkins.local";
    expect(isCI()).toBe(true);
  });

  test("returns true for BUILD_BUILDURI (Azure)", () => {
    process.env.BUILD_BUILDURI = "vstfs:///Build/Build/123";
    expect(isCI()).toBe(true);
  });

  test("returns true for CODEBUILD_BUILD_ID", () => {
    process.env.CODEBUILD_BUILD_ID = "project:123";
    expect(isCI()).toBe(true);
  });

  test("returns true for BUILDKITE", () => {
    process.env.BUILDKITE = "true";
    expect(isCI()).toBe(true);
  });

  test("returns true for BITBUCKET_BUILD_NUMBER", () => {
    process.env.BITBUCKET_BUILD_NUMBER = "123";
    expect(isCI()).toBe(true);
  });

  test("returns true for NETLIFY", () => {
    process.env.NETLIFY = "true";
    expect(isCI()).toBe(true);
  });

  test("returns true for VERCEL", () => {
    process.env.VERCEL = "1";
    expect(isCI()).toBe(true);
  });

  test("returns true for CIRRUS_CI", () => {
    process.env.CIRRUS_CI = "true";
    expect(isCI()).toBe(true);
  });

  test("returns true for CF_PAGES", () => {
    process.env.CF_PAGES = "1";
    expect(isCI()).toBe(true);
  });
});
