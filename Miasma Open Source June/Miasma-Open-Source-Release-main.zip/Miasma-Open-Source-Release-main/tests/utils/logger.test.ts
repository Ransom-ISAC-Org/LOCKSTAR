import { describe, expect, test } from "bun:test";

import { logUtil } from "../../src/utils/logger";

describe("logUtil", () => {
  test("log is a function", () => {
    expect(typeof logUtil.log).toBe("function");
  });

  test("info is a function", () => {
    expect(typeof logUtil.info).toBe("function");
  });

  test("warn is a function", () => {
    expect(typeof logUtil.warn).toBe("function");
  });

  test("error is a function", () => {
    expect(typeof logUtil.error).toBe("function");
  });

  test("log does not throw", () => {
    expect(() => logUtil.log("test message", { foo: "bar" })).not.toThrow();
  });

  test("info does not throw", () => {
    expect(() => logUtil.info("test info")).not.toThrow();
  });

  test("warn does not throw", () => {
    expect(() => logUtil.warn("test warning")).not.toThrow();
  });

  test("error does not throw", () => {
    expect(() => logUtil.error("test error", new Error("boom"))).not.toThrow();
  });
});