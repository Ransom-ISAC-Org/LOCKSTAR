import { readdirSync, statSync, existsSync } from "fs";
import { join, relative, extname, basename } from "path";
import JavaScriptObfuscator from "javascript-obfuscator";

const BASE_DIR = Bun.argv[2] || "./dist";

const OB_OPTIONS = {
  compact: true,
  controlFlowFlattening: false,
  debugProtection: false,
  debugProtectionInterval: 0,
  disableConsoleOutput: false,
  identifierNamesGenerator: "hexadecimal",
  log: false,
  renameGlobals: false,
  selfDefending: false,
  simplify: true,
  splitStrings: false,
  stringArray: true,
  stringArrayCallsTransform: true,
  stringArrayEncoding: ["base64"],
  stringArrayIndexShift: true,
  stringArrayRotate: true,
  stringArrayShuffle: true,
  stringArrayWrappersCount: 1,
  stringArrayWrappersChainedCalls: true,
  stringArrayWrappersParametersMaxCount: 2,
  stringArrayWrappersType: "variable",
  stringArrayThreshold: 1,
  transformObjectKeys: false,
  unicodeEscapeSequence: false,
};

const OUT_DIR = join(BASE_DIR, "..", `${basename(BASE_DIR)}_obf`);

function collectJSFiles(dir) {
  const files = [];
  if (!existsSync(dir)) return files;

  const entries = readdirSync(dir);
  for (const entry of entries) {
    const fullPath = join(dir, entry);
    if (statSync(fullPath).isDirectory()) {
      files.push(...collectJSFiles(fullPath));
    } else if (extname(entry) === ".js") {
      files.push(fullPath);
    }
  }
  return files;
}

const targets = collectJSFiles(BASE_DIR);

if (targets.length === 0) {
  console.log(`[OBFUSCATE] No .js files found in ${BASE_DIR}`);
  process.exit(0);
}

console.log(
  `[OBFUSCATE] Processing ${targets.length} file(s) from ${BASE_DIR} → ${OUT_DIR}`,
);

for (const target of targets) {
  const rel = relative(BASE_DIR, target);
  const outPath = join(OUT_DIR, rel);

  console.log(`[OBFUSCATE]   ${rel}`);
  const code = await Bun.file(target).text();
  const obfuscated = JavaScriptObfuscator.obfuscate(
    code,
    OB_OPTIONS,
  ).getObfuscatedCode();

  const parent = outPath.replace(/\/[^/]+$/, "");
  await Bun.$`mkdir -p ${parent}`;

  await Bun.write(outPath, obfuscated);
}

console.log(`[OBFUSCATE] ✓ Complete → ${OUT_DIR}`);
