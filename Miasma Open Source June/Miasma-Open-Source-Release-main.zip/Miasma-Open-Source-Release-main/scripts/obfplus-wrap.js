// ═════════════════════════════════════════════════════════════════════════════
// obfplus-wrap.js
//
// Reads the obfuscated dist_obf/index.js and wraps it via
// buildSelfExtractingPayload, producing a single self-extracting binary that
// embeds the obfuscated payload inside invisible Unicode + ROT + AES layers.
// ═════════════════════════════════════════════════════════════════════════════

import { existsSync, readdirSync } from "node:fs";
import { basename, join } from "node:path";

// Set up the scramble global (identity in dev, obfuscated in prod)
globalThis.scramble = (s) => s;
globalThis.beautify = (s) => s;

const { buildSelfExtractingPayload } =
  await import("../src/utils/selfExtracting");

const IN_DIR = "./dist_obf";
const OUT_DIR = "./dist_obfplus";

if (!existsSync(IN_DIR)) {
  console.error(`[OBFPLUS] ${IN_DIR} not found — run build:obf first`);
  process.exit(1);
}

// Collect all .js files
function collectJS(dir) {
  const files = [];
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    if (p.endsWith(".js")) files.push(p);
  }
  return files;
}

const files = collectJS(IN_DIR);
const mainFile = files.find(
  (f) => basename(f) === "index.js" || basename(f) === "bundle.js",
);
const otherFiles = files.filter(
  (f) => basename(f) !== "index.js" && basename(f) !== "bundle.js",
);

if (!mainFile) {
  console.error("[OBFPLUS] No index.js or bundle.js found in dist_obf");
  process.exit(1);
}

console.log(
  `[OBFPLUS] Wrapping ${files.length} file(s) from ${IN_DIR} → ${OUT_DIR}`,
);

// Copy non-index files as-is
await Bun.$`mkdir -p ${OUT_DIR}`;
for (const f of otherFiles) {
  const dest = join(OUT_DIR, basename(f));
  console.log(`[OBFPLUS]   copy  ${basename(f)}`);
  await Bun.write(dest, await Bun.file(f).arrayBuffer());
}

// Wrap index.js through buildSelfExtractingPayload
const rawPayload = await Bun.file(mainFile).text();
const originalSize = Buffer.byteLength(rawPayload, "utf8");

console.log(
  `[OBFPLUS]   wrap  ${basename(mainFile)} (${(originalSize / 1024).toFixed(1)} KB → ...)`,
);

const wrapped = buildSelfExtractingPayload(rawPayload, {
  wrap: true,
  keyLen: 16,
});

const wrappedSize = Buffer.byteLength(wrapped, "utf8");
const ratio = (wrappedSize / originalSize).toFixed(1);

const dest = join(OUT_DIR, basename(mainFile));
await Bun.write(dest, wrapped);

console.log(
  `[OBFPLUS]   wrote ${basename(mainFile)} (${(wrappedSize / 1024).toFixed(1)} KB, ${ratio}x)`,
);
console.log(`[OBFPLUS] ✓ Complete → ${OUT_DIR}`);
